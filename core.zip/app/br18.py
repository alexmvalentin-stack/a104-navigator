"""BR18-biblioteket: Bygningsreglementets krav og tabeller med fuldtekstsøgning.

Data (fra bygningsreglementet.dk, Social- og Boligstyrelsen) læses fra mappen »br18«:
* br18_krav.json         – kravtekst pr. § og stk. (kapitel, afsnit, domæne, status, kilde-URL)
* br18_tabeller_lang.csv – tabeller fra bilag og kapitler i »lang« form (tabel, række, kolonne, værdi)
En nyere udgave i programmets datamappe (DATA_ROOT/br18) bruges frem for den medfølgende.

Søgningen kører i en SQLite-database i hukommelsen med FTS5 (ord og ordbegyndelser, så »flugtvej« også finder
»flugtveje«). Paragrafhenvisninger som »§ 82«, »§82 stk. 2« og »82,2« slås direkte op.
"""
from __future__ import annotations

import csv
import json
import logging
import re
import sqlite3
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

from rapidfuzz import fuzz, process

from settings import ASSETS_DIR, DATA_ROOT

log = logging.getLogger(__name__)

USER_DIR = DATA_ROOT / "br18"
BUNDLED_DIR = ASSETS_DIR / "br18"
KRAV_FILE = "br18_krav.json"
TABLE_FILE = "br18_tabeller_lang.csv"
GUIDE_FILES = ("br18_vejledninger.jsonl", "br18_vejledninger_supplerende.jsonl")
ANNEX_FILE = "nationale_annekser.jsonl"     # kun lokalt (Dansk Standards tekst følger ikke med programmet)
ANNEX_SOURCE = "annekser_kilde.json"        # {"pdf_dir": "...\\nationale-annekser"}
GUIDE_TYPES = {"kapitelvejledning": "Kapitelvejledning", "undersider": "Vejledning (underside)",
               "oversigt": "Oversigt", "supplerende side": "Supplerende side"}

DOMAIN_LABELS = {
    "administrativt": "Administrativt", "tilgaengelighed": "Tilgængelighed", "affald": "Affald", "afloeb": "Afløb",
    "brand": "Brand", "brugerbetjente_anlaeg": "Brugerbetjente anlæg", "byggeplads": "Byggeplads",
    "byggeret": "Byggeret", "indretning": "Indretning", "elevator": "Elevatorer", "varme": "Varme og energi",
    "lca": "LCA / klimapåvirkning", "energiforsyning": "Energiforsyning", "forurening": "Forurening",
    "fugt": "Fugt og vådrum", "konstruktion": "Konstruktioner", "legepladser": "Legepladser", "lyd": "Lyd",
    "lys": "Lys og udsyn", "indeklima": "Termisk indeklima", "ubebyggede_arealer": "Ubebyggede arealer",
    "vand": "Vand", "ventilation": "Ventilation", "beregningsregler": "Beregningsregler", "andet": "Andet",
    "kontrol": "Kontrol",
}
WORD_RE = re.compile(r"[0-9A-Za-zÆØÅæøåÄÖÜäöüé]+")
PARAGRAPH_RE = re.compile(r"§+\s*(\d{1,3})(?:\s*,?\s*stk\.?\s*(\d{1,2}))?", re.IGNORECASE)
BARE_REF_RE = re.compile(r"^\s*(\d{1,3})(?:\s*[,.]\s*(?:stk\.?\s*)?(\d{1,2}))?\s*$", re.IGNORECASE)
STK_RE = re.compile(r"\bstk\.?\s*(\d{1,2})\b", re.IGNORECASE)


@dataclass
class Krav:
    kode: str
    kapitel: str
    kapitel_titel: str
    paragraf: int
    afsnit_titel: str
    stk: int
    domaene: str
    status: str
    tekst: str
    url: str

    @property
    def repealed(self) -> bool:
        return self.status != "gaeldende"

    @property
    def reference(self) -> str:
        return f"BR18 § {self.paragraf}" + (f", stk. {self.stk}" if self.stk else "")


@dataclass
class Tabel:
    id: str
    kapitel: str
    titel: str
    header: list[str] = field(default_factory=list)
    rows: list[list[str]] = field(default_factory=list)

    def text(self) -> str:
        return " ".join([self.titel, *self.header, *(" ".join(r) for r in self.rows)])


@dataclass
class Hit:
    krav: Krav
    score: float
    snippet: str  # tekst med \x02 … \x03 omkring fundne ord


@dataclass
class Doc:
    """En vejledning eller én side af et nationalt anneks."""
    id: str
    kind: str          # vejledning | anneks
    kapitel: str       # "05", "B1" eller "" (annekser)
    titel: str
    tekst: str
    url: str = ""
    typ: str = ""      # kapitelvejledning, undersider … / standard for annekser
    page: int = 0      # sidetal i anneks-PDF'en
    pages: int = 0     # antal sider i anneks-PDF'en
    pdf: str = ""      # sti til PDF'en (annekser)


@dataclass
class DocHit:
    doc: Doc
    score: float
    snippet: str


def _annex_title(fil: str, first_page: str) -> str:
    """'ds-en-1991-1-1-dk-na-2013_…pdf' + forsidetekst -> 'DS/EN 1991-1-1 DK NA:2013 – Last på bygværker …'."""
    m = re.search(r"(DS/EN[^\n]*?DK NA:\s?\d{4})", first_page)
    code = re.sub(r"\s+", " ", m.group(1)).strip() if m else ""
    if not code:
        m = re.match(r"ds-en-(.+?)-dk-na-(\d{4})", fil)
        code = f"DS/EN {m.group(1)} DK NA:{m.group(2)}" if m else fil
    m = re.search(r"Nationalt anneks til\s+(.+?)(?:\n\s*\n|_{3,}|$)", first_page, re.S)
    name = re.sub(r"\s+", " ", m.group(1)).strip(" -") if m else ""
    return f"{code} – {name[:90]}" if name else code


class BR18Library:
    def __init__(self, folder: Path | None = None):
        self.folder = folder or self.default_folder()
        self.krav: list[Krav] = []
        self.tables: list[Tabel] = []
        self.docs: list[Doc] = []
        self.annex_pdf_dir: Path | None = None
        self.edition = ""
        self.source = ""
        self.loaded = False
        self.error = ""
        self._db: sqlite3.Connection | None = None
        self._vocabulary: list[str] = []

    @staticmethod
    def default_folder() -> Path:
        if (USER_DIR / KRAV_FILE).exists():
            return USER_DIR
        return BUNDLED_DIR

    # ------------------------------------------------------------------ indlæsning
    def load(self) -> bool:
        if self.loaded:
            return True
        try:
            data = json.loads((self.folder / KRAV_FILE).read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            self.error = f"BR18-data kunne ikke læses fra {self.folder}: {exc}"
            log.warning(self.error)
            return False
        rows = data.get("krav", []) if isinstance(data, dict) else data
        self.edition = str(data.get("udgave", "")) if isinstance(data, dict) else ""
        self.source = str(data.get("kilde", "")) if isinstance(data, dict) else ""
        self.krav = [Krav(str(r.get("kode", "")), str(r.get("kapitel", "")), str(r.get("kapitel_titel", "")),
                          int(r.get("paragraf") or 0), str(r.get("afsnit_titel") or ""), int(r.get("stk") or 0),
                          str(r.get("domaene") or "andet"), str(r.get("status") or "gaeldende"),
                          str(r.get("tekst") or ""), str(r.get("kilde_url") or "")) for r in rows]
        self.tables = self._load_tables(self.folder / TABLE_FILE)
        self.docs = self._load_guides() + self._load_annexes()
        self._build_index()
        self.loaded = True
        return True

    @staticmethod
    def _load_tables(path: Path) -> list[Tabel]:
        if not path.exists():
            return []
        cells: dict[str, dict] = {}
        with open(path, encoding="utf-8-sig", newline="") as fh:
            for r in csv.DictReader(fh, delimiter=";"):
                t = cells.setdefault(r["tabel_id"], {"kapitel": r["kapitel"], "titel": r["tabel_titel"],
                                                     "header": {}, "cells": defaultdict(dict)})
                try:
                    row, col = int(r["raekke"]), int(r["kolonne"])
                except ValueError:
                    continue
                t["header"].setdefault(col, r.get("overskrift") or "")
                t["cells"][row][col] = r.get("vaerdi") or ""
        tables = []
        for tid, t in cells.items():
            cols = sorted(t["header"])
            rows = [[t["cells"][r].get(c, "") for c in cols] for r in sorted(t["cells"])]
            tables.append(Tabel(tid, t["kapitel"], t["titel"], [t["header"][c] for c in cols], rows))
        return tables

    def _load_guides(self) -> list[Doc]:
        """Vejledninger, Q&A og oversigter (fra den valgte mappe, ellers de medfølgende)."""
        docs: list[Doc] = []
        for name in GUIDE_FILES:
            path = self.folder / name if (self.folder / name).exists() else BUNDLED_DIR / name
            if not path.exists():
                continue
            for line in path.read_text(encoding="utf-8").splitlines():
                try:
                    r = json.loads(line)
                except ValueError:
                    continue
                text = str(r.get("tekst") or "").strip()
                if len(text) < 80:  # tomme menusider
                    continue
                title = str(r.get("titel") or "").strip() or str(r.get("id"))
                if " " not in title and "-" in title:  # »vejledning-om-klimasikring« -> »Vejledning om klimasikring«
                    title = title.replace("-", " ").replace("_", " ").capitalize()
                docs.append(Doc(str(r.get("id")), "vejledning", str(r.get("kapitel") or ""), title, text,
                                str(r.get("kilde") or ""), str(r.get("type") or "")))
        return docs

    def _load_annexes(self) -> list[Doc]:
        """Nationale annekser (DK NA) – én post pr. side. Kun hvis de er indlæst lokalt."""
        path = USER_DIR / ANNEX_FILE
        if not path.exists():
            return []
        try:
            src = json.loads((USER_DIR / ANNEX_SOURCE).read_text(encoding="utf-8"))
            self.annex_pdf_dir = Path(src.get("pdf_dir", "")) if src.get("pdf_dir") else None
        except (OSError, ValueError):
            self.annex_pdf_dir = None
        docs: list[Doc] = []
        for line in path.read_text(encoding="utf-8").splitlines():
            try:
                r = json.loads(line)
            except ValueError:
                continue
            pages = r.get("sider") or []
            title = _annex_title(str(r.get("fil", "")), str(pages[0].get("tekst", "")) if pages else "")
            pdf = str(self.annex_pdf_dir / r["fil"]) if self.annex_pdf_dir and r.get("fil") else ""
            for p in pages:
                text = str(p.get("tekst") or "").strip()
                if text:
                    docs.append(Doc(f"{r.get('fil')}#{p.get('side')}", "anneks", "", title, text, "",
                                    typ=f"DS/EN {r.get('standard', '')} ({r.get('sprog', '')})",
                                    page=int(p.get("side") or 0), pdf=pdf, pages=len(pages)))
        return docs

    def _build_index(self) -> None:
        db = sqlite3.connect(":memory:", check_same_thread=False)
        db.execute("CREATE VIRTUAL TABLE fts USING fts5(afsnit, tekst, kapitel, domaene, "
                   "tokenize='unicode61 remove_diacritics 0')")
        db.executemany("INSERT INTO fts(rowid, afsnit, tekst, kapitel, domaene) VALUES (?, ?, ?, ?, ?)",
                       [(i, k.afsnit_titel, k.tekst, k.kapitel_titel, DOMAIN_LABELS.get(k.domaene, k.domaene))
                        for i, k in enumerate(self.krav)])
        db.execute("CREATE VIRTUAL TABLE docs USING fts5(titel, tekst, tokenize='unicode61 remove_diacritics 0')")
        db.executemany("INSERT INTO docs(rowid, titel, tekst) VALUES (?, ?, ?)",
                       [(i, d.titel, d.tekst) for i, d in enumerate(self.docs)])
        self._db = db
        words = set()
        for k in self.krav:
            words.update(w.lower() for w in WORD_RE.findall(f"{k.afsnit_titel} {k.tekst}") if len(w) > 3)
        for d in self.docs:
            if d.kind == "vejledning":
                words.update(w.lower() for w in WORD_RE.findall(d.titel) if len(w) > 3)
        self._vocabulary = sorted(words)

    def doc(self, doc_id: str) -> Doc | None:
        return next((d for d in self.docs if d.id == doc_id), None)

    def doc_counts(self) -> dict[str, int]:
        counts: dict[str, int] = defaultdict(int)
        for d in self.docs:
            counts[d.kind] += 1
        return dict(counts)

    def search_docs(self, query: str, kind: str, kapitel: str | None = None, limit: int = 300) -> list[DocHit]:
        """Søg i vejledninger eller annekser. §-henvisninger (»§ 82«) findes som tekst i dokumenterne."""
        if not self.load():
            return []
        pool = [(i, d) for i, d in enumerate(self.docs)
                if d.kind == kind and (not kapitel or kind != "vejledning" or d.kapitel == kapitel)]
        allowed = {i for i, _d in pool}
        hits: list[DocHit] = []
        seen: set[int] = set()
        refs = [int(m.group(1)) for m in PARAGRAPH_RE.finditer(query)]
        for number in refs:
            pattern = re.compile(rf"§§?\s*{number}(?!\d)")
            for i, d in pool:
                m = pattern.search(d.tekst)
                if m and i not in seen:
                    seen.add(i)
                    start = max(0, m.start() - 80)
                    snip = d.tekst[start:m.start()] + "\x02" + m.group(0) + "\x03" + d.tekst[m.end():m.end() + 120]
                    hits.append(DocHit(d, 500.0 + len(pattern.findall(d.tekst)), ("…" if start else "") + snip))
        terms = [self.corrections(query).get(t, t) for t in self.terms(query)]
        if terms:
            for joiner in (" AND ", " OR "):
                match = joiner.join(f'"{t}"*' for t in terms)
                try:
                    rows = self._db.execute(
                        "SELECT rowid, bm25(docs, 6.0, 1.0), snippet(docs, 1, char(2), char(3), '…', 30) "
                        "FROM docs WHERE docs MATCH ? ORDER BY 2 LIMIT ?", (match, limit * 3)).fetchall()
                except sqlite3.OperationalError:
                    rows = []
                for rowid, rank, snip in rows:
                    if rowid in seen or rowid not in allowed:
                        continue
                    seen.add(rowid)
                    hits.append(DocHit(self.docs[rowid], -rank + (50 if joiner == " AND " else 0), snip))
                if len(hits) >= 5 or len(terms) == 1:
                    break
        elif not refs:
            return [DocHit(d, 0.0, d.tekst[:200]) for _i, d in pool][:limit]
        hits.sort(key=lambda h: -h.score)
        return hits[:limit]

    # ------------------------------------------------------------------ opslag
    def chapters(self) -> list[tuple[str, str, int]]:
        seen: dict[str, list] = {}
        for k in self.krav:
            seen.setdefault(k.kapitel, [k.kapitel_titel, 0])[1] += 1
        return [(kap, v[0], v[1]) for kap, v in sorted(seen.items(), key=lambda kv: _chapter_key(kv[0]))]

    def domains(self) -> list[tuple[str, str, int]]:
        counts: dict[str, int] = defaultdict(int)
        for k in self.krav:
            counts[k.domaene] += 1
        return sorted(((d, DOMAIN_LABELS.get(d, d.capitalize()), n) for d, n in counts.items()),
                      key=lambda x: x[1])

    def paragraph(self, number: int) -> list[Krav]:
        return sorted((k for k in self.krav if k.paragraf == number), key=lambda k: k.stk)

    def chapter_tables(self, kapitel: str) -> list[Tabel]:
        return [t for t in self.tables if t.kapitel == kapitel]

    def table(self, tid: str) -> Tabel | None:
        return next((t for t in self.tables if t.id == tid), None)

    # ------------------------------------------------------------------ søgning
    def _filtered(self, k: Krav, kapitel: str | None, domaene: str | None, include_repealed: bool) -> bool:
        return ((not kapitel or k.kapitel == kapitel) and (not domaene or k.domaene == domaene)
                and (include_repealed or not k.repealed))

    def terms(self, query: str) -> list[str]:
        """Søgeordene (uden §-henvisninger og »stk.«)."""
        q = STK_RE.sub(" ", PARAGRAPH_RE.sub(" ", query))
        return [w for w in WORD_RE.findall(q) if not w.isdigit() or len(w) > 3]

    def corrections(self, query: str) -> dict[str, str]:
        """Stavehjælp: ord, der ikke findes i BR18, men ligner et der gør (»brandkam« -> »brandkamme«)."""
        if not self.load():
            return {}
        out = {}
        for t in self.terms(query):
            lower = t.lower()
            if len(lower) < 4 or any(v.startswith(lower) for v in self._vocabulary):
                continue
            best = process.extractOne(lower, self._vocabulary, scorer=fuzz.ratio, score_cutoff=78)
            if best:
                out[t] = best[0]
        return out

    def search(self, query: str, kapitel: str | None = None, domaene: str | None = None,
               include_repealed: bool = False, limit: int = 300) -> list[Hit]:
        if not self.load():
            return []
        query = query.strip()
        hits: list[Hit] = []
        seen: set[int] = set()

        # 1) §-henvisninger: »§ 82«, »§82 stk. 2«, »82,2« eller bare »82«
        refs = [(int(m.group(1)), int(m.group(2)) if m.group(2) else None) for m in PARAGRAPH_RE.finditer(query)]
        bare = BARE_REF_RE.match(query)
        if bare and not refs:
            refs = [(int(bare.group(1)), int(bare.group(2)) if bare.group(2) else None)]
        for number, stk in refs:
            for i, k in enumerate(self.krav):
                if k.paragraf == number and (stk is None or k.stk == stk) \
                        and self._filtered(k, kapitel, domaene, True):
                    hits.append(Hit(k, 1000.0, k.tekst[:220]))
                    seen.add(i)

        # 2) fuldtekst: alle ord (som ordbegyndelser) – ellers mindst ét ord
        terms = self.terms(query)
        if terms:
            fixed = self.corrections(query)
            terms = [fixed.get(t, t) for t in terms]
            for joiner in (" AND ", " OR "):
                match = joiner.join(f'"{t}"*' for t in terms)
                try:
                    rows = self._db.execute(
                        "SELECT rowid, bm25(fts, 4.0, 1.0, 0.5, 2.0), snippet(fts, 1, char(2), char(3), '…', 28) "
                        "FROM fts WHERE fts MATCH ? ORDER BY 2 LIMIT ?", (match, limit * 2)).fetchall()
                except sqlite3.OperationalError as exc:
                    log.debug("FTS-fejl for %r: %s", match, exc)
                    rows = []
                for rowid, rank, snip in rows:
                    k = self.krav[rowid]
                    if rowid in seen or not self._filtered(k, kapitel, domaene, include_repealed):
                        continue
                    seen.add(rowid)
                    hits.append(Hit(k, -rank + (50 if joiner == " AND " else 0), snip))
                if len(hits) >= 5 or len(terms) == 1:
                    break
        elif not refs:
            # ingen søgning: vis alt (filtreret) i paragrafrækkefølge
            hits = [Hit(k, 0.0, k.tekst[:220]) for k in self.krav
                    if self._filtered(k, kapitel, domaene, include_repealed)]
            return hits[:limit] if limit else hits
        hits.sort(key=lambda h: -h.score)
        return hits[:limit]

    def count(self, query: str) -> int:
        """Antal fundne krav – til den globale søgning."""
        if not query.strip() or not self.load():
            return 0
        return len(self.search(query, limit=500))

    def count_all(self, query: str) -> tuple[int, int, int]:
        """(krav, vejledninger, annekssider) – til den globale søgning."""
        if not query.strip() or not self.load():
            return 0, 0, 0
        return (len(self.search(query, limit=500)), len(self.search_docs(query, "vejledning", limit=500)),
                len(self.search_docs(query, "anneks", limit=500)))

    def search_tables(self, query: str, kapitel: str | None = None) -> list[Tabel]:
        if not self.load():
            return []
        terms = [t.lower() for t in self.terms(query)]
        out = []
        for t in self.tables:
            if kapitel and t.kapitel != kapitel:
                continue
            text = t.text().lower()
            if all(term in text for term in terms):
                out.append(t)
        return out


def _chapter_key(kap: str) -> tuple:
    return (1, kap) if kap[:1].isalpha() else (0, kap.zfill(3))


_library: BR18Library | None = None


def library() -> BR18Library:
    global _library
    if _library is None:
        _library = BR18Library()
    return _library


def reload_library() -> BR18Library:
    global _library
    _library = BR18Library()
    _library.load()
    return _library

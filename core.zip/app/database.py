"""SQLite-databasen: skema, import-hjælpere og forespørgsler.

Databasedesign (se også README.md):

    sources          Datakilder (Molio A104 nu – CCS, BR18, SBi, DS mv. senere)
    code_families    Kodepræfikser (A = Fase, K = Vidensområde, ...) fra arket "Koder"
    folders          Mappestrukturen (indholdstyper C/D/P) som træ via parent_code
    knowledge_areas  Vidensområder (K-koder)
    disciplines      Fagdiscipliner (M-koder) med beskrivelse og nøgleord
    codes            Samlet kodeopslag for alle værdilister (A, B, E, F, G, H, ...)
    documents        Dokument-, tegnings- og modelnavne med typisk placering
    examples         Udfyldte eksempelrækker fra Excel (filnavne, tegningsnumre)
    concepts         Begreber til intelligent matching (brand, KS, lyd, ...)
    relations        Generiske relationer mellem alle ovenstående
    favorites        Brugerens favoritter (overlever genindlæsning)
    projects         Brugerens projektmapper på disken (overlever genindlæsning)
    meta             Nøgle/værdi: importtidspunkt, Excel-sti, hash mv.
"""
from __future__ import annotations

import json
import re
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Iterable, Iterator

from models import CODE, DISCIPLINE, DOCUMENT, EXAMPLE, FOLDER, KNOWLEDGE_AREA

SCHEMA_VERSION = 1

SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);
CREATE TABLE IF NOT EXISTS sources (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    key         TEXT NOT NULL UNIQUE,
    name        TEXT NOT NULL,
    kind        TEXT NOT NULL,
    location    TEXT,
    enabled     INTEGER NOT NULL DEFAULT 1,
    imported_at TEXT
);
CREATE TABLE IF NOT EXISTS code_families (
    family      TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    description TEXT,
    sort_order  INTEGER NOT NULL DEFAULT 0,
    source_id   INTEGER REFERENCES sources(id)
);
CREATE TABLE IF NOT EXISTS folders (
    code        TEXT PRIMARY KEY,
    parent_code TEXT REFERENCES folders(code),
    name        TEXT NOT NULL,
    level       INTEGER NOT NULL DEFAULT 0,
    sort_order  INTEGER NOT NULL DEFAULT 0,
    family      TEXT,
    purpose     TEXT,
    description TEXT,
    phases      TEXT,
    keywords    TEXT,
    source_id   INTEGER REFERENCES sources(id)
);
CREATE TABLE IF NOT EXISTS knowledge_areas (
    code        TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    short_list  INTEGER NOT NULL DEFAULT 0,
    description TEXT,
    keywords    TEXT,
    sort_order  INTEGER NOT NULL DEFAULT 0,
    source_id   INTEGER REFERENCES sources(id)
);
CREATE TABLE IF NOT EXISTS disciplines (
    code        TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    description TEXT,
    keywords    TEXT,
    sort_order  INTEGER NOT NULL DEFAULT 0,
    source_id   INTEGER REFERENCES sources(id)
);
CREATE TABLE IF NOT EXISTS codes (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    code         TEXT,
    family       TEXT NOT NULL,
    category     TEXT NOT NULL,
    name         TEXT NOT NULL,
    description  TEXT,
    folder_code  TEXT REFERENCES folders(code),
    aliases      TEXT,
    entity_type  TEXT NOT NULL DEFAULT 'code',
    sort_order   INTEGER NOT NULL DEFAULT 0,
    source_table TEXT,
    source_id    INTEGER REFERENCES sources(id),
    UNIQUE (code, category)
);
CREATE TABLE IF NOT EXISTS documents (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    name                TEXT NOT NULL,
    doc_kind            TEXT NOT NULL DEFAULT 'document',
    folder_code         TEXT REFERENCES folders(code),
    knowledge_area_code TEXT REFERENCES knowledge_areas(code),
    discipline_code     TEXT REFERENCES disciplines(code),
    phase_codes         TEXT,
    drawing_type_code   TEXT,
    description         TEXT,
    explanation         TEXT,
    keywords            TEXT,
    origin              TEXT NOT NULL,
    placement_source    TEXT,
    source_id           INTEGER REFERENCES sources(id),
    UNIQUE (name, doc_kind)
);
CREATE TABLE IF NOT EXISTS examples (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    sheet               TEXT,
    table_name          TEXT,
    row_number          INTEGER,
    doc_kind            TEXT NOT NULL,
    name                TEXT NOT NULL,
    folder_code         TEXT REFERENCES folders(code),
    phase_code          TEXT,
    file_type_code      TEXT,
    knowledge_area_code TEXT,
    discipline_code     TEXT,
    contract_code       TEXT,
    drawing_type_code   TEXT,
    floor_code          TEXT,
    serial_code         TEXT,
    document_form       TEXT,
    generated_name      TEXT,
    parent_file         TEXT,
    archive_path        TEXT,
    raw_json            TEXT,
    source_id           INTEGER REFERENCES sources(id)
);
CREATE TABLE IF NOT EXISTS concepts (
    key         TEXT PRIMARY KEY,
    label       TEXT NOT NULL,
    emoji       TEXT,
    terms       TEXT NOT NULL,
    description TEXT
);
CREATE TABLE IF NOT EXISTS relations (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    from_type TEXT NOT NULL,
    from_key  TEXT NOT NULL,
    to_type   TEXT NOT NULL,
    to_key    TEXT NOT NULL,
    relation  TEXT NOT NULL,
    weight    REAL NOT NULL DEFAULT 1.0,
    UNIQUE (from_type, from_key, to_type, to_key, relation)
);
CREATE TABLE IF NOT EXISTS favorites (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    item_type  TEXT NOT NULL,
    item_key   TEXT NOT NULL,
    label      TEXT,
    created_at TEXT NOT NULL,
    UNIQUE (item_type, item_key)
);
CREATE TABLE IF NOT EXISTS projects (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL,
    project_id TEXT,
    root_path  TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS folder_structures (
    structure TEXT NOT NULL,          -- fx »Mappestruktur_udvekslingsplatform, metode C« (Molio A104c)
    level     INTEGER NOT NULL,       -- 1 = hovedmappe under projektroden
    code      TEXT,
    name      TEXT NOT NULL,
    path      TEXT NOT NULL,          -- relativ sti, fx »C02 Aftale\\C02.05 Kontrakt«
    sort      INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS file_initials (
    path      TEXT PRIMARY KEY,          -- fuld sti (små bogstaver), initialer sat af brugeren
    initials   TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS initials_rules (
    folder     TEXT PRIMARY KEY,          -- mappe (små bogstaver): alle filer herunder er lavet af ...
    initials   TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_folders_parent ON folders(parent_code);
CREATE INDEX IF NOT EXISTS ix_codes_family ON codes(family);
CREATE INDEX IF NOT EXISTS ix_codes_code ON codes(code);
CREATE INDEX IF NOT EXISTS ix_documents_folder ON documents(folder_code);
CREATE INDEX IF NOT EXISTS ix_examples_folder ON examples(folder_code);
CREATE INDEX IF NOT EXISTS ix_relations_from ON relations(from_type, from_key);
CREATE INDEX IF NOT EXISTS ix_relations_to ON relations(to_type, to_key);
"""

# Tabeller der tømmes ved genindlæsning (favorites og meta bevares)
DATA_TABLES = ("relations", "concepts", "examples", "documents", "codes", "disciplines",
               "knowledge_areas", "folders", "code_families", "folder_structures")

_ZERO_RE = re.compile(r"(?<![0-9])0+(?=\d)")


def code_key(code: str | None) -> str:
    """Normaliseret kode til sammenligning: 'Y070' == 'Y70', 'c04.04' == 'C4.4'."""
    if not code:
        return ""
    return _ZERO_RE.sub("", code.strip().upper())


def folder_sort_key(code: str) -> tuple:
    """Naturlig sortering: C01 < C02 < ... < C11 < D1 < D2 < P3; C06.04 < C06.10; D2.A5 < D2.A7."""
    family_order = {"C": 0, "D": 1, "P": 2}
    main, _, sub = code.partition(".")
    letter = main[:1]
    digits = re.sub(r"\D", "", main)
    sub_letters = re.sub(r"[\d]", "", sub)
    sub_digits = re.sub(r"\D", "", sub)
    return (
        family_order.get(letter, 9), letter, int(digits) if digits else 0,
        1 if sub else 0, sub_letters, int(sub_digits) if sub_digits else 0,
    )


class Database:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        # isolation_level=None: autocommit; transaktioner styres eksplicit i transaction()
        self.conn = sqlite3.connect(str(self.path), isolation_level=None, timeout=30)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA synchronous=NORMAL")
        self._name_cache: dict[str, dict[str, str]] | None = None

    # ------------------------------------------------------------------ basis
    def init_schema(self) -> None:
        self.conn.executescript(SCHEMA)
        self.set_meta("schema_version", str(SCHEMA_VERSION))
        self.conn.commit()

    def close(self) -> None:
        self.conn.close()

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        try:
            self.conn.execute("BEGIN")
            yield self.conn
            self.conn.execute("COMMIT")
        except Exception:
            self.conn.execute("ROLLBACK")
            raise
        finally:
            self._name_cache = None

    def invalidate_cache(self) -> None:
        self._name_cache = None

    def query(self, sql: str, params: Iterable = ()) -> list[sqlite3.Row]:
        return self.conn.execute(sql, tuple(params)).fetchall()

    def query_one(self, sql: str, params: Iterable = ()) -> sqlite3.Row | None:
        return self.conn.execute(sql, tuple(params)).fetchone()

    # ------------------------------------------------------------ initialer
    def _ensure_initials_tables(self) -> None:
        """Tabellerne oprettes også her, så en ældre database (fra før v2.0) virker uden genindlæsning."""
        self.conn.execute("CREATE TABLE IF NOT EXISTS file_initials (path TEXT PRIMARY KEY, initials TEXT NOT NULL, "
                          "updated_at TEXT NOT NULL)")
        self.conn.execute("CREATE TABLE IF NOT EXISTS initials_rules (folder TEXT PRIMARY KEY, initials TEXT NOT NULL, "
                          "updated_at TEXT NOT NULL)")

    # ------------------------------------------------------------ filers oprindelse
    def _ensure_origin_table(self) -> None:
        self.conn.execute("CREATE TABLE IF NOT EXISTS file_origins (path TEXT PRIMARY KEY, source TEXT NOT NULL, "
                          "original_name TEXT, owner TEXT, how TEXT, added_at TEXT NOT NULL)")
        # originalens »Ændret«-dato – filen i projektet får dagens dato, så den ses som ny i SharePoint/Teams
        self.conn.execute("CREATE TABLE IF NOT EXISTS file_dates (path TEXT PRIMARY KEY, orig_modified TEXT NOT NULL)")

    def record_origin(self, path, source, owner: str = "", how: str = "kopieret", orig_modified: str = "") -> None:
        """Husk hvor en fil i projektet kom fra (sti, oprindeligt navn, ejer, originalens ændret-dato). Flyttes/
        omdøbes filen senere, følger oprindelsen med (kald move_origin)."""
        from datetime import datetime
        self._ensure_origin_table()
        self.conn.execute(
            "INSERT INTO file_origins(path, source, original_name, owner, how, added_at) VALUES (?, ?, ?, ?, ?, ?) "
            "ON CONFLICT(path) DO UPDATE SET source = excluded.source, original_name = excluded.original_name, "
            "owner = excluded.owner, how = excluded.how, added_at = excluded.added_at",
            (str(path).lower(), str(source), Path(str(source)).name, owner or "", how,
             datetime.now().isoformat(timespec="seconds")))
        if orig_modified:
            self.set_orig_modified(path, orig_modified)

    def set_orig_modified(self, path, orig_modified: str) -> None:
        """Gem originalens ændret-dato (den første, der kendes – overskrives ikke)."""
        self._ensure_origin_table()
        self.conn.execute("INSERT OR IGNORE INTO file_dates(path, orig_modified) VALUES (?, ?)",
                          (str(path).lower(), orig_modified))

    def orig_modified(self, path) -> str:
        self._ensure_origin_table()
        row = self.query_one("SELECT orig_modified FROM file_dates WHERE path = ?", (str(path).lower(),))
        return row["orig_modified"] if row else ""

    def move_origin(self, old_path, new_path) -> None:
        """Filen er omdøbt/flyttet: behold dens oprindelse – eller registrér den gamle sti som oprindelse."""
        self._ensure_origin_table()
        self._ensure_initials_tables()
        # rettede initialer følger filen (ellers forsvinder de, når filen får A104-kode)
        self.conn.execute("UPDATE OR REPLACE file_initials SET path = ? WHERE path = ?",
                          (str(new_path).lower(), str(old_path).lower()))
        self.conn.execute("UPDATE OR REPLACE file_dates SET path = ? WHERE path = ?",
                          (str(new_path).lower(), str(old_path).lower()))
        self._ensure_upload_table()  # hvem der lagde filen ind, følger også med
        self.conn.execute("UPDATE OR REPLACE file_uploads SET path = ? WHERE path = ?",
                          (str(new_path).lower(), str(old_path).lower()))
        row = self.query_one("SELECT * FROM file_origins WHERE path = ?", (str(old_path).lower(),))
        if row:
            self.conn.execute("UPDATE file_origins SET path = ? WHERE path = ?",
                              (str(new_path).lower(), str(old_path).lower()))
        elif str(old_path).lower() != str(new_path).lower():
            self.record_origin(new_path, old_path, how="omdøbt")

    def origins(self) -> dict[str, dict]:
        self._ensure_origin_table()
        return {r["path"]: dict(r) for r in self.query("SELECT * FROM file_origins")}

    # ------------------------------------------------------------ forfattere fundet i filernes indhold
    def _ensure_content_table(self) -> None:
        self.conn.execute("CREATE TABLE IF NOT EXISTS content_authors (path TEXT PRIMARY KEY, mtime REAL NOT NULL, "
                          "size INTEGER NOT NULL, found TEXT NOT NULL)")

    def content_authors(self) -> dict[str, tuple[float, int, list]]:
        """sti -> (ændret, størrelse, [(værdi, slags, hvor)]) – så filer kun læses igen, når de er ændret."""
        import json
        self._ensure_content_table()
        out = {}
        for r in self.query("SELECT * FROM content_authors"):
            try:
                out[r["path"]] = (r["mtime"], r["size"], [tuple(x) for x in json.loads(r["found"])])
            except ValueError:
                continue
        return out

    def save_content_authors(self, items: dict[str, tuple[float, int, list]]) -> None:
        import json
        self._ensure_content_table()
        with self.transaction():
            self.conn.executemany(
                "INSERT INTO content_authors(path, mtime, size, found) VALUES (?, ?, ?, ?) ON CONFLICT(path) DO UPDATE "
                "SET mtime = excluded.mtime, size = excluded.size, found = excluded.found",
                [(k.lower(), m, s, json.dumps(f, ensure_ascii=False)) for k, (m, s, f) in items.items()])

    def manual_initials(self) -> dict[str, str]:
        self._ensure_initials_tables()
        return {r["path"]: r["initials"] for r in self.query("SELECT path, initials FROM file_initials")}

    def set_manual_initials(self, paths: Iterable[str], initials: str) -> None:
        from datetime import datetime
        self._ensure_initials_tables()
        now = datetime.now().isoformat(timespec="seconds")
        with self.transaction():
            for p in paths:
                key = str(p).lower()
                if initials:
                    self.conn.execute("INSERT INTO file_initials(path, initials, updated_at) VALUES (?, ?, ?) "
                                      "ON CONFLICT(path) DO UPDATE SET initials = excluded.initials, "
                                      "updated_at = excluded.updated_at", (key, initials.upper(), now))
                else:
                    self.conn.execute("DELETE FROM file_initials WHERE path = ?", (key,))

    # ------------------------------------------------------------ hvem har lagt filen ind
    def _ensure_upload_table(self) -> None:
        self.conn.execute("CREATE TABLE IF NOT EXISTS file_uploads (path TEXT PRIMARY KEY, by TEXT NOT NULL, "
                          "at TEXT NOT NULL, how TEXT, source TEXT)")

    def record_upload(self, path, by: str, at: str, how: str = "", source: str = "",
                      keep_earliest: bool = True) -> bool:
        """Husk hvem der lagde filen ind i projektet og hvornår. Den første (ældste) registrering vinder.
        Returnerer True, hvis noget blev gemt."""
        self._ensure_upload_table()
        key = str(path).lower()
        row = self.query_one("SELECT at FROM file_uploads WHERE path = ?", (key,))
        if row and keep_earliest and row["at"] <= at:
            return False
        self.conn.execute("INSERT INTO file_uploads(path, by, at, how, source) VALUES (?, ?, ?, ?, ?) "
                          "ON CONFLICT(path) DO UPDATE SET by = excluded.by, at = excluded.at, how = excluded.how, "
                          "source = excluded.source", (key, by.upper(), at, how, source))
        return True

    def uploads(self) -> dict[str, dict]:
        """sti (små bogstaver) -> {by, at, how, source}."""
        self._ensure_upload_table()
        return {r["path"]: dict(r) for r in self.query("SELECT * FROM file_uploads")}

    # ------------------------------------------------------------ læring af placeringer
    def _ensure_placement_table(self) -> None:
        self.conn.execute("CREATE TABLE IF NOT EXISTS placement_learning (token TEXT NOT NULL, code TEXT NOT NULL, "
                          "hits INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL, PRIMARY KEY (token, code))")

    def learn_placement(self, tokens: Iterable[str], code: str) -> None:
        """Brugeren har lagt en fil med disse ord i `code` (rettet forslaget eller sluppet den på mappen)."""
        from datetime import datetime
        self._ensure_placement_table()
        now = datetime.now().isoformat(timespec="seconds")
        with self.transaction():
            for t in set(tokens):
                self.conn.execute("INSERT INTO placement_learning(token, code, hits, updated_at) VALUES (?, ?, 1, ?) "
                                  "ON CONFLICT(token, code) DO UPDATE SET hits = hits + 1, updated_at = excluded.updated_at",
                                  (t, code, now))

    def placement_votes(self, tokens: Iterable[str]) -> dict[str, dict[str, int]]:
        """{ord: {mappekode: antal gange}} for de ord, der er lært."""
        self._ensure_placement_table()
        tokens = list(set(tokens))
        out: dict[str, dict[str, int]] = {}
        for i in range(0, len(tokens), 200):
            chunk = tokens[i:i + 200]
            marks = ",".join("?" * len(chunk))
            for r in self.query(f"SELECT token, code, hits FROM placement_learning WHERE token IN ({marks})", chunk):
                out.setdefault(r["token"], {})[r["code"]] = r["hits"]
        return out

    def manual_initials_with_time(self) -> dict[str, tuple[str, str]]:
        self._ensure_initials_tables()
        return {r["path"]: (r["initials"], r["updated_at"])
                for r in self.query("SELECT path, initials, updated_at FROM file_initials")}

    def initials_rules_with_time(self) -> dict[str, tuple[str, str]]:
        self._ensure_initials_tables()
        return {r["folder"]: (r["initials"], r["updated_at"])
                for r in self.query("SELECT folder, initials, updated_at FROM initials_rules")}

    def set_manual_initials_at(self, path: str, initials: str, at: str) -> None:
        """Rettelse hentet fra holdet (team_share) – beholder holdets tidspunkt."""
        self._ensure_initials_tables()
        key = str(path).lower()
        if initials:
            self.conn.execute("INSERT INTO file_initials(path, initials, updated_at) VALUES (?, ?, ?) "
                              "ON CONFLICT(path) DO UPDATE SET initials = excluded.initials, "
                              "updated_at = excluded.updated_at", (key, initials.upper(), at))
        else:
            self.conn.execute("DELETE FROM file_initials WHERE path = ?", (key,))

    def set_initials_rule_at(self, folder: str, initials: str, at: str) -> None:
        self._ensure_initials_tables()
        key = str(folder).lower().rstrip("\\/")
        if initials:
            self.conn.execute("INSERT INTO initials_rules(folder, initials, updated_at) VALUES (?, ?, ?) "
                              "ON CONFLICT(folder) DO UPDATE SET initials = excluded.initials, "
                              "updated_at = excluded.updated_at", (key, initials.upper(), at))
        else:
            self.conn.execute("DELETE FROM initials_rules WHERE folder = ?", (key,))

    def initials_rules(self) -> dict[str, str]:
        self._ensure_initials_tables()
        return {r["folder"]: r["initials"] for r in self.query("SELECT folder, initials FROM initials_rules")}

    def set_initials_rule(self, folder: str, initials: str) -> None:
        from datetime import datetime
        self._ensure_initials_tables()
        key = str(folder).lower().rstrip("\\/")
        if initials:
            self.conn.execute("INSERT INTO initials_rules(folder, initials, updated_at) VALUES (?, ?, ?) "
                              "ON CONFLICT(folder) DO UPDATE SET initials = excluded.initials, "
                              "updated_at = excluded.updated_at",
                              (key, initials.upper(), datetime.now().isoformat(timespec="seconds")))
        else:
            self.conn.execute("DELETE FROM initials_rules WHERE folder = ?", (key,))

    def get_meta(self, key: str, default: str = "") -> str:
        row = self.query_one("SELECT value FROM meta WHERE key = ?", (key,))
        return row["value"] if row and row["value"] is not None else default

    def set_meta(self, key: str, value: str) -> None:
        self.conn.execute("INSERT INTO meta(key, value) VALUES(?, ?) "
                          "ON CONFLICT(key) DO UPDATE SET value = excluded.value", (key, value))

    def is_empty(self) -> bool:
        row = self.query_one("SELECT COUNT(*) AS n FROM folders")
        return not row or row["n"] == 0

    def clear_data(self) -> None:
        # (oprettes også her, så en database fra før v2.3 kan genindlæses)
        self.conn.execute("CREATE TABLE IF NOT EXISTS folder_structures (structure TEXT NOT NULL, level INTEGER "
                          "NOT NULL, code TEXT, name TEXT NOT NULL, path TEXT NOT NULL, sort INTEGER NOT NULL)")
        for table in DATA_TABLES:
            self.conn.execute(f"DELETE FROM {table}")

    # ------------------------------------------------------------ mappestrukturer (Molio A104c)
    def structures(self) -> list[tuple[str, int]]:
        """[(navn, antal mapper)] for de mappestrukturer, Excel-arket indeholder (fx Molios A104c)."""
        try:
            rows = self.query("SELECT structure, COUNT(*) AS n, MIN(sort) AS s FROM folder_structures "
                              "GROUP BY structure ORDER BY s")
        except sqlite3.OperationalError:
            return []
        return [(r["structure"], r["n"]) for r in rows]

    def structure_rows(self, structure: str) -> list[sqlite3.Row]:
        try:
            return self.query("SELECT * FROM folder_structures WHERE structure = ? ORDER BY sort", (structure,))
        except sqlite3.OperationalError:
            return []

    def stats(self) -> dict[str, int]:
        result = {}
        for table in ("folders", "documents", "codes", "examples", "disciplines", "knowledge_areas", "favorites"):
            result[table] = self.query_one(f"SELECT COUNT(*) AS n FROM {table}")["n"]
        return result

    # ------------------------------------------------------------ navne-cache
    def _names(self) -> dict[str, dict[str, str]]:
        if self._name_cache is None:
            cache: dict[str, dict[str, str]] = {"folder": {}, "code": {}, "discipline": {}, "knowledge_area": {}}
            for r in self.query("SELECT code, name FROM folders"):
                cache["folder"][r["code"]] = r["name"]
            for r in self.query("SELECT code, name FROM disciplines"):
                cache["discipline"][r["code"]] = r["name"]
            for r in self.query("SELECT code, name FROM knowledge_areas"):
                cache["knowledge_area"][r["code"]] = r["name"]
            for r in self.query("SELECT code, name, aliases FROM codes WHERE code IS NOT NULL ORDER BY sort_order"):
                cache["code"].setdefault(code_key(r["code"]), r["name"])
                for alias in (r["aliases"] or "").split(","):
                    if alias.strip():
                        cache["code"].setdefault(code_key(alias), r["name"])
            self._name_cache = cache
        return self._name_cache

    def folder_name(self, code: str | None) -> str:
        return self._names()["folder"].get(code or "", "")

    def code_name(self, code: str | None) -> str:
        if not code:
            return ""
        names = self._names()
        for bucket in ("folder", "discipline", "knowledge_area"):
            if code in names[bucket]:
                return names[bucket][code]
        return names["code"].get(code_key(code), "")

    def canonical_code(self, code: str | None) -> str | None:
        """Finder den officielle skrivemåde af en kode (fx 'Y70' -> 'Y070')."""
        if not code:
            return None
        key = code_key(code)
        row = self.query_one("SELECT code FROM codes WHERE code IS NOT NULL AND "
                             "(UPPER(code) = ? OR (',' || UPPER(IFNULL(aliases, '')) || ',') LIKE ?)",
                             (code.upper(), f"%,{code.upper()},%"))
        if row:
            return row["code"]
        for r in self.query("SELECT code FROM codes WHERE code IS NOT NULL"):
            if code_key(r["code"]) == key:
                return r["code"]
        return code

    # ----------------------------------------------------------------- mapper
    def folders(self) -> list[sqlite3.Row]:
        rows = self.query("SELECT * FROM folders")
        return sorted(rows, key=lambda r: folder_sort_key(r["code"]))

    def folder(self, code: str) -> sqlite3.Row | None:
        return self.query_one("SELECT * FROM folders WHERE code = ?", (code,))

    def child_folders(self, code: str) -> list[sqlite3.Row]:
        rows = self.query("SELECT * FROM folders WHERE parent_code = ?", (code,))
        return sorted(rows, key=lambda r: folder_sort_key(r["code"]))

    def folder_path(self, code: str | None) -> list[tuple[str, str]]:
        path: list[tuple[str, str]] = []
        seen = set()
        while code and code not in seen:
            seen.add(code)
            row = self.folder(code)
            if not row:
                break
            path.insert(0, (row["code"], row["name"]))
            code = row["parent_code"]
        return path

    def related_folders(self, code: str) -> list[sqlite3.Row]:
        keys = [r["to_key"] for r in self.query(
            "SELECT to_key FROM relations WHERE from_type='folder' AND from_key=? AND to_type='folder' "
            "AND relation='related' ORDER BY weight DESC", (code,))]
        keys += [r["from_key"] for r in self.query(
            "SELECT from_key FROM relations WHERE to_type='folder' AND to_key=? AND from_type='folder' "
            "AND relation='related'", (code,))]
        result, seen = [], {code}
        for key in keys:
            if key in seen:
                continue
            seen.add(key)
            row = self.folder(key)
            if row:
                result.append(row)
        return result

    def documents_in_folder(self, code: str, include_children: bool = True) -> list[sqlite3.Row]:
        if include_children:
            return self.query("SELECT * FROM documents WHERE folder_code = ? OR folder_code LIKE ? "
                              "ORDER BY folder_code, name", (code, f"{code}.%"))
        return self.query("SELECT * FROM documents WHERE folder_code = ? ORDER BY name", (code,))

    def examples_in_folder(self, code: str, include_children: bool = True) -> list[sqlite3.Row]:
        if include_children:
            return self.query("SELECT * FROM examples WHERE folder_code = ? OR folder_code LIKE ? ORDER BY id",
                              (code, f"{code}.%"))
        return self.query("SELECT * FROM examples WHERE folder_code = ? ORDER BY id", (code,))

    def codes_pointing_to_folder(self, code: str) -> list[sqlite3.Row]:
        return self.query("SELECT * FROM codes WHERE folder_code = ? AND entity_type = 'code' ORDER BY family, code",
                          (code,))

    # --------------------------------------------------------------- koder
    def code_families(self) -> list[sqlite3.Row]:
        return self.query("SELECT cf.*, (SELECT COUNT(*) FROM codes c WHERE c.family = cf.family) AS n "
                          "FROM code_families cf ORDER BY sort_order, family")

    def code_family(self, family: str) -> sqlite3.Row | None:
        return self.query_one("SELECT * FROM code_families WHERE family = ?", (family,))

    def codes_by_family(self, family: str | None = None) -> list[sqlite3.Row]:
        if family:
            return self.query("SELECT * FROM codes WHERE family = ? ORDER BY sort_order, code", (family,))
        return self.query("SELECT * FROM codes ORDER BY family, sort_order, code")

    def code_row(self, code_id: int | str) -> sqlite3.Row | None:
        return self.query_one("SELECT * FROM codes WHERE id = ?", (int(code_id),))

    def codes_matching(self, code: str) -> list[sqlite3.Row]:
        key = code_key(code)
        return [r for r in self.query("SELECT * FROM codes WHERE code IS NOT NULL ORDER BY sort_order")
                if code_key(r["code"]) == key or key in {code_key(a) for a in (r["aliases"] or "").split(",") if a}]

    def discipline(self, code: str) -> sqlite3.Row | None:
        return self.query_one("SELECT * FROM disciplines WHERE code = ?", (code,))

    def disciplines(self) -> list[sqlite3.Row]:
        return self.query("SELECT * FROM disciplines ORDER BY sort_order, code")

    def knowledge_area(self, code: str) -> sqlite3.Row | None:
        return self.query_one("SELECT * FROM knowledge_areas WHERE code = ?", (code,))

    def knowledge_areas(self) -> list[sqlite3.Row]:
        return self.query("SELECT * FROM knowledge_areas ORDER BY sort_order, code")

    def phases(self) -> list[sqlite3.Row]:
        rows = self.query("SELECT * FROM codes WHERE family = 'A' AND code IS NOT NULL ORDER BY sort_order")
        seen, result = set(), []
        for r in rows:
            if r["code"] not in seen:
                seen.add(r["code"])
                result.append(r)
        return result

    def examples_using_code(self, code: str, limit: int = 30) -> list[sqlite3.Row]:
        return self.query(
            "SELECT e.* FROM relations r JOIN examples e ON e.id = CAST(r.from_key AS INTEGER) "
            "WHERE r.from_type = 'example' AND r.to_type = 'code' AND r.to_key = ? ORDER BY e.id LIMIT ?",
            (code, limit))

    def count_examples_using_code(self, code: str) -> int:
        row = self.query_one("SELECT COUNT(*) AS n FROM relations WHERE from_type='example' AND to_type='code' "
                             "AND to_key = ?", (code,))
        return row["n"] if row else 0

    def documents_with_code(self, column: str, code: str) -> list[sqlite3.Row]:
        if column not in ("knowledge_area_code", "discipline_code", "drawing_type_code"):
            raise ValueError(column)
        return self.query(f"SELECT * FROM documents WHERE {column} = ? ORDER BY name", (code,))

    def documents_in_phase(self, phase: str, limit: int = 40) -> list[sqlite3.Row]:
        return self.query("SELECT * FROM documents WHERE (',' || IFNULL(phase_codes, '') || ',') LIKE ? "
                          "ORDER BY folder_code, name LIMIT ?", (f"%,{phase},%", limit))

    # ------------------------------------------------------------ dokumenter
    def document(self, doc_id: int | str) -> sqlite3.Row | None:
        return self.query_one("SELECT * FROM documents WHERE id = ?", (int(doc_id),))

    def documents(self) -> list[sqlite3.Row]:
        return self.query("SELECT * FROM documents ORDER BY name")

    def related_documents(self, doc_id: int | str) -> list[sqlite3.Row]:
        key = str(doc_id)
        ids = [r["to_key"] for r in self.query(
            "SELECT to_key FROM relations WHERE from_type='document' AND from_key=? AND to_type='document'", (key,))]
        ids += [r["from_key"] for r in self.query(
            "SELECT from_key FROM relations WHERE to_type='document' AND to_key=? AND from_type='document'", (key,))]
        result, seen = [], {key}
        for i in ids:
            if i in seen:
                continue
            seen.add(i)
            row = self.document(i)
            if row:
                result.append(row)
        return result

    def example(self, example_id: int | str) -> sqlite3.Row | None:
        return self.query_one("SELECT * FROM examples WHERE id = ?", (int(example_id),))

    def examples(self) -> list[sqlite3.Row]:
        return self.query("SELECT * FROM examples ORDER BY id")

    # -------------------------------------------------------------- begreber
    def concepts(self) -> list[dict]:
        result = []
        for r in self.query("SELECT * FROM concepts ORDER BY key"):
            targets = self.query("SELECT to_type, to_key, weight FROM relations WHERE from_type='concept' "
                                 "AND from_key=? AND relation='concerns' ORDER BY weight DESC", (r["key"],))
            result.append({
                "key": r["key"], "label": r["label"], "emoji": r["emoji"],
                "terms": json.loads(r["terms"]),
                "targets": [(t["to_type"], t["to_key"], t["weight"]) for t in targets],
            })
        return result

    # ------------------------------------------------------------- favoritter
    def stable_key(self, entity_type: str, key: str) -> str | None:
        """Nøgle der overlever genindlæsning (id'er ændres ved import)."""
        if entity_type in (FOLDER, DISCIPLINE, KNOWLEDGE_AREA):
            return key
        if entity_type == DOCUMENT:
            row = self.document(key)
            return f"{row['doc_kind']}|{row['name']}" if row else None
        if entity_type == EXAMPLE:
            row = self.example(key)
            return f"{row['sheet']}|{row['name']}" if row else None
        if entity_type == CODE:
            row = self.code_row(key)
            return f"{row['category']}|{row['code'] or row['name']}" if row else None
        return None

    def resolve_stable_key(self, entity_type: str, stable: str) -> str | None:
        if entity_type in (FOLDER, DISCIPLINE, KNOWLEDGE_AREA):
            table = {FOLDER: "folders", DISCIPLINE: "disciplines", KNOWLEDGE_AREA: "knowledge_areas"}[entity_type]
            row = self.query_one(f"SELECT code FROM {table} WHERE code = ?", (stable,))
            return row["code"] if row else None
        first, _, second = stable.partition("|")
        if entity_type == DOCUMENT:
            row = self.query_one("SELECT id FROM documents WHERE doc_kind = ? AND name = ?", (first, second))
        elif entity_type == EXAMPLE:
            row = self.query_one("SELECT id FROM examples WHERE sheet = ? AND name = ?", (first, second))
        elif entity_type == CODE:
            row = self.query_one("SELECT id FROM codes WHERE category = ? AND (code = ? OR (code IS NULL AND name = ?))",
                                 (first, second, second))
        else:
            row = None
        return str(row["id"]) if row else None

    def favorites(self) -> list[sqlite3.Row]:
        return self.query("SELECT * FROM favorites ORDER BY created_at DESC")

    def is_favorite(self, entity_type: str, key: str) -> bool:
        stable = self.stable_key(entity_type, key)
        if not stable:
            return False
        return self.query_one("SELECT 1 FROM favorites WHERE item_type = ? AND item_key = ?",
                              (entity_type, stable)) is not None

    def add_favorite(self, entity_type: str, key: str, label: str) -> None:
        stable = self.stable_key(entity_type, key)
        if not stable:
            return
        self.conn.execute("INSERT OR IGNORE INTO favorites(item_type, item_key, label, created_at) VALUES(?,?,?,?)",
                          (entity_type, stable, label, datetime.now().isoformat(timespec="seconds")))
        self.conn.commit()

    def remove_favorite(self, entity_type: str, key: str) -> None:
        stable = self.stable_key(entity_type, key)
        if stable:
            self.conn.execute("DELETE FROM favorites WHERE item_type = ? AND item_key = ?", (entity_type, stable))
            self.conn.commit()

    def remove_favorite_by_id(self, fav_id: int) -> None:
        self.conn.execute("DELETE FROM favorites WHERE id = ?", (fav_id,))
        self.conn.commit()

    # --------------------------------------------------------------- projekter
    def projects(self) -> list[sqlite3.Row]:
        return self.query("SELECT * FROM projects ORDER BY name COLLATE NOCASE")

    def project(self, project_db_id: int) -> sqlite3.Row | None:
        return self.query_one("SELECT * FROM projects WHERE id = ?", (project_db_id,))

    def add_project(self, name: str, project_id: str, root_path: str) -> int:
        self.conn.execute(
            "INSERT INTO projects(name, project_id, root_path, created_at) VALUES(?,?,?,?) "
            "ON CONFLICT(root_path) DO UPDATE SET name = excluded.name, project_id = excluded.project_id",
            (name, project_id, root_path, datetime.now().isoformat(timespec="seconds")))
        return self.query_one("SELECT id FROM projects WHERE root_path = ?", (root_path,))["id"]

    def update_project(self, project_db_id: int, name: str, project_id: str) -> None:
        self.conn.execute("UPDATE projects SET name = ?, project_id = ? WHERE id = ?",
                          (name, project_id, project_db_id))

    def move_project_root(self, project_db_id: int, old_root: str, new_root: str) -> None:
        """Projektmappen er flyttet: ret projektets sti og alt, der huskes pr. fil (initialer, regler, oprindelse,
        fund i filernes indhold), så det følger med."""
        self._ensure_initials_tables()
        self._ensure_origin_table()
        self._ensure_content_table()
        self._ensure_upload_table()
        old = str(old_root).rstrip("\\/")
        n = len(old)
        with self.transaction():
            self.conn.execute("UPDATE projects SET root_path = ? WHERE id = ?", (str(new_root), project_db_id))
            for table, col in (("file_initials", "path"), ("initials_rules", "folder"), ("file_origins", "path"),
                               ("content_authors", "path"), ("file_dates", "path"), ("file_uploads", "path")):
                lowered = table in ("file_origins", "content_authors", "file_dates", "file_uploads")  # små bogstaver
                new = str(new_root).rstrip("\\/")
                self.conn.execute(
                    f"UPDATE OR REPLACE {table} SET {col} = ? || substr({col}, ?) "
                    f"WHERE lower(substr({col}, 1, ?)) = lower(?) AND (length({col}) = ? OR substr({col}, ?, 1) IN ('\\', '/'))",
                    (new.lower() if lowered else new, n + 1, n, old, n, n + 1))

    def remove_project(self, project_db_id: int) -> None:
        """Fjerner kun projektet fra listen – filerne på disken røres ikke."""
        self.conn.execute("DELETE FROM projects WHERE id = ?", (project_db_id,))

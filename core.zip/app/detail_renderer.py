"""HTML til detaljevisning og læringsmodul (vises i QTextBrowser)."""
from __future__ import annotations

import json
from html import escape

import theme
from database import Database
from models import (CODE, DISCIPLINE, DOCUMENT, ENTITY_ICONS, EXAMPLE, FOLDER, KNOWLEDGE_AREA, Classification,
                    EntityRef)

KIND_LABELS = {"document": "Dokument", "drawing": "Tegning", "model": "Model/CAD-fil"}
KIND_ICONS = {"document": "📄", "drawing": "📐", "model": "🧊"}
ORIGIN_LABELS = {"excel": "Excel-arket", "knowledge": "Indbygget fagviden", "derived": "Udledt automatisk"}


def e(value) -> str:
    return escape(str(value if value is not None else ""))


class DetailRenderer:
    def __init__(self, db: Database):
        self.db = db

    # ------------------------------------------------------------------ fælles
    @property
    def p(self) -> dict:
        return theme.current_palette()

    def _page(self, body: str) -> str:
        p = self.p
        css = f"""
        body {{ color: {p['text']}; font-family: 'Segoe UI'; font-size: 10pt; }}
        h1 {{ font-size: 17pt; font-weight: 600; margin: 0px; }}
        h2 {{ font-size: 9pt; font-weight: 700; color: {p['accent']}; margin-top: 18px; margin-bottom: 4px; }}
        p {{ margin-top: 2px; margin-bottom: 6px; }}
        a {{ color: {p['link']}; text-decoration: none; }}
        .code {{ font-family: Consolas, 'Cascadia Mono', monospace; color: {p['accent']}; font-weight: 600; }}
        .mono {{ font-family: Consolas, 'Cascadia Mono', monospace; }}
        .muted {{ color: {p['muted']}; }}
        .chip {{ background-color: {p['chip']}; color: {p['text']}; }}
        .big {{ font-size: 12pt; }}
        .ok {{ color: {p['success']}; }}
        .warn {{ color: {p['warning']}; }}
        td {{ padding: 3px 14px 3px 0px; vertical-align: top; }}
        td.k {{ color: {p['muted']}; }}
        """
        return f"<html><head><style>{css}</style></head><body>{body}</body></html>"

    def link(self, ref: EntityRef, text: str) -> str:
        return f'<a href="{ref.link()}">{e(text)}</a>'

    def folder_link(self, code: str | None, with_name: bool = True) -> str:
        if not code:
            return '<span class="muted">Ikke placeret</span>'
        name = self.db.folder_name(code)
        label = f"{code} {name}" if with_name and name else code
        return self.link(EntityRef(FOLDER, code), label)

    def code_link(self, code: str | None) -> str:
        """Link til en kode uanset type (mappe, fagdisciplin, vidensområde eller værdikode)."""
        if not code:
            return '<span class="muted">–</span>'
        if self.db.folder(code):
            return self.folder_link(code)
        if self.db.discipline(code):
            return self.link(EntityRef(DISCIPLINE, code), f"{code} {self.db.code_name(code)}")
        if self.db.knowledge_area(code):
            return self.link(EntityRef(KNOWLEDGE_AREA, code), f"{code} {self.db.code_name(code)}")
        rows = self.db.codes_matching(code)
        if rows:
            return self.link(EntityRef(CODE, str(rows[0]["id"])), f"{rows[0]['code']} {rows[0]['name']}")
        return f'<span class="code">{e(code)}</span>'

    def doc_link(self, row) -> str:
        icon = KIND_ICONS.get(row["doc_kind"], "📄")
        return f'{icon} {self.link(EntityRef(DOCUMENT, str(row["id"])), row["name"])}'

    def example_link(self, row) -> str:
        return f'🧾 {self.link(EntityRef(EXAMPLE, str(row["id"])), row["name"])}'

    @staticmethod
    def chips(words) -> str:
        items = [w.strip() for w in words if w and w.strip()]
        return " ".join(f'<span class="chip">&nbsp;{e(w)}&nbsp;</span>' for w in items)

    @staticmethod
    def section(title: str) -> str:
        return f"<h2>{e(title.upper())}</h2>"

    @staticmethod
    def bullet_list(items: list[str]) -> str:
        if not items:
            return '<p class="muted">Ingen registreret.</p>'
        return "<ul style='margin-top:0px; margin-left:-20px;'>" + "".join(f"<li>{i}</li>" for i in items) + "</ul>"

    def kv_table(self, rows: list[tuple[str, str]]) -> str:
        cells = "".join(f'<tr><td class="k">{e(k)}</td><td>{v}</td></tr>' for k, v in rows if v)
        return f"<table cellspacing='0'>{cells}</table>"

    def breadcrumb(self, code: str) -> str:
        path = self.db.folder_path(code)
        return " → ".join(self.link(EntityRef(FOLDER, c), n) for c, n in path)

    def tree_path_text(self, path: list[tuple[str, str]]) -> str:
        """Tekstlig mappesti som i Stifinder: HOVEDMAPPE └─ Undermappe."""
        lines = []
        for i, (code, name) in enumerate(path):
            prefix = "" if i == 0 else "&nbsp;" * (4 * (i - 1)) + "└─ "
            lines.append(f"{prefix}{e(name)} <span class='muted'>({e(code)})</span>")
        return "<br>".join(lines)

    def phase_names(self, phases: str | list[str] | None) -> list[str]:
        if isinstance(phases, str):
            phases = [x for x in phases.split(",") if x]
        return [f"{self.db.code_name(ph) or ph} ({ph})" for ph in phases or []]

    def title_for(self, ref: EntityRef) -> tuple[str, str]:
        """(kode, titel) – bruges til favoritter og kopiering."""
        t, key = ref.entity_type, ref.key
        if t == FOLDER:
            return key, self.db.folder_name(key)
        if t in (DISCIPLINE, KNOWLEDGE_AREA):
            return key, self.db.code_name(key)
        if t == DOCUMENT:
            row = self.db.document(key)
            return (row["folder_code"] or "", row["name"]) if row else ("", "")
        if t == EXAMPLE:
            row = self.db.example(key)
            return (row["generated_name"] or "", row["name"]) if row else ("", "")
        if t == CODE:
            row = self.db.code_row(key)
            return (row["code"] or "", row["name"]) if row else ("", "")
        return "", ""

    # ---------------------------------------------------------------- dispatch
    def render(self, ref: EntityRef) -> str:
        renderers = {
            FOLDER: self.render_folder, DOCUMENT: self.render_document, EXAMPLE: self.render_example,
            CODE: self.render_code, DISCIPLINE: self.render_discipline, KNOWLEDGE_AREA: self.render_knowledge_area,
        }
        try:
            body = renderers[ref.entity_type](ref.key)
        except (KeyError, TypeError, ValueError):
            body = None
        if body is None:
            body = "<p class='muted'>Elementet findes ikke længere i databasen. Prøv at genindlæse.</p>"
        return self._page(body)

    def render_welcome(self, text: str = "") -> str:
        text = text or "Vælg et resultat for at se detaljer, forklaring og relaterede mapper."
        return self._page(f"<p class='muted' style='margin-top:40px;' align='center'>{e(text)}</p>")

    # ------------------------------------------------------------------ mappe
    def render_folder(self, code: str) -> str | None:
        f = self.db.folder(code)
        if not f:
            return None
        parent = self.db.folder(f["parent_code"]) if f["parent_code"] else None
        children = self.db.child_folders(code)
        docs = self.db.documents_in_folder(code, include_children=bool(children))
        examples = self.db.examples_in_folder(code, include_children=bool(children))
        related = self.db.related_folders(code)
        file_codes = self.db.codes_pointing_to_folder(code)

        out = [f"<p class='muted'>{ENTITY_ICONS[FOLDER]} Mappe · Indholdstype</p>",
               f"<h1><span class='code'>{e(code)}</span>&nbsp; {e(f['name'])}</h1>",
               f"<p>{self.breadcrumb(code)} &nbsp; <a href='tree:{e(code)}'>Vis i mappestruktur ›</a></p>"]

        out.append(self.section("Hvad er det?"))
        if f["purpose"]:
            out.append(f"<p>{e(f['purpose'])}</p>")
        if parent:
            out.append(f"<p class='muted'>Undermappe til {self.folder_link(parent['code'])}.</p>")
        else:
            out.append(f"<p class='muted'>Hovedmappe i A104 med {len(children)} undermapper.</p>")

        out.append(self.section("Hvornår bruges det?"))
        phases = self.phase_names(f["phases"])
        if phases:
            out.append(f"<p>Typisk i faserne: {e(', '.join(phases))}.</p>")
        else:
            out.append("<p class='muted'>I alle faser, når der opstår dokumenter af denne type.</p>")
        if file_codes:
            items = ", ".join(self.link(EntityRef(CODE, str(c["id"])), f"{c['code'] or ''} {c['name']}".strip())
                              for c in file_codes[:12])
            out.append(f"<p>Fil- og dokumentformer der arkiveres her: {items}</p>")

        if children:
            out.append(self.section("Undermapper"))
            out.append(self.bullet_list([f"{self.folder_link(c['code'])}" for c in children]))

        out.append(self.section("Typiske dokumenter"))
        items = []
        for d in docs[:30]:
            where = f" <span class='muted'>({e(d['folder_code'])})</span>" if d["folder_code"] != code else ""
            items.append(self.doc_link(d) + where)
        out.append(self.bullet_list(items))
        if len(docs) > 30:
            out.append(f"<p class='muted'>… og {len(docs) - 30} flere.</p>")

        out.append(self.section("Eksempler fra praksis"))
        if examples:
            rows = []
            for x in examples[:12]:
                rows.append(f"{self.example_link(x)}<br><span class='mono muted'>{e(x['generated_name'])}</span>")
            out.append(self.bullet_list(rows))
        if code == "C07.01":
            out.append("<p>Tegningsnummer efter Excel-arket: <span class='mono'>K01_H1_N01</span> "
                       "(Vidensområde_Afbildningstype_Løbenummer).</p>")
        elif code == "C07.02":
            out.append("<p>Modelfilnavn efter Excel-arket: <span class='mono'>Projekt-ID_A4_F02_K01_&lt;Navn&gt;</span> "
                       "(Projekt-ID_Fase_Filtype_Vidensområde_Navn).</p>")
        elif not children and code[:1] in "CD":
            out.append(f"<p>Filnavn efter skabelonen i Excel-arket: <span class='mono'>{e(code)}_K01_&lt;Dokumentnavn&gt;</span></p>")
        elif not examples:
            out.append("<p class='muted'>Ingen udfyldte eksempler i Excel-arket for denne mappe.</p>")

        out.append(self.section("Relaterede mapper"))
        out.append(self.bullet_list([self.folder_link(r["code"]) for r in related]))

        if f["keywords"]:
            out.append(self.section("Nøgleord"))
            out.append(f"<p>{self.chips(f['keywords'].split(','))}</p>")
        return "".join(out)

    # --------------------------------------------------------------- dokument
    def render_document(self, key: str) -> str | None:
        d = self.db.document(key)
        if not d:
            return None
        kind = d["doc_kind"]
        out = [f"<p class='muted'>{KIND_ICONS.get(kind, '📄')} {KIND_LABELS.get(kind, 'Dokument')}</p>",
               f"<h1>{e(d['name'])}</h1>"]
        out.append(self.section("Placering"))
        if d["folder_code"]:
            out.append(f"<p class='big'>{self.folder_link(d['folder_code'])}</p>")
            out.append(f"<p>{self.tree_path_text(self.db.folder_path(d['folder_code']))}</p>")
        else:
            out.append("<p class='muted'>Excel-arket angiver ikke en placering. Brug Dokumentfinderen for et forslag.</p>")

        out.append(self.section("Forklaring"))
        if d["explanation"]:
            out.append(f"<p>{e(d['explanation'])}</p>")
        elif d["folder_code"]:
            f = self.db.folder(d["folder_code"])
            purpose = (f["purpose"] or "") if f else ""
            out.append(f"<p>{e(d['name'])} hører til {e(d['folder_code'])} {e(self.db.folder_name(d['folder_code']))}. "
                       f"{e(purpose)}</p>")

        rows = [
            ("Vidensområde", self.code_link(d["knowledge_area_code"]) if d["knowledge_area_code"] else ""),
            ("Fagdisciplin", self.code_link(d["discipline_code"]) if d["discipline_code"] else ""),
            ("Afbildningstype", self.code_link(d["drawing_type_code"]) if d["drawing_type_code"] else ""),
            ("Faser", e(", ".join(self.phase_names(d["phase_codes"])))),
            ("Kilde", e(ORIGIN_LABELS.get(d["origin"], d["origin"]))
             + (f" · placering: {e(ORIGIN_LABELS.get(d['placement_source'], d['placement_source']))}"
                if d["placement_source"] and d["placement_source"] != d["origin"] else "")),
        ]
        out.append(self.section("Klassifikation"))
        out.append(self.kv_table(rows))

        if d["folder_code"] and kind == "document":
            out.append(self.section("Forslag til filnavn"))
            k = d["knowledge_area_code"] or "K01"
            out.append(f"<p class='mono big'>{e(d['folder_code'])}_{e(k)}_{e(d['name'])}</p>")

        related = self.db.related_documents(d["id"])
        out.append(self.section("Relaterede dokumenter"))
        out.append(self.bullet_list([self.doc_link(r) + f" <span class='muted'>({e(r['folder_code'] or '–')})</span>"
                                     for r in related]))
        if d["folder_code"]:
            siblings = [r for r in self.db.documents_in_folder(d["folder_code"], include_children=False)
                        if r["id"] != d["id"]]
            if siblings:
                out.append(self.section("Andre dokumenter i samme mappe"))
                out.append(self.bullet_list([self.doc_link(r) for r in siblings[:12]]))
        return "".join(out)

    # ---------------------------------------------------------------- eksempel
    def render_example(self, key: str) -> str | None:
        x = self.db.example(key)
        if not x:
            return None
        out = [f"<p class='muted'>🧾 Eksempel fra Excel · ark »{e(x['sheet'])}« række {e(x['row_number'])}</p>",
               f"<h1>{e(x['name'])}</h1>"]
        label = "Tegningsnummer" if x["doc_kind"] == "drawing" else "Filnavn"
        out.append(self.section(label))
        out.append(f"<p class='mono big'>{e(x['generated_name'] or '–')}</p>")
        out.append(self.section("Opbygning"))
        rows = [
            ("Placering", self.folder_link(x["folder_code"]) if x["folder_code"] else ""),
            ("Fase (A)", self.code_link(x["phase_code"]) if x["phase_code"] else ""),
            ("Filtype (F)", self.code_link(x["file_type_code"]) if x["file_type_code"] else ""),
            ("Vidensområde (K)", self.code_link(x["knowledge_area_code"]) if x["knowledge_area_code"] else ""),
            ("Fagdisciplin (M)", self.code_link(x["discipline_code"]) if x["discipline_code"] else ""),
            ("Afbildningstype (H)", self.code_link(x["drawing_type_code"]) if x["drawing_type_code"] else ""),
            ("Etage (E)", self.code_link(x["floor_code"]) if x["floor_code"] else ""),
            ("Entreprise (Y)", self.code_link(x["contract_code"]) if x["contract_code"] else ""),
            ("Løbenummer (N)", e(x["serial_code"] or "")),
            ("Dokumentform", e(x["document_form"] or "")),
            ("Moderfil", f"<span class='mono'>{e(x['parent_file'])}</span>" if x["parent_file"] else ""),
            ("Arkivering", f"<span class='mono'>{e(x['archive_path'])}</span>" if x["archive_path"] else ""),
        ]
        out.append(self.kv_table(rows))
        if x["doc_kind"] == "drawing":
            out.append("<p class='muted'>Tegningsnummeret er opbygget som Vidensområde_Afbildningstype_Løbenummer. "
                       "Løbenummeret starter forfra for hvert vidensområde og hver afbildningstype.</p>")
        elif x["doc_kind"] == "model":
            out.append("<p class='muted'>Model- og CAD-filnavne er opbygget som Projekt-ID_Fase_Filtype_Vidensområde_Navn.</p>")
        else:
            out.append("<p class='muted'>Dokumentfilnavne er opbygget som Mappe_Vidensområde[_Entreprise]_Navn.</p>")
        try:
            raw = json.loads(x["raw_json"] or "{}")
        except ValueError:
            raw = {}
        if raw:
            out.append(self.section("Værdier i Excel-rækken"))
            out.append(self.kv_table([(k, e(v)) for k, v in raw.items()]))
        return "".join(out)

    # -------------------------------------------------------------------- kode
    def render_code(self, key: str) -> str | None:
        c = self.db.code_row(key)
        if not c:
            return None
        family = self.db.code_family(c["family"])
        out = [f"<p class='muted'>🏷 Kode · {e(c['category'])}</p>",
               f"<h1><span class='code'>{e(c['code'] or '')}</span>&nbsp; {e(c['name'])}</h1>"]
        out.append(self.section("Hvad er det?"))
        if family:
            out.append(f"<p><b>{e(c['family'])} = {e(family['name'])}.</b> {e(family['description'] or '')}</p>")
        if c["description"]:
            out.append(f"<p>{e(c['description'])}</p>")
        if c["aliases"]:
            out.append(f"<p class='muted'>Skrives også: {e(c['aliases'])}</p>")
        if c["folder_code"]:
            out.append(self.section("Placering"))
            out.append(f"<p>Filer af denne type arkiveres i {self.folder_link(c['folder_code'])}.</p>")

        if c["code"]:
            if c["family"] == "A":
                phase_folders = self.db.query("SELECT to_key FROM relations WHERE from_type='code' AND from_key=? "
                                              "AND relation='phase_folder'", (c["code"],))
                if phase_folders:
                    out.append(self.section("Mapper for fasen"))
                    out.append(self.bullet_list([self.folder_link(r["to_key"]) for r in phase_folders]))
                docs = self.db.documents_in_phase(c["code"])
                if docs:
                    out.append(self.section("Typiske dokumenter i fasen"))
                    out.append(self.bullet_list([self.doc_link(d) for d in docs[:20]]))
            out.append(self.section("Typiske anvendelser"))
            n = self.db.count_examples_using_code(c["code"])
            examples = self.db.examples_using_code(c["code"], 12)
            if examples:
                out.append(f"<p>Bruges i {n} eksempel{'er' if n != 1 else ''} i Excel-arket:</p>")
                out.append(self.bullet_list([f"{self.example_link(x)} <span class='mono muted'>{e(x['generated_name'])}</span>"
                                             for x in examples]))
            else:
                out.append("<p class='muted'>Koden bruges ikke i eksempelrækkerne i Excel-arket.</p>")
        siblings = [r for r in self.db.codes_by_family(c["family"]) if r["id"] != c["id"]
                    and r["category"] == c["category"]][:14]
        if siblings:
            out.append(self.section(f"Andre koder i {c['category']}"))
            out.append("<p>" + " · ".join(self.link(self._ref_for_code_row(r), f"{r['code'] or ''} {r['name']}".strip())
                                          for r in siblings) + "</p>")
        return "".join(out)

    @staticmethod
    def _ref_for_code_row(row) -> EntityRef:
        mapping = {"folder": FOLDER, "discipline": DISCIPLINE, "knowledge_area": KNOWLEDGE_AREA}
        entity = mapping.get(row["entity_type"])
        if entity and row["code"]:
            return EntityRef(entity, row["code"])
        return EntityRef(CODE, str(row["id"]))

    # --------------------------------------------------------- fagdisciplin
    def render_discipline(self, code: str) -> str | None:
        m = self.db.discipline(code)
        if not m:
            return None
        out = [f"<p class='muted'>🎓 Fagdisciplin (M)</p>",
               f"<h1><span class='code'>{e(code)}</span>&nbsp; {e(m['name'])}</h1>"]
        out.append(self.section("Hvad er det?"))
        out.append(f"<p>{e(m['description'] or '')}</p>")
        if m["keywords"]:
            out.append(f"<p>{self.chips(m['keywords'].split(','))}</p>")
        folders = self._concept_folders_for(DISCIPLINE, code)
        if folders:
            out.append(self.section("Relaterede mapper"))
            out.append(self.bullet_list([self.folder_link(f) for f in folders]))
        docs = self.db.documents_with_code("discipline_code", code)
        out.append(self.section("Typiske dokumenter"))
        out.append(self.bullet_list([self.doc_link(d) + f" <span class='muted'>({e(d['folder_code'] or '–')})</span>"
                                     for d in docs[:20]]))
        out.append(self._usage_section(code))
        return "".join(out)

    # ------------------------------------------------------- vidensområde
    def render_knowledge_area(self, code: str) -> str | None:
        k = self.db.knowledge_area(code)
        if not k:
            return None
        out = [f"<p class='muted'>🧭 Vidensområde (K)</p>",
               f"<h1><span class='code'>{e(code)}</span>&nbsp; {e(k['name'])}</h1>"]
        out.append(self.section("Hvad er det?"))
        out.append("<p>Vidensområdet angiver hvilket fagområde en fil eller tegning tilhører. Det indgår i "
                   "filnavne og tegningsnumre, fx <span class='mono'>"
                   f"{e(code)}_H1_N01</span>.</p>")
        if k["short_list"]:
            short = f" (kort navn: »{e(k['keywords'])}«)" if k["keywords"] else ""
            out.append(f"<p class='ok'>Med på den korte liste, der bruges på studiet{short}.</p>")
        folders = self._concept_folders_for(KNOWLEDGE_AREA, code)
        if folders:
            out.append(self.section("Relaterede mapper"))
            out.append(self.bullet_list([self.folder_link(f) for f in folders]))
        docs = self.db.documents_with_code("knowledge_area_code", code)
        out.append(self.section("Typiske dokumenter"))
        out.append(self.bullet_list([self.doc_link(d) + f" <span class='muted'>({e(d['folder_code'] or '–')})</span>"
                                     for d in docs[:20]]))
        out.append(self._usage_section(code))
        return "".join(out)

    def _concept_folders_for(self, entity_type: str, code: str) -> list[str]:
        concepts = [r["from_key"] for r in self.db.query(
            "SELECT from_key FROM relations WHERE from_type='concept' AND to_type=? AND to_key=?", (entity_type, code))]
        folders: list[str] = []
        for concept in concepts:
            for r in self.db.query("SELECT to_key FROM relations WHERE from_type='concept' AND from_key=? "
                                   "AND to_type='folder' ORDER BY weight DESC", (concept,)):
                if r["to_key"] not in folders:
                    folders.append(r["to_key"])
        return folders[:8]

    def _usage_section(self, code: str) -> str:
        n = self.db.count_examples_using_code(code)
        examples = self.db.examples_using_code(code, 10)
        if not examples:
            return ""
        return (self.section("Eksempler fra praksis") + f"<p>Bruges i {n} eksempler i Excel-arket, fx:</p>"
                + self.bullet_list([f"{self.example_link(x)} <span class='mono muted'>{e(x['generated_name'])}</span>"
                                    for x in examples]))

    # ------------------------------------------------------ dokumentguide
    def render_classification(self, c: Classification) -> str:
        if not c.best:
            return self._page(f"<p>{e(c.explanation)}</p>")
        kind_label = KIND_LABELS.get(c.doc_kind, "Dokument")
        out = [self.section("Mappe"), f"<p class='big'>{self.tree_path_text(c.folder_path)}</p>"]
        rows = [
            ("Placering", self.folder_link(c.best.folder_code)),
            ("Dokumenttype", e(kind_label)),
            ("Fase", self.code_link(c.phase[0]) if c.phase else "<span class='muted'>Ikke angivet – vælg den aktuelle fase</span>"),
            ("Fagdisciplin", self.code_link(c.discipline[0]) if c.discipline else "<span class='muted'>Ingen bestemt</span>"),
            ("Vidensområde", self.code_link(c.knowledge_area[0]) if c.knowledge_area else ""),
            ("Afbildningstype", self.code_link(c.drawing_type[0]) if c.drawing_type else ""),
            ("Genkendte begreber", e(", ".join(c.concepts)) if c.concepts else ""),
        ]
        out.append(self.section("Klassifikation"))
        out.append(self.kv_table(rows))
        out.append(self.section("Forklaring"))
        out.append(f"<p>{e(c.explanation)}</p>")
        if c.best.reasons:
            out.append("<p class='muted'>Begrundelse: " + e("; ".join(c.best.reasons)) + ".</p>")
        out.append(f"<p class='muted'>{e(c.filename_note)}</p>")

        if c.example:
            out.append(self.section("Sådan er det gjort i Excel-eksemplet"))
            ex_row = self.db.example(c.example.example_id)
            if ex_row:
                out.append(f"<p>{self.example_link(ex_row)} er placeret i {self.folder_link(c.example.folder_code)} "
                           f"med navnet <span class='mono'>{e(c.example.generated_name)}</span>.</p>")

        if c.alternatives:
            out.append(self.section("Alternative placeringer"))
            out.append(self.bullet_list([f"{self.folder_link(a.folder_code)} <span class='muted'>({a.probability} %)</span>"
                                         for a in c.alternatives]))
        out.append(self.section("Relaterede dokumenter"))
        out.append(self.bullet_list([
            f"📄 {self.link(EntityRef(DOCUMENT, str(i)), name)} <span class='muted'>({e(folder or '–')})</span>"
            for i, name, folder in c.related_documents]))
        return self._page("".join(out))

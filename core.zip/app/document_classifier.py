"""Offline dokumentassistent: "Hvor skal dokumentet ligge?"

Klassifikatoren samler evidens for hver mappe fra fire kilder og vægter dem:

1. Kendte dokumenttyper (fra Excel + indbygget fagviden) – stærkest ved eksakt match
2. Udfyldte eksempelrækker i Excel-arket (filnavne og tegningsnumre)
3. Mappenavne og nøgleord
4. Begreber (brand, KS, referat, ...) der peger på bestemte mapper

Evidensen omsættes til en sandsynlighed med softmax, så en klar vinder giver
høj sikkerhed, mens to næsten lige gode forslag giver lavere sikkerhed og
vises som alternativer. Der bruges ingen cloud-tjenester.
"""
from __future__ import annotations

import math
import re
from collections import defaultdict
from dataclasses import dataclass

from rapidfuzz import fuzz

import knowledge_base as kb
from database import Database
from models import DISCIPLINE, Classification, ExampleMatch, PlacementCandidate
from search_engine import QueryInfo, SearchEngine, normalize, tokenize

TEMPERATURE = 8.0
MAX_PROBABILITY = 98
INVALID_FILENAME_CHARS = re.compile(r'[<>:"/\\|?*]+')


def clean_phrase(text: str | None) -> str:
    return " ".join(t for t in tokenize(text) if t not in kb.STOPWORDS)


def similarity(query: str, target: str) -> tuple[float, bool]:
    """Lighed mellem renset forespørgsel og renset navn. Returnerer (score 0-100, eksakt)."""
    if not query or not target:
        return 0.0, False
    if query == target:
        return 100.0, True
    s1 = fuzz.token_sort_ratio(query, target)
    # Et kort navn tæller kun fuldt, hvis det står ordret i teksten ("kontor" må ikke matche "kontrakt")
    if 4 <= len(target) <= len(query):
        t2, q2 = target.replace("-", " "), query.replace("-", " ")
        if t2 in q2:
            s2 = 97.0
        else:
            pr = fuzz.partial_ratio(t2, q2)
            s2 = pr * 0.92 if pr >= 92 else pr * 0.8
    else:
        s2 = 0.0
    s3 = fuzz.partial_ratio(query, target) * 0.85 if len(query) >= 4 and len(query) < len(target) else 0.0
    return max(s1, s2, s3), False


@dataclass
class _Doc:
    id: int
    name: str
    norm: str
    folder: str | None
    kind: str
    k: str | None
    m: str | None
    phases: list[str]
    h: str | None
    explanation: str


@dataclass
class _Example:
    id: int
    name: str
    norm: str
    folder: str | None
    kind: str
    phase: str | None
    k: str | None
    m: str | None
    h: str | None
    f: str | None
    y: str | None
    serial: str | None
    generated: str


@dataclass
class _Folder:
    code: str
    name: str
    norm: str
    keywords: list[str]
    purpose: str


class DocumentClassifier:
    def __init__(self, db: Database, engine: SearchEngine):
        self.db = db
        self.engine = engine
        self.rebuild()

    def rebuild(self) -> None:
        db = self.db
        self.docs = [
            _Doc(d["id"], d["name"], clean_phrase(d["name"]), d["folder_code"], d["doc_kind"],
                 d["knowledge_area_code"], d["discipline_code"],
                 [p for p in (d["phase_codes"] or "").split(",") if p], d["drawing_type_code"],
                 d["explanation"] or "")
            for d in db.documents()
        ]
        self.examples = [
            _Example(e["id"], e["name"], clean_phrase(e["name"]), e["folder_code"], e["doc_kind"], e["phase_code"],
                     e["knowledge_area_code"], e["discipline_code"], e["drawing_type_code"], e["file_type_code"],
                     e["contract_code"], e["serial_code"], e["generated_name"] or "")
            for e in db.examples()
        ]
        self.folders = [
            _Folder(f["code"], f["name"], clean_phrase(f["name"]),
                    [clean_phrase(k) for k in (f["keywords"] or "").split(",") if k.strip()],
                    f["purpose"] or "")
            for f in db.folders()
        ]
        self.folder_codes = {f.code for f in self.folders}
        self.phases = [(p["code"], normalize(p["name"])) for p in db.phases()]

    # ----------------------------------------------------------------- hoved
    def _has_children(self, code: str) -> bool:
        return any(c.startswith(code + ".") for c in self.folder_codes)

    def classify(self, text: str, project_id: str = "", include_project_id: bool = False,
                 within: str | None = None) -> Classification:
        """Klassificerer en beskrivelse. `within` begrænser forslaget til en hovedmappes undermapper
        (bruges når en fil slippes på en hovedmappe); findes intet match der, bruges hele strukturen."""
        q = self.engine.analyze(text)
        qc = q.cleaned
        evidence: dict[str, list[tuple[float, str]]] = defaultdict(list)

        best_doc: tuple[float, _Doc] | None = None
        for d in self.docs:
            s, exact = similarity(qc, d.norm)
            if exact:
                s = 120.0
            if d.folder and s >= 60:
                evidence[d.folder].append((s, f"Dokumenttypen »{d.name}« placeres her"))
            if s >= 75 and (best_doc is None or s > best_doc[0]):
                best_doc = (s, d)

        best_example: tuple[float, _Example] | None = None
        for e in self.examples:
            s, exact = similarity(qc, e.norm)
            if exact:
                s = 125.0
            if e.folder and s >= 60:
                evidence[e.folder].append((s, f"Eksempel i Excel-arket: »{e.name}«"))
            if s >= 75 and (best_example is None or s > best_example[0]):
                best_example = (s, e)

        for f in self.folders:
            s = self._folder_score(qc, f)
            if s >= 55:
                evidence[f.code].append((s, f"Mappenavn/nøgleord matcher »{f.name}«"))

        concept_labels = []
        for key, strength in sorted(q.concepts.items(), key=lambda kv: -kv[1]):
            concept = self.engine.concept(key)
            if not concept:
                continue
            concept_labels.append(f"{concept.emoji} {concept.label}".strip())
            folder_targets = sorted(((w, k) for (t, k), w in concept.targets.items() if t == "folder"), reverse=True)
            for weight, code in folder_targets:
                evidence[code].append((70 * strength * weight, f"Begrebet »{concept.label}« peger på mappen"))

        doc_match = best_doc if best_doc and best_doc[0] >= 85 else None
        example_match = best_example if best_example and best_example[0] >= 85 else None
        kind = self._detect_kind(qc, doc_match, example_match)
        if kind in ("drawing", "model") and "C07" in self.folder_codes:
            evidence["C07"].append((18.0, "Tegninger og modeller ligger i GEOMETRI (C07)"))
            sub = "C07.01" if kind == "drawing" else "C07.02"
            if sub in self.folder_codes:
                label = "Tegninger" if kind == "drawing" else "Modeller"
                evidence[sub].append((30.0, f"{label} ligger i {sub} {self.db.folder_name(sub)}"))

        ranked = self._rank(evidence, within)
        candidates = ranked
        # Dokumenter hører til i en undermappe: peger forslaget på en hovedmappe med undermapper,
        # vælges den bedste undermappe
        if ranked and self._has_children(ranked[0].folder_code):
            parent = ranked[0]
            children = self._rank(evidence, parent.folder_code, strict=True)
            if children:
                child = children[0]
                child.reasons = list(dict.fromkeys(child.reasons + parent.reasons))[:4]
                candidates = [child] + children[1:3] + [c for c in ranked[1:]
                                                        if not c.folder_code.startswith(parent.folder_code + ".")]
        best = candidates[0] if candidates else None
        if best and "." in best.folder_code:
            # Sikkerhed = sandsynligheden for hele hovedmappen (fx C07 + C07.01 + C07.02)
            # gange undermappens andel blandt søskende
            main = best.folder_code.split(".")[0]
            group = sum(c.probability for c in ranked
                        if c.folder_code == main or c.folder_code.startswith(main + "."))
            siblings = self._rank(evidence, main, strict=True)
            total = sum(s.probability for s in siblings)
            share = (next((s.probability for s in siblings if s.folder_code == best.folder_code), 0) / total
                     if total else 1.0)
            best.probability = max(1, min(MAX_PROBABILITY, round(min(group, 100) * share)))
        alternatives = [c for c in candidates[1:4] if c.probability >= 3]

        phase = self._detect_phase(qc, q, doc_match, example_match, best)
        knowledge_area = self._detect_knowledge_area(qc, q, doc_match, example_match)
        discipline = self._detect_discipline(text, q, doc_match, example_match)
        drawing_type = self._detect_drawing_type(qc, doc_match, example_match) if kind == "drawing" else None

        pid = project_id or self.db.get_meta("excel_project_id")
        filename, note = self._build_filename(text, q, kind, best, phase, knowledge_area, drawing_type,
                                              doc_match, example_match, pid, include_project_id)
        explanation = self._explanation(text, best, doc_match)
        related = self._related(best, doc_match)

        example = None
        if best_example and best_example[0] >= 75:
            e = best_example[1]
            example = ExampleMatch(e.id, e.name, e.folder, e.generated, min(100.0, best_example[0]))

        return Classification(
            query=text, terms=q.terms, doc_kind=kind, best=best, alternatives=alternatives,
            folder_path=self.db.folder_path(best.folder_code) if best else [],
            phase=self._named(phase), discipline=self._named(discipline),
            knowledge_area=self._named(knowledge_area), drawing_type=self._named(drawing_type),
            filename=filename, filename_note=note, explanation=explanation, related_documents=related,
            matched_document=(doc_match[1].id, doc_match[1].name) if doc_match else None,
            example=example, concepts=concept_labels,
        )

    # --------------------------------------------------------------- scoring
    @staticmethod
    def _folder_score(qc: str, f: _Folder) -> float:
        if not qc:
            return 0.0
        if qc == f.norm:
            name_score = 100.0
        elif len(f.norm) >= 4 and f.norm in qc:
            name_score = 90.0
        else:
            name_score = fuzz.token_sort_ratio(qc, f.norm) * 0.85
        kw_score = 0.0
        for kw in f.keywords:
            if not kw:
                continue
            if kw == qc:
                s = 95.0
            elif len(kw) >= 5 and kw in qc:
                s = 80 + 8 * min(1.0, len(kw) / max(len(qc), 1))
            elif len(qc) >= 5 and qc in kw:
                s = 70 + 15 * len(qc) / len(kw)
            else:
                r = fuzz.ratio(qc, kw)
                s = r * 0.9 if r >= 85 else 0.0
            kw_score = max(kw_score, s)
        return max(name_score, kw_score) * 0.9

    def _rank(self, evidence: dict[str, list[tuple[float, str]]], within: str | None = None,
              strict: bool = False) -> list[PlacementCandidate]:
        if within:
            limited = {c: v for c, v in evidence.items() if c.startswith(within + ".")}
            if limited or strict:
                evidence = limited
        scores: dict[str, float] = {}
        reasons: dict[str, list[str]] = {}
        for code, items in evidence.items():
            if code not in self.folder_codes:
                continue
            items = sorted(items, key=lambda x: -x[0])
            values = [v for v, _ in items]
            scores[code] = values[0] + 0.12 * (values[1] if len(values) > 1 else 0) \
                + 0.06 * (values[2] if len(values) > 2 else 0)
            reasons[code] = list(dict.fromkeys(r for _, r in items))[:4]
        # En undermappe er mere præcis end dens hovedmappe
        for code in list(scores):
            if any(other.startswith(code + ".") for other in scores):
                scores[code] *= 0.9
        ordered = sorted(scores.items(), key=lambda kv: -kv[1])[:6]
        if not ordered:
            return []
        top = ordered[0][1]
        exps = [math.exp((s - top) / TEMPERATURE) for _, s in ordered]
        total = sum(exps)
        strength = min(1.0, top / 100.0)
        result = []
        for (code, score), e in zip(ordered, exps):
            prob = round(100 * (e / total) * strength)
            result.append(PlacementCandidate(code, self.db.folder_name(code), round(score, 1),
                                             max(1, min(MAX_PROBABILITY, prob)), reasons.get(code, [])))
        return result

    # ------------------------------------------------------------- detaljer
    @staticmethod
    def _detect_kind(qc: str, doc_match, example_match) -> str:
        if example_match and example_match[0] >= 90:
            return example_match[1].kind
        if doc_match and doc_match[0] >= 90:
            return doc_match[1].kind
        if any(w in qc for w in kb.MODEL_WORDS):
            return "model"
        if any(w in qc for w in kb.DRAWING_WORDS):
            return "drawing"
        if doc_match:
            return doc_match[1].kind
        return "document"

    def _detect_phase(self, qc: str, q: QueryInfo, doc_match, example_match, best) -> str | None:
        words = set(q.terms)
        for hint in sorted(kb.PHASE_HINTS, key=len, reverse=True):
            if hint in words or (len(hint) >= 7 and hint in qc):
                return kb.PHASE_HINTS[hint]
        for code, name in sorted(self.phases, key=lambda p: -len(p[1])):
            if len(name) >= 6 and name in qc:
                return code
        if best:
            m = re.match(r"^D\d\.(A\d+)$", best.folder_code)
            if m:
                return m.group(1)
        if example_match and example_match[1].phase:
            return example_match[1].phase
        # Kun når dokumenttypen hører til få faser – ellers er et gæt misvisende (fx referater)
        if doc_match and 0 < len(doc_match[1].phases) <= 2:
            return doc_match[1].phases[0]
        return None

    def _detect_knowledge_area(self, qc: str, q: QueryInfo, doc_match, example_match) -> str | None:
        if example_match and example_match[1].k:
            return example_match[1].k
        if doc_match and doc_match[1].k:
            return doc_match[1].k
        hinted = next((code for code, words in kb.KNOWLEDGE_AREA_HINTS if any(w in qc for w in words)), None)
        if hinted:
            return hinted
        for key, _ in sorted(q.concepts.items(), key=lambda kv: -kv[1]):
            concept = self.engine.concept(key)
            if concept:
                area = next((k for (t, k), _w in concept.targets.items() if t == "knowledge_area"), None)
                if area:
                    return area
        return "K01" if self.db.knowledge_area("K01") else None

    def _detect_discipline(self, text: str, q: QueryInfo, doc_match, example_match) -> str | None:
        if doc_match and doc_match[1].m:
            return doc_match[1].m
        if example_match and example_match[1].m:
            return example_match[1].m
        for key, _ in sorted(q.concepts.items(), key=lambda kv: -kv[1]):
            concept = self.engine.concept(key)
            if concept:
                disc = next((k for (t, k), _w in sorted(concept.targets.items(), key=lambda kv: -kv[1])
                             if t == "discipline"), None)
                if disc:
                    return disc
        hits = self.engine.search(text, limit=3, types={DISCIPLINE})
        if hits and hits[0].score >= 70:
            return hits[0].ref.key
        return None

    @staticmethod
    def _detect_drawing_type(qc: str, doc_match, example_match) -> str | None:
        if example_match and example_match[1].h:
            return example_match[1].h
        if doc_match and doc_match[1].h:
            return doc_match[1].h
        for code, words in kb.DRAWING_TYPE_HINTS:
            if any(w in qc for w in words):
                return code
        return "H0"

    def _named(self, code: str | None) -> tuple[str, str] | None:
        if not code:
            return None
        return code, self.db.code_name(code) or ""

    # -------------------------------------------------------------- filnavn
    @staticmethod
    def _name_part(text: str) -> str:
        words = re.findall(r"[\w&\-.]+", text)
        kept = [w for w in words if w.lower().strip(".") not in kb.STOPWORDS]
        name = " ".join(kept).strip(" .-") or text.strip()
        name = INVALID_FILENAME_CHARS.sub("", name)
        return name[:1].upper() + name[1:]

    def _next_serial(self, k: str | None, h: str | None) -> str:
        numbers = [int(re.sub(r"\D", "", e.serial)) for e in self.examples
                   if e.kind == "drawing" and e.k == k and e.h == h and e.serial and re.sub(r"\D", "", e.serial)]
        return f"N{(max(numbers) + 1) if numbers else 1:02d}"

    def _build_filename(self, text, q, kind, best, phase, k, h, doc_match, example_match, project_id,
                        include_project_id) -> tuple[str, str]:
        k = k or "K01"
        if kind == "drawing":
            if example_match and example_match[1].kind == "drawing" and example_match[1].generated:
                e = example_match[1]
                note = f"Tegningsnummer fra Excel-eksemplet »{e.name}«."
                number = e.generated
            else:
                number = f"{k}_{h or 'H0'}_{self._next_serial(k, h)}"
                note = "Tegningsnummer = Vidensområde_Afbildningstype_Løbenummer. Løbenummeret er næste ledige i Excel-arket."
            if include_project_id and project_id:
                number = f"{project_id}_{number}"
            return number, note

        if doc_match and doc_match[0] >= 90:
            name = doc_match[1].name
        elif example_match and example_match[0] >= 90:
            name = re.sub(r"_N\d+$", "", example_match[1].name)
        else:
            name = self._name_part(text)
        name = INVALID_FILENAME_CHARS.sub("", name)

        if kind == "model":
            f_type = None
            if example_match and example_match[1].f:
                f_type = example_match[1].f
            else:
                f_type = next((code for code, words in kb.FILE_TYPE_HINTS if any(w in q.cleaned for w in words)),
                              "F02")
            parts = [project_id or "PROJEKT-ID", phase or "Ax", f_type, k, name]
            note = "Model/CAD-fil = Projekt-ID_Fase_Filtype_Vidensområde_Navn."
            if not phase:
                note += " Erstat »Ax« med den aktuelle fase."
            return "_".join(parts), note

        folder = best.folder_code if best else "Cxx"
        parts = []
        if include_project_id and project_id:
            parts.append(project_id)
        parts += [folder, k]
        recurring = next((w for w in kb.RECURRING_WORDS if w in q.cleaned), None)
        if recurring:
            parts += [recurring.capitalize(), "N01"]
            note = "Dokumentfil = Mappe_Vidensområde_Navn. Løbenummer (N01, N02 …) bruges ved mange ens dokumenter."
        else:
            parts.append(name)
            note = "Dokumentfil = Mappe_Vidensområde_Navn (som i Excel-arket »Dokument-fil-navne«)."
        return "_".join(parts), note

    # ------------------------------------------------------------ forklaring
    def _explanation(self, text: str, best: PlacementCandidate | None, doc_match) -> str:
        if not best:
            return ("Der blev ikke fundet et sikkert match. Prøv at beskrive dokumentet med et fagord, "
                    "fx »referat«, »kontrolplan«, »brandstrategi« eller »tidsplan«.")
        if doc_match and doc_match[1].explanation and doc_match[1].folder == best.folder_code:
            return doc_match[1].explanation
        folder = self.db.folder(best.folder_code)
        purpose = (folder["purpose"] if folder else "") or ""
        subject = doc_match[1].name if doc_match else self._name_part(text)
        text_out = f"{subject} passer bedst i {best.folder_code} {best.folder_name}."
        if purpose:
            text_out += f" Mappen indeholder: {purpose[0].lower()}{purpose[1:]}"
        return text_out

    def _related(self, best: PlacementCandidate | None, doc_match) -> list[tuple[int, str, str | None]]:
        result: list[tuple[int, str, str | None]] = []
        seen: set[int] = set()
        if doc_match:
            seen.add(doc_match[1].id)
            for r in self.db.related_documents(doc_match[1].id):
                if r["id"] not in seen:
                    seen.add(r["id"])
                    result.append((r["id"], r["name"], r["folder_code"]))
        if best and len(result) < 5:
            for r in self.db.documents_in_folder(best.folder_code, include_children=False):
                if r["id"] not in seen:
                    seen.add(r["id"])
                    result.append((r["id"], r["name"], r["folder_code"]))
                if len(result) >= 6:
                    break
        return result[:6]

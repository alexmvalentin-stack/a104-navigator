"""Søgning i projektfilernes navne, egenskaber og indhold – fx efter initialer (»ALVA«).

Der søges i:
* filnavnet og mappenavnet (fx kontrolkoden Q: »…_QALVA20261012.pdf«)
* dokumentegenskaber: Oprettet af / Sidst gemt af (Word, Excel, PowerPoint) og Forfatter (PDF)
* teksten i Word, Excel, PowerPoint, PDF (fx tegningshovedet), IFC, tekst- og mailfiler
* rå tekst i ældre Office-filer (.doc/.xls/.ppt), .msg og .rtf

Initialer kobles til fulde navne: dokumenter gemmer typisk »Alexander Valentin« – ikke »ALVA«. Derfor samles
alle personnavne i projektet, og navne hvis initialer passer (ALexander VAlentin = ALVA) søges med.

Filer, der kun ligger i OneDrive-skyen, hentes kun ned, hvis brugeren vælger det.
"""
from __future__ import annotations

import html
import logging
import os
import re
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

log = logging.getLogger(__name__)

# Windows-attributter for OneDrive-filer, der kun ligger i skyen
_CLOUD_ATTRS = 0x1000 | 0x40000 | 0x400000  # OFFLINE | RECALL_ON_OPEN | RECALL_ON_DATA_ACCESS
MAX_BYTES = 40 * 1024 * 1024
MAX_DOWNLOAD = 60 * 1024 * 1024  # større skyfiler hentes ikke ned for at blive søgt i
MAX_PDF_PAGES = 60

OFFICE_XML = {
    ".docx": ("word/document.xml", "word/header", "word/footer", "word/footnotes.xml", "word/comments.xml"),
    ".docm": ("word/document.xml", "word/header", "word/footer", "word/footnotes.xml", "word/comments.xml"),
    ".dotx": ("word/document.xml", "word/header", "word/footer"),
    ".xlsx": ("xl/sharedStrings.xml", "xl/worksheets/sheet", "xl/comments"),
    ".xlsm": ("xl/sharedStrings.xml", "xl/worksheets/sheet", "xl/comments"),
    ".pptx": ("ppt/slides/slide", "ppt/notesSlides/notesSlide"),
}
TEXT_EXT = {".txt", ".csv", ".md", ".eml", ".ifc", ".xml", ".json", ".log", ".htm", ".html", ".bcf"}
RAW_EXT = {".doc", ".xls", ".ppt", ".msg", ".rtf", ".dwg", ".dxf"}
SEARCHABLE_EXT = set(OFFICE_XML) | TEXT_EXT | RAW_EXT | {".pdf"}

LOWER = "a-zæøåäöüéè"
UPPER = "A-ZÆØÅÄÖÜÉ"
LETTERS = f"0-9{LOWER}{UPPER}"
PEOPLE_FIELDS = ("Oprettet af", "Sidst gemt af", "Forfatter (PDF)")
# Navne i teksten: 2–4 ord med stort forbogstav på samme linje, fx »Jamie Frederik Johansen«
NAME_RE = re.compile(rf"(?<![{LETTERS}])[{UPPER}][{LOWER}]+(?:[ \t]+[{UPPER}][{LOWER}]+){{1,3}}(?![{LETTERS}])")
INITIALS_RE = re.compile(rf"^[{LOWER}{UPPER}]{{2,5}}$")
NOT_NAMES = {"un-named", "unnamed", "user", "bruger", "admin", "administrator", "microsoft", "autodesk", "revit"}
# programmer og biblioteker, der skriver sig selv som »forfatter« (python-docx, openpyxl, PptxGenJS …)
GENERATOR_RE = re.compile(
    r"(?:python-docx|python-pptx|openpyxl|xlsxwriter|pptxgenjs|docx4j|reportlab|pdfkit|wkhtml|libreoffice|openoffice|"
    r"microsoft|office|word|excel|powerpoint|adobe|acrobat|pdf24|nitro|bluebeam|autocad|archicad|revit|sketchup|"
    r"solidworks|cutepdf|primopdf|ghostscript|chrom(?:e|ium)|skia|quartz|canva|apache|aspose|itext|pdfsharp|"
    r"tcpdf|mpdf|fpdf|qt\b|latex|pandoc|google|onlyoffice|wps|ricoh|canon|konica|xerox|scanner|scan\b|"
    r"^owner$|^ejer$|^author$|^forfatter$|^skabelon$|^template$|^default$|^standard$)", re.IGNORECASE)


@dataclass
class FileInfo:
    fields: list[tuple[str, str]] = field(default_factory=list)  # (hvor, tekst)
    cloud_only: bool = False
    error: str = ""

    def people(self) -> list[tuple[str, str]]:
        """Kun personfelterne (oprettet af, sidst gemt af, forfatter)."""
        return [(k, v) for k, v in self.fields if k in PEOPLE_FIELDS and v.strip()]


@dataclass
class Hit:
    where: str
    snippet: str
    term: str = ""


def is_cloud_only(path: Path) -> bool:
    try:
        return bool(getattr(os.stat(path), "st_file_attributes", 0) & _CLOUD_ATTRS)
    except OSError:
        return False


# ---------------------------------------------------------------------------
# Søgeord, initialer og navne
# ---------------------------------------------------------------------------
def split_terms(query: str) -> list[str]:
    """»JAJO, Jamie« -> ['JAJO', 'Jamie']."""
    terms = [re.sub(r"\s+", " ", t).strip() for t in re.split(r"[,;]", query)]
    return list(dict.fromkeys(t for t in terms if len(t) >= 2))


def looks_like_initials(term: str) -> bool:
    return bool(INITIALS_RE.match(term))


def name_initials(name: str) -> set[str]:
    """Mulige initialer for et navn. »Alexander Sølbeck Maisøe Valentin« -> ALVA, ALSØ, ALMA, AV, ASMV …
    Den danske standard er 2 bogstaver af fornavn + 2 af efternavn (ALVA)."""
    parts = [p for p in re.split(r"[\s.\-_]+", name.strip()) if p and p[0].isalpha()]
    if len(parts) < 2:
        return set()
    first, rest = parts[0], parts[1:]
    out = {"".join(p[0] for p in parts), first[0] + parts[-1][0]}
    for p in rest:
        out.add(first[:2] + p[:2])
        out.add(first[:2] + p[:1])
        out.add(first[:1] + p[:2])
    out.add(first[:3] + parts[-1][:1])
    return {i.upper() for i in out if len(i) >= 2}


COMPANY_RE = re.compile(r"\b(?:ApS|A/S|I/S|K/S|P/S|IVS|Kommune|Styrelse|Ministeriet|Rådgivning|Arkitekter|"
                        r"Ingeniører|Entreprise|Consult|GmbH|AG|Ltd|Inc|LLC|Corp|Oy|BV|S\.?A\.?|AB|AS|Group|"
                        r"Gruppen|Holding|International|Industri|Fabrik)\b", re.IGNORECASE)
# et hold eller en projektkode som »forfatter« (»Hold BKN-MIL-F26-G1«, »Team 3«) er ikke en person
GROUP_RE = re.compile(r"^(?:[Hh]old|[Tt]eam\w*|[Gg]ruppe|[Gg]roup|[Pp]rojekt|[Pp]roject|[Kk]lasse)\b"
                      r"|(?<![A-Za-zÆØÅæøå])[A-ZÆØÅ]{2,}-[A-Z0-9-]*\d")


def person_initials(name: str) -> str:
    """Initialer for en person ud fra et metadatanavn. »Alexander Valentin« -> ALVA, »Valentin, Alexander« -> ALVA,
    »alva1000« / »alva1000@stud.ek.dk« -> ALVA, »PEHA« -> PEHA. Tom streng, hvis det ikke ligner en person."""
    v = (name or "").strip()
    username = False
    if re.fullmatch(r"[\w.-]+\\[\w.@-]+", v):  # DOMÆNE\bruger
        v = v.rsplit("\\", 1)[-1]
        username = True
    if not v or v.lower() in NOT_NAMES or re.search(r"www\.|https?:|[/\\]", v) or COMPANY_RE.search(v) \
            or GROUP_RE.search(v):
        return ""
    if "@" in v:
        v = v.split("@")[0]
        username = True
    username = username or bool(re.search(r"\d", v))
    if "," in v:  # »Efternavn, Fornavn«
        last, _, first = v.partition(",")
        v = f"{first} {last}"
    v = re.sub(r"[\d_]+$", "", v).strip()
    parts = [p for p in re.split(r"[\s.\-_]+", v) if p and p[0].isalpha()]
    if not parts:
        return ""
    if len(parts) == 1:
        # ét ord er kun initialer, hvis det står med store bogstaver (»PEHA«) eller er et brugernavn (»alva1000«);
        # et fornavn alene (»Danny«) kobles til en person andetsteds (initials.py)
        word = re.sub(r"[^A-Za-zÆØÅæøåÄÖÜäöüé]", "", parts[0])
        return word.upper() if 2 <= len(word) <= 5 and (word.isupper() or username) else ""
    return (parts[0][:2] + parts[-1][:2]).upper()


@dataclass
class Authorship:
    initials: str = ""     # fx ALVA (den, der har oprettet filen – ellers den, der sidst har gemt den)
    created_by: str = ""
    modified_by: str = ""
    cloud_only: bool = False

    @property
    def modified_initials(self) -> str:
        return person_initials(self.modified_by)

    def tooltip(self) -> str:
        if self.cloud_only:
            return "Filen ligger kun i OneDrive-skyen – hent den for at se, hvem der har lavet den."
        lines = []
        if self.created_by:
            lines.append(f"Oprettet af: {self.created_by}")
        if self.modified_by:
            lines.append(f"Sidst gemt af: {self.modified_by}")
        return "\n".join(lines) or "Filen har ingen oplysninger om, hvem der har lavet den."


AUTHOR_EXT = set(OFFICE_XML) | {".pdf"}


def authorship(path: Path, allow_download: bool = False) -> Authorship:
    """Hvem har lavet filen? Læses fra dokumentegenskaberne (Word, Excel, PowerPoint og PDF)."""
    path = Path(path)
    if path.suffix.lower() not in AUTHOR_EXT:
        return Authorship()
    info = extract(path, include_text=False, allow_download=allow_download)
    if info.cloud_only:
        return Authorship(cloud_only=True)
    people = dict(info.people())

    def plausible(n: str) -> str:
        """Navnet som det står – medmindre det tydeligvis ikke er en person (Un-named, www…, ApS)."""
        n = (n or "").strip()
        if not n or n.lower() in NOT_NAMES or re.search(r"www\.|https?:|/|&", n) or COMPANY_RE.search(n) \
                or GENERATOR_RE.search(n) or GROUP_RE.search(n) or not re.search(r"[A-Za-zÆØÅæøå]{2}", n):
            return ""
        # en titel i forfatterfeltet (»Projektgrundlag for byggeledelse og …«) er ikke en person
        if len(n.split()) > 4 or re.search(r"\b(?:og|for|til|med|af|på|om|the|and|of)\b", n):
            return ""
        return n

    created = plausible(people.get("Oprettet af") or people.get("Forfatter (PDF)") or "")
    modified = plausible(people.get("Sidst gemt af", ""))
    return Authorship(person_initials(created) or person_initials(modified), created, modified)


def names_in(info: FileInfo) -> set[str]:
    """Personnavne i en fil: personfelterne og navne i teksten."""
    names = set()
    for _k, v in info.people():
        v = v.strip()
        if v.lower() not in NOT_NAMES and not re.search(r"[@/\\:]|www\.|\d", v):
            names.add(re.sub(r"\s+", " ", v))
    for k, text in info.fields:
        if k not in PEOPLE_FIELDS:
            names.update(re.sub(r"\s+", " ", m.group(0)) for m in NAME_RE.finditer(text[:400_000]))
    return names


def expand_terms(terms: list[str], names: set[str], first_names: bool = False) -> dict[str, str]:
    """Søgeord -> forklaring. Initialer udvides med de navne i projektet, hvis initialer passer."""
    out = {t: "" for t in terms}
    for t in terms:
        if not looks_like_initials(t):
            continue
        upper = t.upper()
        matches = sorted(n for n in names if upper in name_initials(n))
        # foretræk de længste navne (»Jamie Frederik Johansen« frem for »Jamie Frederik«)
        for n in matches:
            if not any(n != m and n in m for m in matches):
                out.setdefault(n, f"= {upper}")
                parts = n.split(" ")
                if len(parts) > 2:  # »Jamie Frederik Johansen« skrives ofte »Jamie Johansen«
                    out.setdefault(f"{parts[0]} {parts[-1]}", f"= {upper}")
        if first_names:
            for n in matches:
                first = n.split(" ")[0]
                if len(first) >= 3:
                    out.setdefault(first, f"fornavn for {upper}")
    return out


def make_pattern(terms) -> re.Pattern | None:
    """Hele ord, uanset store/små bogstaver. Initialer må stå efter Q (kontrol: QALVA) og før en dato (ALVA12.10)."""
    if isinstance(terms, str):
        terms = split_terms(terms)
    parts = []
    for t in sorted(terms, key=len, reverse=True):
        body = r"\s+".join(re.escape(w) for w in t.split(" "))
        parts.append(rf"Q?{body}" if looks_like_initials(t) else body)
    if not parts:
        return None
    return re.compile(rf"(?<![{LETTERS}])(?:{'|'.join(parts)})(?![{LOWER}{UPPER}])", re.IGNORECASE)


def snippet(text: str, m: re.Match, width: int = 45) -> str:
    start, end = max(0, m.start() - width), min(len(text), m.end() + width)
    s = re.sub(r"\s+", " ", text[start:end]).strip()
    return ("…" if start > 0 else "") + s + ("…" if end < len(text) else "")


# ---------------------------------------------------------------------------
# Udtræk
# ---------------------------------------------------------------------------
def _xml_text(data: bytes) -> str:
    text = data.decode("utf-8", errors="ignore")
    text = re.sub(r"</(?:w:p|a:p|si|row|c)>|<w:tab/>|<w:br/>", "\n", text)
    text = re.sub(r"<[^>]+>", " ", text)
    return html.unescape(text)


def _core_props(z: zipfile.ZipFile) -> list[tuple[str, str]]:
    try:
        core = z.read("docProps/core.xml").decode("utf-8", errors="ignore")
    except KeyError:
        return []
    out = []
    for tag, label in (("dc:creator", "Oprettet af"), ("cp:lastModifiedBy", "Sidst gemt af"),
                       ("dc:title", "Titel"), ("dc:subject", "Emne"), ("cp:keywords", "Nøgleord"),
                       ("dc:description", "Kommentarer"), ("cp:category", "Kategori")):
        m = re.search(rf"<{tag}[^>]*>(.*?)</{tag}>", core, re.S)
        if m and m.group(1).strip():
            out.append((label, html.unescape(m.group(1).strip())))
    # brugerdefinerede egenskaber fra firmaets skabeloner (»Sagsbehandler«, »Udarbejdet af«, »Initialer« …)
    try:
        custom = z.read("docProps/custom.xml").decode("utf-8", errors="ignore")
    except KeyError:
        custom = ""
    for m in re.finditer(r'<property\b[^>]*\bname="([^"]+)"[^>]*>\s*<vt:\w+>([^<]*)</vt:\w+>', custom):
        value = html.unescape(m.group(2)).strip()
        if value:
            out.append((f"Egenskab: {html.unescape(m.group(1)).strip()}", value))
    return out


def _office(path: Path, include_text: bool) -> FileInfo:
    info = FileInfo()
    with zipfile.ZipFile(path) as z:
        info.fields += _core_props(z)
        if include_text:
            prefixes = OFFICE_XML[path.suffix.lower()]
            parts = [n for n in z.namelist() if n.endswith(".xml") and n.startswith(prefixes)]
            text = "\n".join(_xml_text(z.read(n)) for n in sorted(parts))
            if text.strip():
                info.fields.append(("Tekst i dokumentet", text))
    return info


def _pdf(path: Path, include_text: bool) -> FileInfo:
    info = FileInfo()
    try:
        from pypdf import PdfReader
    except ImportError:  # biblioteket mangler – søg som rå tekst i stedet
        return _raw(path)
    logging.getLogger("pypdf").setLevel(logging.ERROR)
    reader = PdfReader(str(path), strict=False)
    if reader.is_encrypted:
        try:
            reader.decrypt("")
        except Exception:
            info.error = "PDF'en er krypteret"
            return info
    meta = reader.metadata or {}
    for key, label in (("/Author", "Forfatter (PDF)"), ("/Title", "Titel"), ("/Subject", "Emne"),
                       ("/Keywords", "Nøgleord")):
        value = meta.get(key)
        if value and str(value).strip():
            info.fields.append((label, str(value).strip()))
    if not meta.get("/Author"):  # nogle programmer skriver kun forfatteren i XMP-delen
        try:
            xmp = reader.xmp_metadata
            creators = [c for c in (xmp.dc_creator or []) if str(c).strip()] if xmp else []
            if creators:
                info.fields.append(("Forfatter (PDF)", str(creators[0]).strip()))
        except Exception:
            pass
    if include_text:
        texts = []
        for i, page in enumerate(reader.pages):
            if i >= MAX_PDF_PAGES:
                break
            try:
                texts.append(page.extract_text() or "")
            except Exception:  # enkelte sider kan være defekte
                continue
        text = "\n".join(texts)
        if text.strip():
            info.fields.append(("Tekst i PDF'en", text))
    return info


def _text(path: Path) -> FileInfo:
    data = path.read_bytes()[:MAX_BYTES]
    for enc in ("utf-8", "cp1252"):
        try:
            return FileInfo([("Tekst i filen", data.decode(enc))])
        except UnicodeDecodeError:
            continue
    return FileInfo([("Tekst i filen", data.decode("latin-1"))])


def _raw(path: Path) -> FileInfo:
    """Ældre binære formater: læs tekststumper (ANSI og UTF-16) direkte fra filen."""
    data = path.read_bytes()[:MAX_BYTES]
    ansi = " ".join(s.decode("cp1252", errors="ignore") for s in re.findall(rb"[\x20-\x7e\xc0-\xff]{3,}", data))
    wide = " ".join(s.decode("utf-16-le", errors="ignore")
                    for s in re.findall(rb"(?:[\x20-\x7e\xc0-\xff]\x00){3,}", data))
    return FileInfo([("Indhold i filen", ansi + "\n" + wide)])


_cache: dict[tuple[str, bool], tuple[float, int, FileInfo]] = {}


def extract(path: Path, include_text: bool = True, allow_download: bool = False) -> FileInfo:
    """Egenskaber og (valgfrit) tekst fra en fil. Resultatet gemmes, til filen ændres.
    Filer, der kun ligger i OneDrive-skyen, læses kun (og hentes dermed ned), når allow_download er sand."""
    path = Path(path)
    try:
        st = path.stat()
    except OSError as exc:
        return FileInfo(error=str(exc))
    key = (str(path), include_text)
    cached = _cache.get(key)
    if cached and cached[0] == st.st_mtime and cached[1] == st.st_size:
        return cached[2]
    ext = path.suffix.lower()
    if ext not in SEARCHABLE_EXT:
        return FileInfo()
    if is_cloud_only(path) and (not allow_download or st.st_size > MAX_DOWNLOAD):
        return FileInfo(cloud_only=True)
    try:
        if ext in OFFICE_XML:
            info = _office(path, include_text)
        elif ext == ".pdf":
            info = _pdf(path, include_text)
        elif not include_text:
            info = FileInfo()
        elif ext in TEXT_EXT:
            info = _text(path)
        else:
            info = _raw(path)
    except Exception as exc:  # beskadigede eller låste filer må ikke stoppe søgningen
        log.debug("Kunne ikke læse %s: %s", path, exc)
        info = FileInfo(error=str(exc) or exc.__class__.__name__)
    _cache[key] = (st.st_mtime, st.st_size, info)
    if len(_cache) > 20000:
        _cache.clear()
    return info


_author_cache: dict[str, tuple[float, int, list]] = {}


def author_text(path: Path) -> list[tuple[str, str]]:
    """Tekst til at finde, hvem der har lavet filen (»Tegnet: ALVA«, »Udarbejdet af …«): egenskaber + tekst.
    PDF'er læses kun på de første 2 sider og den sidste side (tegningshoved, forside, underskrift), så ⟳ Opdatér er
    hurtig. Henter aldrig filer ned fra skyen."""
    path = Path(path)
    ext = path.suffix.lower()
    if ext not in SEARCHABLE_EXT or ext in {".dwg", ".dxf", ".ifc", ".bcf", ".json", ".log", ".csv"}:
        return []
    try:
        st = path.stat()
    except OSError:
        return []
    if is_cloud_only(path):
        return []
    full = _cache.get((str(path), True))
    if full and full[0] == st.st_mtime and full[1] == st.st_size:  # allerede læst helt (fx af en søgning)
        return full[2].fields
    if ext != ".pdf":
        return extract(path, include_text=True).fields
    hit = _author_cache.get(str(path))
    if hit and hit[0] == st.st_mtime and hit[1] == st.st_size:
        return hit[2]
    fields = list(extract(path, include_text=False).fields)
    try:
        from pypdf import PdfReader
        logging.getLogger("pypdf").setLevel(logging.ERROR)
        reader = PdfReader(str(path), strict=False)
        if reader.is_encrypted:
            reader.decrypt("")
        n = len(reader.pages)
        texts = []
        for i in sorted({*range(min(2, n)), *range(max(0, n - 1), n)}):
            try:
                texts.append(reader.pages[i].extract_text() or "")
            except Exception:
                continue
        if any(t.strip() for t in texts):
            fields.append(("Tekst i PDF'en", "\n".join(texts)))
    except Exception as exc:
        log.debug("Kunne ikke læse %s: %s", path, exc)
    _author_cache[str(path)] = (st.st_mtime, st.st_size, fields)
    if len(_author_cache) > 20000:
        _author_cache.clear()
    return fields


# ---------------------------------------------------------------------------
# Kig ind i filen – til bedre placering
# ---------------------------------------------------------------------------
DRAWING_MARKERS = re.compile(
    r"Tegn(?:ing)?s?\.?\s*nr|Målestok|\bMål\s*[:.]|\b1\s*:\s*(?:5|10|20|50|100|200|250|500|1000)\b|Papir\s*str|"
    r"Sheet\s*(?:number|no)|Drawing\s*(?:number|no)|\bRev\.?\s*dato|Tegnet\s*(?:af)?\s*:", re.IGNORECASE)
DRAWING_NUMBER_RE = re.compile(r"(?<![A-Za-z0-9])(K\d{2})[_ ](H\d)[_ ](N\d{2})", re.IGNORECASE)
JUNK_TITLES = re.compile(r"^(?:untitled|unavngivet|uden titel|dokument\d*|document\d*|præsentation\d*|"
                         r"presentation\d*|mappe\d*|book\d*|ark\d*|sheet\d*|revit|autocad)$", re.IGNORECASE)


@dataclass
class Peek:
    title: str = ""          # dokumentets titel (egenskab), hvis den er brugbar
    heading: str = ""        # første meningsfulde linje(r) i teksten
    is_drawing: bool = False  # teksten ligner et tegningshoved (Tegn. nr., Mål 1:100 …)
    drawing_number: str = ""  # fx K01_H2_N02 fra tegningshovedet
    raw: str = ""            # begyndelsen af teksten (genbruges af profile(), så filen ikke læses to gange)

    @property
    def text(self) -> str:
        return " ".join(t for t in (self.title, self.heading) if t)


_peek_cache: dict[str, tuple[float, int, Peek]] = {}


def fix_mojibake(text: str) -> str:
    """»TvÃ¦rfaglig« -> »Tværfaglig«: UTF-8 læst som Windows-1252 (ses tit i PDF-titler)."""
    if not re.search(r"[ÃÂ][\x80-\xbf ¦¥¸˜]", text or ""):
        return text
    try:
        fixed = text.encode("cp1252").decode("utf-8")
        return fixed if fixed.count("�") == 0 else text
    except (UnicodeEncodeError, UnicodeDecodeError):
        return text


@dataclass
class Profile:
    """Alt, der kan læses fra en fil til placering: egenskaber, overskrift, tekst og format."""
    title: str = ""
    subject: str = ""         # emne/nøgleord/kommentarer/kategori (dokumentegenskaber) – eller mailens emne
    heading: str = ""
    body: str = ""            # begyndelsen af teksten (første sider)
    pages: int = 0
    large_format: bool = False  # PDF-side større end A3 (typisk tegning)
    is_drawing: bool = False
    drawing_number: str = ""


_profile_cache: dict[str, tuple[float, int, Profile]] = {}
LARGE_PAGE_PT = 1190  # A3 er 842 x 1191 pt – større sider er næsten altid tegninger


def profile(path: Path) -> Profile:
    """Grundigere end peek(): dokumentegenskaber, mailens emne, de første sider og sideformat.
    Henter aldrig filer ned fra OneDrive-skyen."""
    path = Path(path)
    ext = path.suffix.lower()
    try:
        st = path.stat()
    except OSError:
        return Profile()
    cached = _profile_cache.get(str(path))
    if cached and cached[0] == st.st_mtime and cached[1] == st.st_size:
        return cached[2]
    if is_cloud_only(path) or st.st_size > MAX_BYTES:
        return Profile()
    look = peek(path)
    result = Profile(title=look.title, heading=look.heading, is_drawing=look.is_drawing,
                     drawing_number=look.drawing_number)
    try:
        if ext == ".pdf":
            from pypdf import PdfReader
            logging.getLogger("pypdf").setLevel(logging.ERROR)
            reader = PdfReader(str(path), strict=False)
            if reader.is_encrypted:
                reader.decrypt("")
            result.pages = len(reader.pages)
            meta = reader.metadata or {}
            result.subject = " ".join(str(meta.get(k) or "") for k in ("/Subject", "/Keywords")).strip()
            result.body = look.raw  # første side er allerede læst af peek()
            if result.pages:
                box = reader.pages[0].mediabox
                result.large_format = max(float(box.width), float(box.height)) > LARGE_PAGE_PT
                if result.pages > 1 and not result.large_format and len(result.body) < 3000:
                    try:  # korte forsider: tag også side 2 med
                        result.body = (result.body + "\n" + (reader.pages[1].extract_text() or ""))[:6000]
                    except Exception:
                        pass
        elif ext in (".eml", ".msg"):
            info = extract(path, include_text=True)
            text = next((v for k, v in info.fields if k.startswith(("Tekst", "Indhold"))), "")
            m = re.search(r"^(?:Subject|Emne)\s*:\s*(.+)$", text, re.MULTILINE | re.IGNORECASE)
            result.subject = m.group(1).strip()[:150] if m else ""
            result.body = text[:6000]
        elif ext in SEARCHABLE_EXT:
            info = extract(path, include_text=True)
            fields = dict(info.fields)
            result.subject = " ".join(fields.get(k, "") for k in ("Emne", "Nøgleord", "Kommentarer", "Kategori")
                                      ).strip()[:300]
            result.body = next((v for k, v in info.fields if k.startswith(("Tekst", "Indhold"))), "")[:6000]
    except Exception as exc:
        log.debug("Kunne ikke profilere %s: %s", path, exc)
    result.subject = fix_mojibake(result.subject)
    _profile_cache[str(path)] = (st.st_mtime, st.st_size, result)
    if len(_profile_cache) > 5000:
        _profile_cache.clear()
    return result


def _clean_title(title: str, path: Path) -> str:
    t = re.sub(r"^Microsoft (?:Word|Excel|PowerPoint)\s*-\s*", "", fix_mojibake(title).strip())
    t = re.sub(r"\.(?:docx?|xlsx?|pptx?|pdf|rvt|dwg)$", "", t, flags=re.IGNORECASE).strip()
    if len(t) < 3 or JUNK_TITLES.match(t) or t.lower() == path.stem.lower():
        return ""
    return t[:120]


def _heading(text: str) -> str:
    lines = []
    for line in text.splitlines():
        line = re.sub(r"\s+", " ", line).strip(" •-–:")
        if len(re.findall(rf"[{LOWER}{UPPER}]", line)) >= 4 and len(line) <= 120:
            lines.append(line)
        if len(lines) == 2 or sum(len(x) for x in lines) > 120:
            break
    return " – ".join(lines)


def peek(path: Path) -> Peek:
    """Titel, overskrift og tegningshoved fra en fil – bruges til at placere filer bedre end ud fra navnet alene.
    Læser kun begyndelsen af filen og henter aldrig filer ned fra OneDrive-skyen."""
    path = Path(path)
    ext = path.suffix.lower()
    if ext not in AUTHOR_EXT:
        return Peek()
    try:
        st = path.stat()
    except OSError:
        return Peek()
    cached = _peek_cache.get(str(path))
    if cached and cached[0] == st.st_mtime and cached[1] == st.st_size:
        return cached[2]
    if is_cloud_only(path):
        return Peek()
    result = Peek()
    try:
        if ext == ".pdf":
            from pypdf import PdfReader
            logging.getLogger("pypdf").setLevel(logging.ERROR)
            reader = PdfReader(str(path), strict=False)
            if reader.is_encrypted:
                reader.decrypt("")
            meta = reader.metadata or {}
            title = str(meta.get("/Title") or "")
            text = (reader.pages[0].extract_text() or "") if len(reader.pages) else ""
        else:
            info = extract(path, include_text=True)
            fields = dict(info.fields)
            title = fields.get("Titel", "")
            text = next((v for k, v in info.fields if k.startswith("Tekst")), "")[:20000]
        result.title = _clean_title(title, path)
        result.raw = text[:6000]
        markers = len(DRAWING_MARKERS.findall(text))
        result.is_drawing = ext == ".pdf" and markers >= 2
        m = DRAWING_NUMBER_RE.search(text)
        if m:
            result.drawing_number = "_".join(g.upper() for g in m.groups())
        # på tegninger er første linjer typisk koter og mål – brug kun titlen dér
        result.heading = "" if result.is_drawing else _heading(text)
    except Exception as exc:  # beskadigede filer må ikke stoppe placeringen
        log.debug("Kunne ikke kigge i %s: %s", path, exc)
    _peek_cache[str(path)] = (st.st_mtime, st.st_size, result)
    return result


def search_info(path: Path, info: FileInfo | None, pattern: re.Pattern, root: Path | None = None) -> list[Hit]:
    """Find mønsteret i filnavn, mappenavn, egenskaber og tekst. Højst ét fund pr. felt."""
    hits: list[Hit] = []
    m = pattern.search(path.name)
    if m:
        hits.append(Hit("Filnavn", path.name, m.group(0)))
    if root is not None:
        try:
            rel = str(path.parent.relative_to(root))
        except ValueError:
            rel = ""
        m = pattern.search(rel) if rel and rel != "." else None
        if m:
            hits.append(Hit("Mappenavn", rel, m.group(0)))
    if info:
        for where, text in info.fields:
            m = pattern.search(text)
            if m:
                hits.append(Hit(where, snippet(text, m), m.group(0)))
    return hits


def search_file(path: Path, pattern: re.Pattern, include_text: bool = True,
                allow_download: bool = False) -> tuple[list[Hit], FileInfo]:
    info = extract(path, include_text, allow_download)
    return search_info(path, info, pattern), info

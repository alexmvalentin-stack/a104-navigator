"""AB 18, ABR 18 og ABT 18 – aftalevilkårene for byggeriet med fuldtekstsøgning.

Data: assets/love/<kode>.json, bygget fra Retsinformations tekster (via MolioNavigator's lovdata.sqlite):
afsnit (A.–J.), paragraffer med overskrift og stykker samt sidetallet i den officielle PDF (assets/love/pdf).
Søgningen virker som i BR18: ord og ordbegyndelser (FTS5), stavehjælp og paragrafhenvisninger (»§ 12«,
»12 stk. 3«, »12,3«).
"""
from __future__ import annotations

import json
import logging
import re
import sqlite3
from dataclasses import dataclass, field
from pathlib import Path

from rapidfuzz import fuzz, process

from settings import ASSETS_DIR

log = logging.getLogger(__name__)

LAW_DIR = ASSETS_DIR / "love"
# kode i filnavn, visningsnavn, kort beskrivelse (til siden og menuen)
LAWS = [
    ("ab18", "AB 18", "Arbejder og leverancer – forholdet mellem bygherre og entreprenør"),
    ("abr18", "ABR 18", "Rådgivning og bistand – forholdet mellem bygherre og rådgiver"),
    ("abt18", "ABT 18", "Totalentreprise – forholdet mellem bygherre og totalentreprenør"),
]
WORD_RE = re.compile(r"[0-9A-Za-zÆØÅæøåÄÖÜäöüé]+")
PARAGRAPH_RE = re.compile(r"§+\s*(\d{1,3})\s?([a-z]?)(?:\s*,?\s*stk\.?\s*(\d{1,2}))?", re.IGNORECASE)
BARE_REF_RE = re.compile(r"^\s*(\d{1,3})(?:\s*[,.]\s*(?:stk\.?\s*)?(\d{1,2})|\s+stk\.?\s*(\d{1,2}))?\s*$", re.IGNORECASE)
STK_RE = re.compile(r"\bstk\.?\s*\d{1,2}\b", re.IGNORECASE)


@dataclass
class Para:
    num: int
    suffix: str
    section: str
    section_title: str
    heading: str
    stk: list[str] = field(default_factory=list)
    page: int = 1

    @property
    def key(self) -> str:
        return f"{self.num}{self.suffix}"


@dataclass
class LawHit:
    para: Para
    stk: int          # 1-baseret
    score: float
    snippet: str      # \x02 … \x03 omkring fundne ord


class LawLibrary:
    def __init__(self, code: str):
        self.code = code
        self.name = next((n for c, n, _d in LAWS if c == code), code.upper())
        self.description = next((d for c, _n, d in LAWS if c == code), "")
        self.title = ""
        self.url = ""
        self.lastmod = ""
        self.source = ""
        self.pdf: Path | None = None
        self.sections: list[tuple[str, str]] = []
        self.paras: list[Para] = []
        self.loaded = False
        self.error = ""
        self._rows: list[tuple[Para, int]] = []
        self._db: sqlite3.Connection | None = None
        self._vocabulary: list[str] = []

    def load(self) -> bool:
        if self.loaded:
            return True
        path = LAW_DIR / f"{self.code}.json"
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            self.error = f"{self.name} kunne ikke læses ({path}): {exc}"
            log.warning(self.error)
            return False
        self.title = data.get("title", self.name)
        self.url = data.get("url", "")
        self.lastmod = data.get("lastmod", "")
        self.source = data.get("source", "Retsinformation")
        pdf = LAW_DIR / data.get("pdf", "")
        self.pdf = pdf if data.get("pdf") and pdf.exists() else None
        self.sections = [(s["letter"], s["title"]) for s in data.get("sections", [])]
        self.paras = [Para(int(p["num"]), p.get("suffix", ""), p.get("section", ""), p.get("section_title", ""),
                           p.get("heading", ""), list(p.get("stk") or [""]), int(p.get("page") or 1))
                      for p in data.get("paragraphs", [])]
        self._build_index()
        self.loaded = True
        return True

    def _build_index(self) -> None:
        db = sqlite3.connect(":memory:", check_same_thread=False)
        db.execute("CREATE VIRTUAL TABLE fts USING fts5(heading, tekst, afsnit, "
                   "tokenize='unicode61 remove_diacritics 0')")
        self._rows = [(p, i + 1) for p in self.paras for i in range(len(p.stk))]
        db.executemany("INSERT INTO fts(rowid, heading, tekst, afsnit) VALUES (?, ?, ?, ?)",
                       [(i, p.heading, p.stk[n - 1], p.section_title) for i, (p, n) in enumerate(self._rows)])
        self._db = db
        words = set()
        for p in self.paras:
            words.update(w.lower() for w in WORD_RE.findall(" ".join([p.heading, *p.stk])) if len(w) > 3)
        self._vocabulary = sorted(words)

    # ------------------------------------------------------------------ opslag
    def para(self, key: str | int) -> Para | None:
        key = str(key)
        return next((p for p in self.paras if p.key == key), None)

    def neighbours(self, p: Para) -> tuple[Para | None, Para | None]:
        i = self.paras.index(p)
        return (self.paras[i - 1] if i > 0 else None, self.paras[i + 1] if i + 1 < len(self.paras) else None)

    def reference(self, p: Para, stk: int | None = None) -> str:
        return f"{self.name} § {p.key}" + (f", stk. {stk}" if stk and len(p.stk) > 1 else "")

    # ------------------------------------------------------------------ søgning
    def terms(self, query: str) -> list[str]:
        q = STK_RE.sub(" ", PARAGRAPH_RE.sub(" ", query))
        return [w for w in WORD_RE.findall(q) if not w.isdigit() or len(w) > 3]

    def corrections(self, query: str) -> dict[str, str]:
        out = {}
        for t in self.terms(query):
            lower = t.lower()
            if len(lower) < 4 or any(v.startswith(lower) for v in self._vocabulary):
                continue
            best = process.extractOne(lower, self._vocabulary, scorer=fuzz.ratio, score_cutoff=78)
            if best:
                out[t] = best[0]
        return out

    def search(self, query: str, section: str | None = None, limit: int = 400) -> list[LawHit]:
        if not self.load():
            return []
        query = query.strip()
        hits: list[LawHit] = []
        seen: set[int] = set()

        def allowed(p: Para) -> bool:
            return not section or p.section == section

        refs = [(m.group(1) + (m.group(2) or "").lower(), int(m.group(3)) if m.group(3) else None)
                for m in PARAGRAPH_RE.finditer(query)]
        bare = BARE_REF_RE.match(query)
        if bare and not refs:
            stk = bare.group(2) or bare.group(3)
            refs = [(bare.group(1), int(stk) if stk else None)]
        for key, stk in refs:
            for i, (p, n) in enumerate(self._rows):
                if p.key == key and (stk is None or n == stk) and i not in seen:
                    seen.add(i)
                    hits.append(LawHit(p, n, 1000.0 - n, p.stk[n - 1][:220]))
        terms = self.terms(query)
        if terms:
            fixed = self.corrections(query)
            terms = [fixed.get(t, t) for t in terms]
            for joiner in (" AND ", " OR "):
                match = joiner.join(f'"{t}"*' for t in terms)
                try:
                    rows = self._db.execute(
                        "SELECT rowid, bm25(fts, 4.0, 1.0, 1.0), snippet(fts, 1, char(2), char(3), '…', 28) "
                        "FROM fts WHERE fts MATCH ? ORDER BY 2 LIMIT ?", (match, limit * 2)).fetchall()
                except sqlite3.OperationalError as exc:
                    log.debug("FTS-fejl for %r: %s", match, exc)
                    rows = []
                for rowid, rank, snip in rows:
                    p, n = self._rows[rowid]
                    if rowid in seen or not allowed(p):
                        continue
                    seen.add(rowid)
                    hits.append(LawHit(p, n, -rank + (50 if joiner == " AND " else 0), snip))
                if len(hits) >= 5 or len(terms) == 1:
                    break
        elif not refs:
            return [LawHit(p, 1, 0.0, p.stk[0][:200]) for p in self.paras if allowed(p)][:limit]
        hits.sort(key=lambda h: -h.score)
        return hits[:limit]

    def count(self, query: str) -> int:
        if not query.strip() or not self.load():
            return 0
        return len({id(h.para) for h in self.search(query)})


_libraries: dict[str, LawLibrary] = {}


def library(code: str) -> LawLibrary:
    if code not in _libraries:
        _libraries[code] = LawLibrary(code)
    return _libraries[code]

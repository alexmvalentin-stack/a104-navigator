"""Læringsindhold om A104 Informationshåndtering – skrevet med egne ord.

Teksten forklarer principperne i A104 (metadata, værdilister, navngivning, versionsstyring, mappestruktur
og tilladte tegn). Den gengiver ikke Molios publikationer; læs A104-vejledningen på ikt.molio.dk for den
officielle tekst. Links i formatet folder:C05.01 / karea:K01 / disc:M06 / family:K åbner programmets egne visninger.
"""
from __future__ import annotations

# Åben = brugeren må selv tilføje værdier; bunden = kun de officielle værdier.
LIST_TYPES = {
    "A": "Åben", "B": "Bunden (åben underliste)", "C": "Bunden (åben underliste)", "D": "Bunden",
    "E": "Åben", "F": "Bunden", "G": "Bunden", "H": "Bunden", "J": "Bunden", "K": "Bunden", "M": "Åben",
    "P": "Bunden", "R": "Åben", "S": "Bunden", "T": "Åben", "W": "Bunden", "X": "Bunden", "Y": "Åben",
}
# Hvad listen bruges til – kort, med egne ord
LIST_PURPOSE = {
    "A": "Hvilken fase i projektet informationen hører til (fx A4 Projektforslag).",
    "B": "Hvilken type virksomhed/part der står bag (bygherre, rådgiver, entreprenør …).",
    "C": "Hvad dokumentet handler om – bruges oftest som øverste niveau i mappestrukturen.",
    "D": "Om materialet er modtaget grundlag (D1) eller noget, der afleveres (D2).",
    "E": "Hvilken etage en tegning eller model viser.",
    "F": "Hvad en fil bruges til – tegningsfil, fagmodel, fællesmodel, plot …",
    "G": "Hvor dokumentet er i sin livscyklus – under udarbejdelse, udvekslet, publiceret …",
    "H": "Hvordan geometrien vises – plan, snit, opstalt, detalje …",
    "J": "Hvor detaljeret informationen om et objekt er (informationsniveau).",
    "K": "Hvilket fagligt vidensområde informationen tilhører (fx K01 Arkitektur).",
    "M": "Den mere detaljerede fagdisciplin (fx M06 Brand) – supplerer K på større projekter.",
    "P": "Hvilken type proces/aktivitet (ledelse, projektering, udførelse …) – alternativ topstruktur.",
    "R": "Hvilken rolle en person har i projektet.",
    "S": "Udviklingstrin for indholdet, fx nyt, eksisterende eller nedrives (bruges især ved renovering).",
    "T": "Et projektspecifikt tema – fx en CCS-kode eller bygningsdel – når der skal skelnes yderligere.",
    "W": "Hvilken kontraktlig organisering (fx totalentreprise, rådgivning).",
    "X": "Om noget er afsendt (X1) eller modtaget (X2) – praktisk til korrespondance.",
    "Y": "Hvilken entreprise informationen vedrører (fx Y070 Døre og vinduer).",
}
METADATA_SET = {
    "I": "Projekt-ID", "N": "Løbenummer", "Q": "Kontrolleret af/dato", "V": "Version og revision",
    "Z": "Dokumentnavn (fritekst)", "L": "Lokation", "O": "Virksomhedens projekt-ID",
}

CHAPTERS = [
    ("intro", "1. Hvad er A104?"),
    ("begreber", "2. Begreberne – metadata og koder"),
    ("lister", "3. De 17 værdilister"),
    ("underlister", "4. Underlister, åbne og bundne lister"),
    ("navngivning", "5. Sådan bygges et filnavn"),
    ("bygger", "6. ✏️ Navnebygger (prøv selv)"),
    ("version", "7. Versioner og revisioner"),
    ("mapper", "8. Mappestruktur"),
    ("tegn", "9. Tilladte tegn"),
    ("praksis", "10. I praksis – mails, udveksling og ISO 19650"),
    ("quiz", "🎓 Test dig selv"),
]

TEXT = {
"intro": """
<h1>Hvad er A104?</h1>
<p><b>A104 Informationshåndtering</b> er byggebranchens fælles danske metode til at <b>navngive, sortere og
styre</b> dokumenter, filer, tegninger og mapper. Den er udgivet af Molio og bruges af bygherrer, rådgivere,
entreprenører og uddannelser.</p>
<h2>Hvorfor?</h2>
<ul>
<li>Når alle parter bruger <b>de samme koder</b>, kan man finde rundt i hinandens materiale – også på et fælles
projektweb (et »fælles datamiljø«).</li>
<li>Koder som <a href="karea:K01">K01</a> er <b>entydige</b>: K01 betyder altid Arkitektur – uanset projekt og firma.</li>
<li>Koder er <b>søgbare</b>: søger du på »K01_H1«, finder du alle arkitekt-planer.</li>
</ul>
<h2>De fire dele</h2>
<table>
<tr><td><b>A104</b></td><td>Vejledningen – metoderne og reglerne (det, dette afsnit forklarer).</td></tr>
<tr><td><b>A104a</b></td><td>Værdilisterne – alle koderne med definitioner. Se dem under <i>Koder</i> i programmet.</td></tr>
<tr><td><b>A104b</b></td><td>Eksempelsamlingen – eksempler på mappestrukturer og navne.</td></tr>
<tr><td><b>A104c</b></td><td>Paradigmet – færdige mappestrukturer til download.</td></tr>
</table>
<p>Metoden bygger på de internationale standarder for dokumentstyring (DS/EN 82045) og kan bruges, når et
projekt arbejder efter <b>ISO 19650</b> (BIM og informationsstyring).</p>
<p class="muted">Den officielle tekst finder du på ikt.molio.dk (kræver adgang, fx via din uddannelse).</p>
""",

"begreber": """
<h1>Begreberne – metadata og koder</h1>
<p><b>Metadata</b> er »data om data« – oplysninger, der fortæller, hvad et dokument er, uden at man skal åbne det.
I A104 er metadata <b>koder</b>.</p>
<h2>Eksempel: K01 Arkitektur</h2>
<table>
<tr><td class="mono big">K</td><td><b>Metadatakode</b> – bogstavet, der fortæller hvilken liste (K = Vidensområder).</td></tr>
<tr><td class="mono big">01</td><td><b>Værdikode</b> – nummeret på værdien i listen.</td></tr>
<tr><td class="mono big">Arkitektur</td><td><b>Metadataværdi</b> – det beskrivende ord.</td></tr>
<tr><td class="mono big">K01 Arkitektur</td><td><b>Metadataelement</b> – det hele samlet.</td></tr>
<tr><td class="mono big">Vidensområder</td><td><b>Metadatanavn</b> – navnet på listen.</td></tr>
</table>
<h2>Hvor sætter man metadata på?</h2>
<ul>
<li><b>I filnavnet</b> – fx <span class="mono">C05.01_K09_Statisk beregning.pdf</span>.</li>
<li><b>I selve dokumentet</b> – fx i tegningshovedet eller på forsiden.</li>
<li><b>Som »tags«</b> i et system (projektweb, SharePoint, Dalux …).</li>
</ul>
<p>Man kan kombinere metoderne. Står noget allerede som tag eller i tegningshovedet, behøver filnavnet ikke at
indeholde det – så bliver navnene kortere.</p>
<h2>Metadatasæt</h2>
<p>Nogle oplysninger har ingen liste, fx <b>Projekt-ID</b>, <b>Løbenummer</b> (N) og <b>Dokumentnavn</b> (Z).
De hører til det såkaldte <b>metadatasæt</b>. På hvert projekt aftaler man, hvilke metadata der skal bruges –
typisk i IKT-specifikationen (A102) eller IKT-procesmanualen (A402).</p>
""",

"underlister": """
<h1>Underlister, åbne og bundne lister</h1>
<h2>Underlister</h2>
<p>Nogle koder deles op i en <b>underliste</b>, der gør emnet mere præcist. Punktum viser niveauet:</p>
<p class="mono big"><a href="folder:C02">C02</a> Aftale → <a href="folder:C02.05">C02.05</a> Kontrakt</p>
<p>Det er netop underlisten til <b>Indholdstype (C)</b>, der giver undermapperne i mappestrukturen. Du bruger
kun de mapper, projektet har brug for.</p>
<h2>Bunden eller åben?</h2>
<table>
<tr><td><b>Bunden</b></td><td>Kun de officielle værdier må bruges (fx <a href="family:K">K</a> Vidensområder).</td></tr>
<tr><td><b>Åben</b></td><td>Du må selv tilføje værdier (fx <a href="family:M">M</a> Fagdiscipliner, <a href="family:E">E</a> Etage).</td></tr>
</table>
<p>En liste kan godt være bunden, mens dens underliste er åben – sådan er det med C: hovedmapperne C01–C11 ligger
fast, men du må tilføje egne undermapper.</p>
<h2>Egne koder</h2>
<p>Tilføjer du en egen værdi til en åben (under)liste, fortsætter du nummereringen med punktum, fx
<span class="mono">D2.01 Foreløbig gennemgang</span>, <span class="mono">D2.02 Endelig gennemgang</span>.
Programmets mapper C07.01–C07.04 er Molios officielle underliste for Geometri.</p>
<h2>Kombinerede koder</h2>
<p>På tegninger ser man ofte flere fagdiscipliner samlet (fx vand og varme). Da M er åben, kan projektet lave en
kombineret kode – men det skal <b>aftales og skrives ned</b>, så alle forstår den.</p>
<h2>Nulværdi</h2>
<p>Vil man have lige lange navne, kan <b>0</b> bruges som »ingen værdi«, fx <span class="mono">B07.00</span>.</p>
""",

"navngivning": """
<h1>Sådan bygges et filnavn</h1>
<p>Et A104-filnavn er en række <b>positioner</b> – hver position er et metadataelement – adskilt af
<b>understregning (_)</b>.</p>
<p class="mono big">K01_H1_N03</p>
<p class="muted">Vidensområde Arkitektur · Afbildningstype Plan · Løbenummer 3</p>
<h2>De fire tegn med betydning</h2>
<table>
<tr><td class="mono big">_</td><td>Adskiller positioner: <span class="mono">K01_H1</span></td></tr>
<tr><td class="mono big">.</td><td>Viser underniveau: <span class="mono">C05.01</span>, <span class="mono">B07.01</span></td></tr>
<tr><td class="mono big">+</td><td>Bruges, når et listebogstav står alene og skal kunne søges: <span class="mono">K+</span></td></tr>
<tr><td class="mono big">0</td><td>Nulværdi – »ingen værdi« for at holde navne lige lange.</td></tr>
</table>
<h2>Gode regler</h2>
<ul>
<li><b>Højst 4–5 positioner.</b> Brug kun det, der skal til for at skelne filerne fra hinanden.</li>
<li><b>Rækkefølgen</b> ændrer ikke betydningen (koderne er entydige), men aftal en fast rækkefølge på projektet,
så filerne sorteres pænt.</li>
<li>Til <b>tegninger og BIM-filer</b> bruger man typisk: Vidensområde (K), Fagdisciplin (M), Filtype (F),
Afbildningstype (H), Etage (E), Tema (T) og Stade (S).</li>
<li>Til <b>almindelige dokumenter</b> er få positioner nok: fx Projekt-ID, Vidensområde og Indholdstype.</li>
</ul>
<h2>Når flere dokumenter har samme type</h2>
<table>
<tr><td><b>Z – Dokumentnavn</b></td><td>Beskriver indholdet med ord, når flere dokumenter har samme indholdstype
(fx to økonomi-dokumenter: budget og prisoverslag).</td></tr>
<tr><td><b>N – Løbenummer</b></td><td>Nummererer flere udgaver af den samme slags dokument: <span class="mono">…_N01</span>,
<span class="mono">…_N02</span> (fx referater).</td></tr>
<tr><td><b>T – Tema</b></td><td>Skelner efter fysisk eller faglig opdeling, fx en CCS-kode for en bygningsdel.</td></tr>
<tr><td><b>Q – Kontrol</b></td><td>Hvem der har kontrolleret dokumentet og hvornår (initialer + dato).</td></tr>
</table>
<h2>Eksempler (i programmets skabelon)</h2>
<table>
<tr><td class="mono">C06.04_K01_Referat_N01.docx</td><td>Referat fra projekteringsmøde nr. 1</td></tr>
<tr><td class="mono">K01_H1_N10</td><td>Arkitektens plan nr. 10 (tegningsnummer)</td></tr>
<tr><td class="mono">G3_A4_F02_K09_Konstruktionsmodel</td><td>Projekt G3, projektforslag, fagmodel, konstruktioner</td></tr>
<tr><td class="mono">D2.A5_K01_Energirammeberegning</td><td>Afleveret i myndighedsprojektet</td></tr>
</table>
<p>Prøv selv i <b>✏️ Navnebygger</b>.</p>
""",

"version": """
<h1>Versioner og revisioner</h1>
<p>Dokumenter og modeller ændrer sig over tid. A104 skelner mellem to ting, som samles i ét <b>versions-ID</b>
med koden <b>V</b>:</p>
<table>
<tr><td><b>Revision</b> – tal (0, 1, 2 …)</td><td>En <b>officiel udgave</b>, der gives videre: faseskift, aflevering til
bygherren, kontraktlige afleveringer. Første revision er <b>0</b>, og tallet nulstilles aldrig.</td></tr>
<tr><td><b>Version</b> – bogstav (A, B, C …)</td><td>Det <b>interne arbejde</b> mellem revisionerne. Du bestemmer selv,
hvornår der er så meget nyt, at det er en ny version.</td></tr>
</table>
<h2>Sådan læses versions-ID'et</h2>
<table>
<tr><td class="mono big">VA</td><td>Version A – før første revision</td></tr>
<tr><td class="mono big">V0</td><td>Revision 0 – første officielle udgave</td></tr>
<tr><td class="mono big">V0A</td><td>Revision 0, version A – arbejdet efter revision 0</td></tr>
<tr><td class="mono big">V1</td><td>Revision 1 – næste officielle udgave</td></tr>
</table>
<p>Tallet står først, bogstavet sidst. En ren revision (fx <span class="mono">V2</span>) har intet bogstav.</p>
<h2>Skal versionen stå i filnavnet?</h2>
<ul>
<li><b>Nej</b>, hvis filen bruges som reference (fx en Revit-model, andre linker til) – så skal navnet være det samme
hele vejen.</li>
<li><b>Ja</b>, hvis man skal kunne se forskel på udgaver i Stifinder, fx ved faseaflevering:
<span class="mono">…_K01_F02_V1A</span>.</li>
</ul>
<h2>Status (G)</h2>
<p>Ud over versionen kan dokumentets <b>status</b> angives med liste <a href="family:G">G</a> – fx under udarbejdelse,
udvekslet eller publiceret. Det svarer til tilstandene i ISO 19650 (igangværende, fælles, udgivet).</p>
<p class="muted">Man kan aftale at bruge dato i stedet for bogstav-versioner, men revisionsreglerne gælder stadig.</p>
""",

"mapper": """
<h1>Mappestruktur</h1>
<p>Mapperne bygges af de <b>samme koder</b> som filnavnene. Fordelen er, at alle i branchen ved, hvad der ligger i
fx <a href="folder:C04.04">C04.04 Myndighedskrav</a>.</p>
<h2>Øverste niveau: C eller P</h2>
<table>
<tr><td><b>Indholdstype (C)</b></td><td>Sorterer efter <i>hvad</i> dokumentet handler om: <a href="folder:C01">C01 Basis</a> …
<a href="folder:C11">C11 Tids- og ressourcestyring</a>. Det er den, programmet bruger.</td></tr>
<tr><td><b>Procestype (P)</b></td><td>Sorterer efter <i>hvilken aktivitet</i>: P1 Ledelse og styring … P10
Myndighedsbehandling.</td></tr>
</table>
<h2>Underniveauer</h2>
<p>Under hovedmappen bruger man enten <b>underlisten</b> (fx C05 → C05.01 Beregning) eller <b>koder fra en anden
liste</b>. Et klassisk eksempel er aflevering opdelt efter fase – præcis som programmets
<a href="folder:D2">D2 Aflevering</a> → <a href="folder:D2.A5">D2.A5 Myndighedsprojekt</a>.</p>
<h2>Korrespondance</h2>
<p>Mails og breve arkiveres efter den <b>dominerende indholdstype</b>. Vil man skille afsendt og modtaget ad, kan
man lave undermapperne <b>X1 Afsendt</b> og <b>X2 Modtaget</b> – fx under C04 Myndigheder og instanser.</p>
<h2>Gode råd</h2>
<ul>
<li>Brug kun de mapper, projektet har brug for – men tænk strukturen igennem fra start.</li>
<li>Gå <b>højst 3–5 niveauer</b> ned, ellers bliver det uoverskueligt.</li>
<li>Brug <b>den samme struktur</b> internt og på projektweb'et.</li>
<li>Mappenavne skrives med kode, mellemrum og navn: <span class="mono">C05.01 Beregning</span>.</li>
</ul>
""",

"tegn": """
<h1>Tilladte tegn</h1>
<p>For at navne virker i alle systemer (projektweb, backup, referencer i CAD), bruger A104 kun:</p>
<p class="mono big">0-9 &nbsp; a-å &nbsp; A-Å &nbsp; _ &nbsp; .</p>
<table>
<tr><td class="mono big">_</td><td>Mellem positioner i et filnavn</td></tr>
<tr><td class="mono big">.</td><td>Mellem niveauer i en kode (C05.01)</td></tr>
<tr><td class="mono big">mellemrum</td><td>Kun i mappenavne mellem kode og navn (»C05.01 Beregning«)</td></tr>
</table>
<h2>Undgå</h2>
<p class="mono big">/ ? &lt; &gt; \\ : * |</p>
<p>Selve <b>koderne</b> indeholder ikke æ, ø og å, fordi ikke alle programmer kan håndtere dem – men beskrivende
ord må gerne have danske bogstaver.</p>
<p class="muted">Bemærk: Skolens Excel-skabelon og programmets forslag bruger mellemrum og bindestreg i den
beskrivende del (fx »Bygningsmodel - bolig«). Er der stillet krav om streng A104, så erstat mellemrum med
understregning eller skriv ordene sammen.</p>
""",

"praksis": """
<h1>I praksis – mails, udveksling og ISO 19650</h1>
<h2>Mappe eller database?</h2>
<table>
<tr><td><b>Mappestruktur</b> (Stifinder, OneDrive, de fleste projektweb)</td><td>Overskuelig og hurtig, men en fil kan kun
ligge ét sted – derfor er det vigtigt, at det er tydeligt <i>hvilket</i> sted. Det er det, programmet hjælper med.</td></tr>
<tr><td><b>Database med tags</b> (fx Dalux, ACC)</td><td>Filer findes via deres metadata i stedet for placering, men tags
følger ikke altid med, når filer flyttes til andre systemer.</td></tr>
</table>
<p>Derfor er det klogt at have <b>metadata i filnavnet</b> – så går informationen ikke tabt.</p>
<h2>Udveksling</h2>
<ul>
<li>Aftal fra start, hvilke koder og hvilken rækkefølge der bruges i navnene.</li>
<li>Brug samme navngivning, når filer sendes på mail, så modtageren kan genkende dem.</li>
<li>Skriftlige aftaler hører hjemme i IKT-specifikationen (A102) og IKT-procesmanualen (A402).</li>
</ul>
<h2>Mails</h2>
<p>Mails og vedhæftede filer er dokumenter på lige fod med alt andet. Gemmes de i projektmappen, så navngiv dem efter
samme regler og læg dem efter indhold.</p>
<h2>ISO 19650</h2>
<p>ISO 19650 kræver, at alle »informationscontainere« (filer, modeller, mapper) har et entydigt ID efter en aftalt
navngivningskonvention. <b>A104 er den danske konvention</b>, så bruger man A104, opfylder man det krav.</p>
""",
}

QUIZ = [
    ("Hvad betyder bogstavet i koden K01?",
     ["Hvilken værdiliste koden kommer fra", "Hvilken fase dokumentet hører til", "Hvem der har lavet dokumentet"], 0,
     "Bogstavet er metadatakoden – K er listen Vidensområder. Tallet (01) er værdikoden."),
    ("Hvilket tegn adskiller positionerne i et A104-filnavn?",
     ["Bindestreg (-)", "Understregning (_)", "Mellemrum"], 1,
     "Understregning adskiller positioner. Punktum bruges til underniveauer, og mellemrum kun i mappenavne."),
    ("Hvad betyder punktummet i C05.01?",
     ["At det er version 01", "At C05.01 er en underværdi til C05", "At filen er en PDF"], 1,
     "Punktum viser nedbrydningen: C05 Analyse → C05.01 Beregning."),
    ("Hvad er V1A?",
     ["Version 1, revision A", "Revision 1, version A", "Vidensområde 1A"], 1,
     "Tallet er revisionen (officiel udgave), bogstavet er versionen (internt arbejde)."),
    ("Hvornår laves en ny revision?",
     ["Hver gang filen gemmes", "Ved officielle udgivelser som faseskift og afleveringer", "Hver måned"], 1,
     "Revisioner bruges til officielle udgaver, der gives videre. Det løbende arbejde er versioner."),
    ("Hvor mange positioner anbefales højst i et filnavn?",
     ["2", "4–5", "10"], 1,
     "Hold navnene korte: højst 4–5 positioner – kun det, der skal til for at skelne filerne."),
    ("Du har to økonomidokumenter: et budget og et prisoverslag. Hvad skelner dem i navnet?",
     ["Dokumentnavn (Z)", "Etage (E)", "Afbildningstype (H)"], 0,
     "Dokumentnavn (Z) beskriver indholdet, når flere dokumenter har samme indholdstype."),
    ("Hvilken liste bruges oftest som øverste niveau i mappestrukturen?",
     ["K Vidensområder", "C Indholdstype", "G Status"], 1,
     "Indholdstype (C) – alternativt Procestype (P)."),
    ("Må du selv tilføje værdier til listen M Fagdiscipliner?",
     ["Ja, den er åben", "Nej, den er bunden"], 0,
     "M er en åben liste. K Vidensområder er derimod bunden."),
    ("Hvilket af disse tegn må IKKE bruges i A104-navne?",
     ["_", ".", "/"], 2,
     "Skråstreg og tegn som ? < > \\ : * | undgås, fordi ikke alle systemer understøtter dem."),
]

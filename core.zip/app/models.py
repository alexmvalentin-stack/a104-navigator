"""Datamodeller, der udveksles mellem søgemaskine, klassifikator og GUI."""
from __future__ import annotations

from dataclasses import dataclass, field

# Entitetstyper. Nøglen er kode for folder/discipline/knowledge_area og id for resten.
FOLDER = "folder"
DOCUMENT = "document"
EXAMPLE = "example"
CODE = "code"
DISCIPLINE = "discipline"
KNOWLEDGE_AREA = "knowledge_area"

ENTITY_LABELS = {
    FOLDER: "Mappe",
    DOCUMENT: "Dokument",
    EXAMPLE: "Eksempel",
    CODE: "Kode",
    DISCIPLINE: "Fagdisciplin",
    KNOWLEDGE_AREA: "Vidensområde",
}
ENTITY_ICONS = {
    FOLDER: "📁",
    DOCUMENT: "📄",
    EXAMPLE: "🧾",
    CODE: "🏷",
    DISCIPLINE: "🎓",
    KNOWLEDGE_AREA: "🧭",
}
ENTITY_PRIORITY = {FOLDER: 0, DOCUMENT: 1, CODE: 2, DISCIPLINE: 3, KNOWLEDGE_AREA: 4, EXAMPLE: 5}

# Korte navne til links i detaljevisningen (URL-skemaer må ikke indeholde "_")
LINK_SCHEMES = {
    FOLDER: "folder",
    DOCUMENT: "doc",
    EXAMPLE: "ex",
    CODE: "code",
    DISCIPLINE: "disc",
    KNOWLEDGE_AREA: "karea",
}
SCHEME_TO_ENTITY = {v: k for k, v in LINK_SCHEMES.items()}


@dataclass(frozen=True)
class EntityRef:
    entity_type: str
    key: str

    def link(self) -> str:
        return f"{LINK_SCHEMES[self.entity_type]}:{self.key}"


@dataclass
class SearchHit:
    ref: EntityRef
    title: str
    code: str
    subtitle: str
    score: float
    folder_code: str | None = None

    @property
    def entity_type(self) -> str:
        return self.ref.entity_type


@dataclass
class PlacementCandidate:
    folder_code: str
    folder_name: str
    score: float
    probability: int = 0
    reasons: list[str] = field(default_factory=list)


@dataclass
class ExampleMatch:
    example_id: int
    name: str
    folder_code: str | None
    generated_name: str
    similarity: float


@dataclass
class Classification:
    query: str
    terms: list[str]
    doc_kind: str  # document | drawing | model
    best: PlacementCandidate | None
    alternatives: list[PlacementCandidate]
    folder_path: list[tuple[str, str]]  # [(kode, navn), ...] fra rod til mappe
    phase: tuple[str, str] | None
    discipline: tuple[str, str] | None
    knowledge_area: tuple[str, str] | None
    drawing_type: tuple[str, str] | None
    filename: str
    filename_note: str
    explanation: str
    related_documents: list[tuple[int, str, str | None]]  # (id, navn, mappekode)
    matched_document: tuple[int, str] | None
    example: ExampleMatch | None
    concepts: list[str]

    @property
    def probability(self) -> int:
        return self.best.probability if self.best else 0

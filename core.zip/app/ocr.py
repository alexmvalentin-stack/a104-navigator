"""Tekstgenkendelse (OCR) til scannede PDF'er og billeder af dokumenter.

Bruger Windows' indbyggede OCR-motor (Windows.Media.Ocr) via assets/ocr.ps1 – offline, gratis og uden installation.
Dansk bruges, når sprogpakken findes (det gør den på danske Windows), ellers brugerens sprog.
En PDF-side gøres til et billede med Qt (QtPdf), så der ikke kræves andre biblioteker.
Bruges kun, når en fil ikke har læsbar tekst (fx »00012345.pdf« fra en scanner).
"""
from __future__ import annotations

import logging
import os
import subprocess
import sys
import tempfile
from pathlib import Path

from settings import ASSETS_DIR

log = logging.getLogger(__name__)
CREATE_NO_WINDOW = 0x08000000
IMAGE_EXT = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp", ".gif", ".heic"}
SCRIPT = ASSETS_DIR / "ocr.ps1"
_cache: dict[str, tuple[float, int, str]] = {}
_available: bool | None = None


def available() -> bool:
    """Kan Windows' OCR bruges på denne computer?"""
    global _available
    if _available is None:
        _available = sys.platform == "win32" and SCRIPT.exists()
    return _available


def _run(image: Path, timeout: float = 30) -> str:
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(SCRIPT),
                              str(image)], capture_output=True, timeout=timeout, creationflags=CREATE_NO_WINDOW)
    except (OSError, subprocess.SubprocessError) as exc:
        log.info("OCR fejlede for %s: %s", image, exc)
        return ""
    if out.returncode != 0:
        log.info("OCR gav fejl for %s: %s", image, out.stderr.decode("utf-8", "ignore")[:300])
        return ""
    return out.stdout.decode("utf-8", "ignore").strip()


def _render_page(path: Path, dpi: int = 200, max_side: int = 9000):
    """Første side af en PDF som QImage (som den vises, dvs. med rotation). Kræver en kørende Qt-applikation."""
    try:
        from PySide6.QtCore import QSize
        from PySide6.QtPdf import QPdfDocument
    except ImportError:
        return None
    doc = QPdfDocument()
    if doc.load(str(path)) != QPdfDocument.Error.None_ or doc.pageCount() < 1:
        return None
    size = doc.pagePointSize(0)
    scale = dpi / 72
    w, h = int(size.width() * scale), int(size.height() * scale)
    longest = max(w, h, 1)
    if longest > max_side:  # Windows' OCR tager højst ca. 10.000 pixel
        w, h = int(w * max_side / longest), int(h * max_side / longest)
    image = doc.render(0, QSize(max(w, 1), max(h, 1)))
    doc.close()
    return None if image.isNull() else image


def _render_pdf_page(path: Path, target: Path, dpi: int = 200) -> bool:
    image = _render_page(path, dpi)
    return image is not None and image.save(str(target), "PNG")


def read_region(path: Path, from_x: float, from_y: float, dpi: int = 300) -> str:
    """Tekst i et hjørne af første side – fx tegningshovedet nederst til højre (from_x/from_y = andel af siden).
    Tegningshoveder har lille tekst, så hjørnet forstørres, før det læses."""
    if not available():
        return ""
    image = _render_page(Path(path), dpi, max_side=14000)
    if image is None:
        return ""
    from PySide6.QtCore import Qt
    x, y = int(image.width() * from_x), int(image.height() * from_y)
    crop = image.copy(x, y, image.width() - x, image.height() - y)
    longest = max(crop.width(), crop.height(), 1)
    factor = min(2.0, 9500 / longest)
    if abs(factor - 1) > 0.05:
        crop = crop.scaled(int(crop.width() * factor), int(crop.height() * factor),
                           Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
    with tempfile.TemporaryDirectory() as tmp:
        png = Path(tmp) / "hjoerne.png"
        return _run(png) if crop.save(str(png), "PNG") else ""


def read_text(path: Path) -> str:
    """Tekst fra en scannet PDF (første side) eller et billede. Tom streng, hvis der ingen tekst er."""
    path = Path(path)
    ext = path.suffix.lower()
    if not available() or (ext != ".pdf" and ext not in IMAGE_EXT):
        return ""
    try:
        st = path.stat()
    except OSError:
        return ""
    hit = _cache.get(str(path))
    if hit and hit[0] == st.st_mtime and hit[1] == st.st_size:
        return hit[2]
    import file_search
    if file_search.is_cloud_only(path) or st.st_size > 60 * 1024 * 1024:
        return ""
    text = ""
    if ext == ".pdf":
        with tempfile.TemporaryDirectory() as tmp:
            png = Path(tmp) / "side1.png"
            if _render_pdf_page(path, png):
                text = _run(png)
    else:
        text = _run(path)
    _cache[str(path)] = (st.st_mtime, st.st_size, text)
    return text

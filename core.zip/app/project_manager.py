"""Projektmapper på disken.

* Opretter A104-mappestrukturen med kode + navn, fx
  »C04 MYNDIGHED & INSTANSER\\C04.04 Myndighedskrav«.
* Læser et projekts filer og knytter dem til A104-mapperne ud fra mappenavnenes koder
  (virker også med mapper, der kun hedder »C04.04«).
* Foreslår placering og A104-filnavn for nye filer (via dokumentassistenten).
* Kopierer filer på plads – originalen røres aldrig.
* Tjekker projektet for filer, der ligger forkert eller ikke følger navngivningen.
"""
from __future__ import annotations

import hashlib
import os
import re
import shutil
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path

import file_search
import ocr
import title_block
from database import Database
from document_classifier import DocumentClassifier

DIR_CODE_RE = re.compile(r"^([CDP]\d{1,2}(?:\.[A-Z]?\d{1,2})?)(?=[\s_]|$)", re.IGNORECASE)
FILE_CODE_RE = re.compile(r"^([CDP]\d{1,2}(?:\.[A-Z]?\d{1,2})?)_", re.IGNORECASE)
MODEL_NAME_RE = re.compile(r"_A(?:\d{1,2}|x)_F\d{2}_K\d{2}_", re.IGNORECASE)
DRAWING_NAME_RE = re.compile(r"^(?:.+_)?K\d{2}_H\d_N\d{2}", re.IGNORECASE)
SERIAL_RE = re.compile(r"_N(\d+)(?=_|$)")
INVALID_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]+')
NOISE_RE = re.compile(
    r"\b(?:v|ver|version|rev)\s?\d+[a-z]?\b|\b\d{4}[-_.]?\d{2}[-_.]?\d{2}\b|\b\d{6,8}\b|"
    r"\b(?:final|endelig|kopi|copy|udkast|draft|ny|new)\b", re.IGNORECASE)
IGNORED_NAMES = {"desktop.ini", "thumbs.db", ".ds_store"}
MEDIA_EXTENSIONS = {".jpg", ".jpeg", ".png", ".heic", ".gif", ".bmp", ".tif", ".tiff", ".mp4", ".mov", ".avi", ".wmv"}
# CAD-/modelfiler -> filtype (F) efter Excel-arket
CAD_EXTENSIONS = {".rvt": "F02", ".rfa": "F10", ".rte": "F07", ".pln": "F02", ".dwg": "F01", ".dxf": "F01",
                  ".ifc": "F03", ".nwc": "F04", ".nwd": "F04", ".nwf": "F04", ".skp": "F13", ".3dm": "F02"}


def kb_drawing_hints():
    import knowledge_base as kb
    return kb.DRAWING_TYPE_HINTS


def is_ignored(name: str) -> bool:
    lower = name.lower()
    return lower in IGNORED_NAMES or lower.startswith("~$") or lower.startswith(".") or lower.endswith(".tmp")


def make_visible_in_sharepoint(path: Path, when: float | None = None) -> None:
    """En fil, der er lagt ind i projektet, skal ses som ny i SharePoint/Teams:
    * »Ændret« sættes til nu (eller `when`). Ellers viser SharePoint den gamle dato fra originalen
      (fx »Ændret 02-09-2026« for en fil lagt ind i dag), og holdet finder den ikke under seneste/sorteret efter dato.
    * Skjult/system/skrivebeskyttet fjernes – arvet fra originalen kan det få OneDrive til at springe filen over.
    Originalens dato huskes i databasen (file_origins.orig_modified)."""
    try:
        if os.name == "nt":
            import ctypes
            attrs = ctypes.windll.kernel32.GetFileAttributesW(str(path))
            if attrs != -1 and attrs != 0xFFFFFFFF and attrs & 0x7:  # READONLY | HIDDEN | SYSTEM
                ctypes.windll.kernel32.SetFileAttributesW(str(path), (attrs & ~0x7) or 0x80)
        os.utime(path, None if when is None else (when, when))
    except OSError:
        pass


EXTENSION_RE = re.compile(r"\.[A-Za-z0-9]{1,6}$")
COPY_SUFFIX_RE = re.compile(r"(?: \(\d+\)| - kopi(?: \(\d+\))?| - copy)$", re.IGNORECASE)


def split_name(name: str, default_ext: str = "") -> tuple[str, str]:
    """Deler et filnavn i navn og endelse. »Plantegning 1. sal« har ingen endelse (». sal« er ikke en endelse)."""
    m = EXTENSION_RE.search(name)
    if m and m.start() > 0:
        return name[:m.start()], name[m.start():]
    return name, default_ext


def with_extension(name: str, default_ext: str) -> str:
    stem, ext = split_name(name.strip(), default_ext)
    return stem + ext


def safe_name(text: str) -> str:
    text = INVALID_CHARS.sub("", text)
    return re.sub(r"\s+", " ", text).strip(" .")


def folder_dir_name(code: str, name: str) -> str:
    """Mappenavn på disken: kode + navn (Windows tillader ikke punktum til sidst)."""
    name = safe_name(name)
    return f"{code} {name}" if name else code


# Én A104-kode som selvstændigt ord – uanset om den står med _, mellemrum eller bindestreg omkring sig
CODE_TOKEN_RE = re.compile(
    r"^(?:[CD]\d{1,2}(?:\.[A-Z]?\d{1,2})?|P\d{1,2}|[BKMRW]\d{2}(?:\.\d{2})?|H\d|N\d{1,3}|E\d{2}|E0X|F\d{2}|"
    r"A\d{1,2}|(?-i:Ax)|Y\d{2,4}|J\d|G\d|S\d|X\d|(?-i:V\d{1,2}[A-Z]?|V[A-Z])|PROJEKT-ID)$", re.IGNORECASE)
CONTROL_TOKEN_RE = re.compile(r"^Q[A-ZÆØÅ]{2,5}\d{0,8}$")  # QALVA20261012
PROJECT_ID_TOKEN_RE = re.compile(r"^[A-ZÆØÅ]{2,6}(?:-[A-Za-z0-9]{1,12}){2,}$")  # BKN-MIL-F26-2H-G1
GENERIC_NAME_RE = re.compile(r"^(?:scan|scanning|img|image|billede|dsc|dcim|foto|photo|document|dokument|untitled|"
                             r"unavngivet|ny|new|fil|file|download|tegning|udklip|screenshot|skærmbillede)?[\s\d]*$",
                             re.IGNORECASE)


def _is_code(token: str, project_id="") -> bool:
    t = token.strip(" .-")
    if not t:
        return True
    ids = [project_id] if isinstance(project_id, str) else list(project_id or [])
    if any(i and t.lower() == i.lower() for i in ids):
        return True
    if CODE_TOKEN_RE.match(t) or CONTROL_TOKEN_RE.match(t) or PROJECT_ID_TOKEN_RE.match(t):
        return True
    parts = [p for p in t.split("-") if p]
    return len(parts) > 1 and all(CODE_TOKEN_RE.match(p) for p in parts)  # K01-H2-N01


def codes_in(text: str) -> dict[str, str]:
    """De første koder pr. liste i et navn: 'K01 H2 N01 Opstalt' -> {'K': 'K01', 'H': 'H2', 'N': 'N01'}.
    En konkret fase (A4) foretrækkes frem for pladsholderen Ax."""
    found: dict[str, str] = {}
    for token in re.split(r"[_\s\-]+", text):
        t = token.strip(" .")
        if not CODE_TOKEN_RE.match(t) or t.upper() in ("PROJEKT-ID", "PROJEKT", "ID"):
            continue
        family = "C" if t[0].upper() in "CD" else t[0].upper()
        value = t if family == "C" or t == "Ax" else t.upper()
        if family == "A" and found.get("A") == "Ax":
            found["A"] = value
        found.setdefault(family, value)
    return found


def _id_pattern(project_ids) -> re.Pattern | None:
    """Projekt-ID'er – også når de er skrevet med mellemrum i stedet for bindestreger (»BKON MIL E25 BJAog LST«)."""
    if isinstance(project_ids, str):
        project_ids = [project_ids]
    alts = []
    for pid in project_ids or []:
        chars = [ch for ch in re.sub(r"[\s_\-]+", "", pid or "")]
        if len(chars) >= 4:
            alts.append(r"[\s_\-]*".join(re.escape(ch) for ch in chars))
    alts.append(r"PROJEKT[\s_\-]*ID")
    return re.compile(rf"(?<![0-9A-Za-zÆØÅæøå])(?:{'|'.join(alts)})(?![0-9A-Za-zÆØÅæøå])", re.IGNORECASE)


def clean_name(text: str, project_id="") -> str:
    """Den beskrivende del af et navn uden koder og gentagelser:
    'C07 K01 N01 Plan Stue plan' -> 'Plan Stue', 'K01 H2 N01 K01 H2 N01 Opstalt S' -> 'Opstalt S'.
    `project_id` kan være ét ID eller en liste (alle projektets kendte ID'er)."""
    text = _id_pattern(project_id).sub(" ", file_search.fix_mojibake(text))
    words, seen = [], set()
    for token in re.split(r"[_\s]+", text):
        t = token.strip(" .")
        if _is_code(t, project_id):
            continue
        key = t.lower()
        if len(key) > 3 and key in seen:  # samme ord to gange (korte ord som »og« må gentages)
            continue
        seen.add(key)
        words.append(t)
    return " ".join(words).strip(" -")


def tidy_filename(stem: str, project_id: str = "") -> str:
    """Sikrer, at et foreslået navn har koderne én gang: koderne foran beholdes, koder gentaget i den
    beskrivende del fjernes, og løbenummer/version/kontrol (N/V/Q) står til sidst."""
    parts = [p for p in stem.split("_") if p != ""]
    head: list[str] = []
    while parts and _is_code(parts[0], project_id) and not CONTROL_TOKEN_RE.match(parts[0]):
        p = parts.pop(0)
        if p.upper() not in {h.upper() for h in head}:
            head.append(p)
    tail: list[str] = []
    while parts and re.fullmatch(r"N\d{1,3}|V\d{0,2}[A-Z]?|Q[A-ZÆØÅ]{2,5}\d{0,8}", parts[-1]):
        tail.insert(0, parts.pop())
    body_text = " ".join(parts)
    body = clean_name(body_text, project_id)
    if body.split(" ") == [w for w in re.split(r"[_\s]+", body_text) if w]:
        body = "_".join(parts)  # intet at rydde op – behold navnets egne skilletegn
    has_serial = any(re.fullmatch(r"N\d{1,3}", t, re.IGNORECASE) for t in head + tail)
    serial = codes_in(body_text).get("N")
    if serial and not has_serial:
        tail.insert(0, serial)
    if len(body) <= 1:  # en enlig rest som »F« fra et afkortet navn
        body = ""
    head_upper = {h.upper() for h in head}
    tail = [t for t in dict.fromkeys(tail) if t.upper() not in head_upper]
    return "_".join([*head, *([body] if body else []), *tail])


def is_generic(text: str) -> bool:
    """Navne der intet siger om indholdet, fx 'Scan_0012', 'IMG 1234', 'Dokument1'."""
    return bool(GENERIC_NAME_RE.match(text.strip())) or len(re.findall(r"[A-Za-zÆØÅæøå]", text)) < 3


def describe_filename(stem: str) -> str:
    """Gør et filnavn til en beskrivelse, fx 'Referat_projekteringsmøde_v2' -> 'Referat projekteringsmøde'."""
    text = re.sub(r"[_\-.+]+", " ", stem)
    text = re.sub(r"(?<=[a-zæøå])(?=[A-ZÆØÅ])", " ", text)  # KontrolPlan -> Kontrol Plan
    text = NOISE_RE.sub(" ", text)
    text = re.sub(r"\(\d+\)", " ", text)
    text = re.sub(r"\b\d{1,4}\b", " ", text)  # løse tal, fx datoer som 12-03
    return re.sub(r"\s+", " ", text).strip() or stem


@dataclass
class ProjectFile:
    path: Path
    folder_code: str | None
    size: int
    modified: datetime
    created: datetime | None = None  # hvornår filen kom ind i mappen (Windows: oprettet/kopieret/synkroniseret)

    @property
    def name(self) -> str:
        return self.path.name

    @property
    def activity(self) -> datetime:
        """Seneste aktivitet: lagt i mappen eller ændret – det seneste af de to."""
        return max(self.modified, self.created) if self.created else self.modified

    @property
    def added(self) -> bool:
        """True hvis den seneste aktivitet er, at filen er lagt i mappen (ikke en senere ændring)."""
        return bool(self.created) and self.created >= self.modified - timedelta(minutes=1)


@dataclass
class ProjectScan:
    root: Path
    folder_paths: dict[str, Path] = field(default_factory=dict)
    files: dict[str, list[ProjectFile]] = field(default_factory=lambda: defaultdict(list))
    outside: list[ProjectFile] = field(default_factory=list)

    @property
    def file_count(self) -> int:
        return sum(len(v) for v in self.files.values()) + len(self.outside)


@dataclass
class FileSuggestion:
    source: Path
    description: str
    folder_code: str | None
    folder_name: str
    probability: int
    new_name: str
    extension: str
    kind: str
    reason: str
    alternatives: list[tuple[str, str, int]] = field(default_factory=list)

    @property
    def filename(self) -> str:
        return self.new_name + self.extension


@dataclass
class DuplicateGroup:
    files: list[ProjectFile]
    identical: bool  # True = samme indhold (kopier foreslås slettet); False = samme navn, men forskelligt indhold
    note: str = ""   # fx når originalen kun ligger i OneDrive-skyen og ikke kunne læses


@dataclass
class DuplicateAction:
    """Det, der sker med en dublet-gruppe: `keep` beholdes, `remove` flyttes til papirkurven, og hvis `keep`
    er en »(2)«-kopi, får den bagefter det rene navn (`rename_to`) – så den nyeste version erstatter den gamle."""
    keep: Path
    remove: list[Path]
    rename_to: Path | None = None


def plan_for(keep: Path, remove: list[Path]) -> DuplicateAction:
    """Byg handlingen for en gruppe, når det er bestemt, hvilken fil der beholdes."""
    rename_to = None
    if is_copy_name(keep.name):
        clean = base_name(keep.name)
        for r in remove:  # den rene fil i samme mappe forsvinder – den nyeste overtager navnet
            if r.parent == keep.parent and r.name.lower() == clean:
                rename_to = r
                break
    return DuplicateAction(keep, list(remove), rename_to)


@dataclass
class EmptyFolder:
    path: Path
    empty_children: int  # tomme undermapper, der forsvinder sammen med mappen


def is_copy_name(name: str) -> bool:
    return bool(COPY_SUFFIX_RE.search(split_name(name)[0]))


def base_name(name: str) -> str:
    stem, ext = split_name(name)
    return (COPY_SUFFIX_RE.sub("", stem).strip() + ext).lower()


@dataclass
class Issue:
    file: ProjectFile
    problem: str
    suggested_code: str | None = None


class ProjectManager:
    def __init__(self, db: Database, classifier: DocumentClassifier):
        self.db = db
        self.classifier = classifier

    # ------------------------------------------------------------- struktur
    def folder_codes(self) -> set[str]:
        return {f["code"] for f in self.db.folders()}

    def expected_path(self, root: Path, code: str) -> Path:
        path = Path(root)
        for c, name in self.db.folder_path(code):
            path /= folder_dir_name(c, name)
        return path

    def create_structure(self, root: Path, structure: str | None = None) -> int:
        """Opretter alle mapper, der ikke allerede findes. Returnerer antal nye mapper.
        `structure` = navnet på en Molio A104c-mappestruktur (fx »…udvekslingsplatform, metode C«);
        uden struktur bruges A104-mapperne fra Excel-arket (C01–C11, D1, D2 …)."""
        root = Path(root)
        root.mkdir(parents=True, exist_ok=True)
        if structure:
            rows = self.db.structure_rows(structure)
            if rows:
                created = 0
                for r in rows:
                    rel = "\\".join(safe_name(part) for part in str(r["path"]).split("\\") if part)
                    target = root / rel
                    if not target.exists():
                        target.mkdir(parents=True, exist_ok=True)
                        created += 1
                return created
        existing = self.scan(root).folder_paths
        created = 0
        for f in self.db.folders():
            if f["code"] in existing:
                continue
            parent_path = existing.get(f["parent_code"]) if f["parent_code"] else root
            if parent_path is None:
                parent_path = self.expected_path(root, f["parent_code"])
            target = parent_path / folder_dir_name(f["code"], f["name"])
            if not target.exists():
                target.mkdir(parents=True, exist_ok=True)
                created += 1
            existing[f["code"]] = target
        return created

    def scan(self, root: Path) -> ProjectScan:
        root = Path(root)
        result = ProjectScan(root)
        if not root.exists():
            return result
        codes = {c.upper(): c for c in self.folder_codes()}
        dir_code: dict[str, str | None] = {str(root): None}
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = sorted(d for d in dirnames if not is_ignored(d))
            current = Path(dirpath)
            inherited = dir_code.get(str(current.parent)) if current != root else None
            own = inherited
            if current != root:
                m = DIR_CODE_RE.match(current.name)
                if m and m.group(1).upper() in codes:
                    own = codes[m.group(1).upper()]
                    result.folder_paths.setdefault(own, current)
            dir_code[str(current)] = own
            for fn in sorted(filenames, key=str.lower):
                if is_ignored(fn):
                    continue
                path = current / fn
                try:
                    stat = path.stat()
                except OSError:
                    continue
                pf = ProjectFile(path, own, stat.st_size, datetime.fromtimestamp(stat.st_mtime),
                                 datetime.fromtimestamp(stat.st_ctime))  # Windows: ctime = lagt i mappen
                if own:
                    result.files[own].append(pf)
                else:
                    result.outside.append(pf)
        return result

    @staticmethod
    def find_empty_folders(root: Path, keep: set[Path] | frozenset = frozenset()) -> list[EmptyFolder]:
        """Mapper under root uden filer – heller ikke i undermapper. Kun den øverste tomme mappe i en gren
        returneres (dens tomme undermapper følger med). Mapper i »keep« returneres aldrig, men deres tomme
        undermapper gør. desktop.ini, Thumbs.db o.l. tæller ikke som indhold; skjulte mapper (fx .git) gør."""
        root = Path(root)
        if not root.is_dir():
            return []
        keep = {str(p) for p in keep} | {str(root)}
        has_content: dict[str, bool] = {}
        subtree: dict[str, int] = {}  # antal tomme mapper i grenen, inkl. mappen selv
        children: dict[str, list[str]] = defaultdict(list)
        for dirpath, dirnames, filenames in os.walk(root, topdown=False, onerror=lambda _e: None):
            content = any(not is_ignored(f) for f in filenames) or any(is_ignored(d) for d in dirnames)
            kids = [str(Path(dirpath) / d) for d in dirnames if not is_ignored(d)]
            children[dirpath] = kids
            content = content or any(has_content.get(k, True) for k in kids)
            if not content:
                try:  # mapper vi ikke kan læse, tæller som »ikke tomme«
                    os.listdir(dirpath)
                except OSError:
                    content = True
            has_content[dirpath] = content
            subtree[dirpath] = 0 if content else 1 + sum(subtree.get(k, 0) for k in kids)

        result: list[EmptyFolder] = []

        def collect(path: str) -> None:
            for kid in sorted(children.get(path, []), key=str.lower):
                if not has_content.get(kid, True) and kid not in keep:
                    result.append(EmptyFolder(Path(kid), subtree[kid] - 1))
                elif kid in has_content:
                    collect(kid)

        collect(str(root))
        return result

    def resolve_folder(self, root: Path, code: str, scan: ProjectScan | None = None) -> Path:
        scan = scan or self.scan(root)
        path = scan.folder_paths.get(code)
        if path is None:
            parent = self.db.folder(code)
            parent_code = parent["parent_code"] if parent else None
            base = self.resolve_folder(root, parent_code, scan) if parent_code else Path(root)
            path = base / folder_dir_name(code, self.db.folder_name(code))
            scan.folder_paths[code] = path
        path.mkdir(parents=True, exist_ok=True)
        return path

    # -------------------------------------------------------------- forslag
    def file_code(self, filename: str) -> str | None:
        m = FILE_CODE_RE.match(filename)
        if not m:
            return None
        codes = {c.upper(): c for c in self.folder_codes()}
        return codes.get(m.group(1).upper())

    def has_children(self, code: str | None) -> bool:
        return bool(code) and any(c.startswith(code + ".") for c in self.folder_codes())

    # ----------------------------------------------------- flere spor til placering
    GENERIC_DIRS = {"downloads", "overførsler", "desktop", "skrivebord", "documents", "dokumenter", "users", "onedrive",
                    "temp", "tmp", "appdata", "local", "mine filer", "my files", "attachments", "vedhæftede filer",
                    "microsoft teams chat files", "microsoft teams-chatfiler", "nyt", "ny mappe", "new folder", "diverse",
                    "andet", "filer", "files", "shared documents", "delte dokumenter", "documents - kopi"}
    EXT_PRIORS = {".mpp": ("C11.02", "MS Project-fil (tidsplan)"), ".mpx": ("C11.02", "MS Project-fil (tidsplan)"),
                  ".xer": ("C11.02", "Primavera-fil (tidsplan)"), ".pod": ("C11.02", "Projektplan-fil"),
                  ".bcf": ("C10.01", "BCF-fil med kommentarer fra granskning"),
                  ".bcfzip": ("C10.01", "BCF-fil med kommentarer fra granskning"),
                  ".ifc": ("C07.02", "IFC-model"), ".nwd": ("C07.02", "Navisworks-model"),
                  ".nwc": ("C07.02", "Navisworks-model"), ".skp": ("C07.02", "SketchUp-model"),
                  ".3dm": ("C07.02", "Rhino-model")}

    @staticmethod
    def placement_tokens(*texts: str) -> set[str]:
        """Betydningsfulde ord til læring (uden koder, tal, fyldord og meget korte ord)."""
        import knowledge_base as kb
        from search_engine import tokenize
        out = set()
        for text in texts:
            for t in tokenize(text or ""):
                if len(t) >= 4 and not t.isdigit() and t not in kb.STOPWORDS and not CODE_TOKEN_RE.fullmatch(t.upper()):
                    out.add(t)
        return out

    def _rank_from(self, text: str, project_id: str, within: str | None) -> list[tuple[str, int]]:
        if not text or not text.strip():
            return []
        c = self.classifier.classify(describe_filename(text), project_id, False, within=within)
        if not c.best:
            return []
        return [(c.best.folder_code, c.best.probability)] + [(a.folder_code, a.probability) for a in c.alternatives]

    def placement_signals(self, source: Path, prof, scan: ProjectScan | None, project_id: str,
                          within: str | None) -> list[tuple[str, float, str]]:
        """Alle spor for, hvor filen hører hjemme: [(mappekode, vægt 0–1, begrundelse)]."""
        codes = set(self.folder_codes())
        ids = self.known_ids(project_id)
        stem = source.stem
        out: list[tuple[str, float, str]] = []

        def add_ranked(ranked, weight: float, label: str) -> None:
            for i, (code, prob) in enumerate(ranked[:3]):
                w = weight * prob / 100 * (1.0 if i == 0 else 0.6)
                if w >= 0.08:
                    out.append((code, w, f"{label} ({prob} %)" if i == 0 else f"{label} – alternativ"))

        # 1) filnavnet (»Dokument1«, »scan_0012« o.l. siger intet)
        if not is_generic(clean_name(stem, ids)) and not re.fullmatch(r"(?i)(?:scan|img|dsc|image|pxl|foto|document)"
                                                                      r"[\s_-]*\d*", clean_name(stem, ids).strip()):
            add_ranked(self._rank_from(stem, project_id, within), 1.0, "filnavnet")
        # 2) dokumentets egenskaber og indhold – renset for projekt-ID, firmanavne og »Udarbejdet af …«
        def tidy(text: str) -> str:
            text = re.sub(r"(?i)\b(?:(?:udarbejdet|tegnet|skrevet|kontrolleret)\s+af\b|(?:referent|dato|side|"
                          r"rev(?:ision)?|af)\s*:).*?(?=[–·|]|$)", " ", text or "")
            text = re.sub(r"\b[\w&.-]+\s+(?:ApS|A/S|I/S|P/S|IVS)\b", " ", text)
            parts = [p.strip() for p in re.split(r"\s[–·|]\s", text) if p.strip()]
            parts = [p for p in parts if clean_name(p, ids).strip()]  # dele, der kun er projekt-ID/koder, droppes
            return clean_name(" ".join(parts), ids).strip()
        for raw, weight, label in ((prof.title, 0.9, "titlen"), (prof.subject, 0.75, "emne/nøgleord"),
                                   (prof.heading, 0.75, "overskriften")):
            text = tidy(raw)
            if len(text) >= 4 and not is_generic(text):
                add_ranked(self._rank_from(text, project_id, within), weight, f"{label} »{text[:50]}«")
        if prof.body:
            add_ranked(self._rank_from(tidy(prof.body[:1200]), project_id, within), 0.4, "teksten i filen")
        # 3) mappen filen kommer fra
        parts = [p for p in source.parent.parts[1:]][-4:]
        for depth, seg in enumerate(reversed(parts)):
            m = FILE_CODE_RE.match(seg.replace(" ", "_") + "_")
            code = None
            if m:
                code = {c.upper(): c for c in codes}.get(m.group(1).upper())
            if code and (not within or code.startswith(within + ".")):
                out.append((code, 0.95 - 0.1 * depth, f"den kom fra mappen »{seg}«"))
                break
        for depth, seg in enumerate(reversed(parts[-2:])):
            if seg.lower() in self.GENERIC_DIRS or CODE_TOKEN_RE.fullmatch(seg.upper()) or len(seg) < 4:
                continue
            add_ranked(self._rank_from(seg, project_id, within), 0.7 - 0.15 * depth, f"mappen »{seg}« den kom fra")
        # 4) lignende filer, der allerede ligger i projektet (fx »Mødereferat 07« ~ »C06.18_Mødereferat_05«)
        if scan is not None:
            from rapidfuzz import fuzz
            mine = re.sub(r"\d+", " ", clean_name(stem, ids)).strip().lower()
            if len(mine) >= 5 and not is_generic(mine):
                best = None
                for code, files in scan.files.items():
                    if within and not code.startswith(within + "."):
                        continue
                    for pf in files:
                        if pf.path == source:
                            continue
                        theirs = re.sub(r"\d+", " ", clean_name(pf.path.stem, ids)).strip().lower()
                        if len(theirs) < 5:
                            continue
                        r = fuzz.token_set_ratio(mine, theirs)
                        if r >= 70 and (best is None or r > best[0]):  # filserier: »LCA Kviste« ~ »LCA Døre«
                            best = (r, code, pf.name)
                if best:
                    out.append((best[1], 0.85 * best[0] / 100, f"ligner »{best[2]}«, der allerede ligger i projektet"))
        # 5) det, du tidligere har rettet
        tokens = self.placement_tokens(clean_name(stem, ids), prof.title)
        if tokens:
            votes = self.db.placement_votes(tokens)
            tally: dict[str, int] = defaultdict(int)
            for by_code in votes.values():
                for code, n in by_code.items():
                    tally[code] += n
            if tally:
                code, n = max(tally.items(), key=lambda kv: kv[1])
                share = n / sum(tally.values())
                if code in codes and share >= 0.6 and (not within or code.startswith(within + ".")):
                    words = ", ".join(sorted(t for t, v in votes.items() if code in v)[:3])
                    out.append((code, min(0.9, 0.55 + 0.1 * n) * share,
                                f"du har før lagt filer med »{words}« i {code}"))
        # 6) filtype og sideformat
        prior = self.EXT_PRIORS.get(source.suffix.lower())
        if prior and prior[0] in codes and (not within or prior[0].startswith(within + ".")):
            out.append((prior[0], 0.75, prior[1]))
        if prof.large_format and "C07.01" in codes and (not within or "C07.01".startswith(within + ".")):
            out.append(("C07.01", 0.7, f"stort sideformat ({prof.pages} side{'r' if prof.pages != 1 else ''}) – "
                                       "typisk en tegning"))
        if prof.is_drawing and source.suffix.lower() == ".pdf" and "C07.01" in codes \
                and (not within or "C07.01".startswith(within + ".")):
            out.append(("C07.01", 0.7, "tegningshoved i filen (Tegn. nr., mål …)"))
        return [s for s in out if s[0] in codes]

    @staticmethod
    def combine_signals(signals: list[tuple[str, float, str]]) -> list[tuple[str, int, list[str]]]:
        """Saml sporene pr. mappe (noisy-or). En undermappe arver halvdelen af sin hovedmappes spor.
        Returnerer [(kode, sikkerhed %, begrundelser)] bedste først."""
        score: dict[str, float] = {}
        reasons: dict[str, list[str]] = defaultdict(list)
        for code, w, why in signals:
            score[code] = 1 - (1 - score.get(code, 0.0)) * (1 - min(w, 0.97))
            reasons[code].append(why)
        for code in list(score):
            if "." in code:
                parent = code.split(".")[0]
                if parent in score:
                    score[code] = 1 - (1 - score[code]) * (1 - 0.5 * score[parent])
        ranked = sorted(score.items(), key=lambda kv: -kv[1])
        if not ranked:
            return []
        out = []
        second = ranked[1][1] if len(ranked) > 1 else 0.0
        for i, (code, s) in enumerate(ranked[:4]):
            p = s * (1 - 0.35 * second) if i == 0 else s * 0.8
            out.append((code, max(1, min(98, round(100 * p))), list(dict.fromkeys(reasons[code]))))
        return out

    def suggest(self, source: Path, forced_code: str | None = None, project_id: str = "",
                scan: ProjectScan | None = None) -> FileSuggestion:
        """Foreslår mappe og filnavn. `forced_code` er den mappe, filen blev sluppet på:
        en undermappe bruges som den er, en hovedmappe betyder »find den rigtige undermappe i den«."""
        source = Path(source)
        stem, ext = source.stem, source.suffix
        ids = self.known_ids(project_id)
        within = None
        if forced_code and self.has_children(forced_code):
            within, forced_code = forced_code, None
        existing_code = self.file_code(source.name)
        if existing_code and not forced_code and not self.has_children(existing_code) \
                and (not within or existing_code.startswith(within + ".")):
            return FileSuggestion(source, stem, existing_code, self.db.folder_name(existing_code), 100,
                                  self.finish_name(stem, ids), ext, "document",
                                  "Filnavnet starter allerede med mappekoden.")

        description = describe_filename(stem)
        name_codes = codes_in(stem)
        readable = describe_filename(clean_name(stem, ids))  # navnet uden koder og gentagelser
        c = self.classifier.classify(description, project_id, False, within=within)
        lower_ext = ext.lower()
        weak = not c.best or c.probability < 50

        # Kig ind i filen: titel, overskrift og tegningshoved giver ofte en bedre placering end filnavnet
        content_note = ""
        look = file_search.peek(source) if source.exists() else file_search.Peek()
        generic = is_generic(readable)
        if look.text and (weak or generic):
            c2 = self.classifier.classify(describe_filename(look.text), project_id, False, within=within)
            if c2.best and (generic or c2.probability > c.probability + 5):
                c = c2
                weak = c.probability < 50
                content_note = f" Placeringen er fundet ud fra filens indhold: »{look.text[:80]}«."
                if generic:
                    readable = clean_name(look.title or look.heading, ids)[:60] or readable
        # flere spor vejet sammen: navn, egenskaber, indhold, oprindelsesmappe, lignende filer, læring, format
        prof = file_search.profile(source) if source.exists() else file_search.Profile()
        # scannet dokument (ingen tekst i filen, fx »00012345.pdf«) – læs teksten med Windows' tekstgenkendelse
        if source.exists() and not prof.body.strip() and not prof.title and not prof.large_format \
                and (lower_ext == ".pdf" or (lower_ext in ocr.IMAGE_EXT and generic)):
            text = ocr.read_text(source)
            if len(re.findall(r"[A-Za-zÆØÅæøå]{3,}", text)) >= 6:  # et billede med lidt skilt-tekst er stadig et foto
                import dataclasses
                prof = dataclasses.replace(prof, body=text[:6000], heading=file_search._heading(text))
                content_note += " Teksten er læst med tekstgenkendelse (scannet dokument)."
                if weak or generic:
                    c2 = self.classifier.classify(describe_filename(prof.heading or text[:200]), project_id, False,
                                                  within=within)
                    if c2.best:
                        c = c2
                        weak = c.probability < 50
                if generic:
                    readable = clean_name(prof.heading.split(" – ")[0], ids)[:60] or readable
        # tegningshovedet nederst til højre: titel, tegningsnummer, målestok, fase, fag, revision
        tb = title_block.TitleBlock()
        if lower_ext == ".pdf" and source.exists():
            drawingish = look.is_drawing or prof.large_format
            tb = title_block.read(source, allow_ocr=drawingish)
            if not (drawingish or (tb.scale and (tb.title or tb.number))):
                tb = title_block.TitleBlock()  # et almindeligt dokument – hjørnet er ikke et tegningshoved
        signals = [] if forced_code else self.placement_signals(source, prof, scan, project_id, within)
        if tb.found and not forced_code and "C07.01" in self.folder_codes() \
                and (not within or "C07.01".startswith(within + ".")):
            signals.append(("C07.01", 0.85, f"tegningshoved: {tb.summary()}"))
            if tb.title:
                for code_, prob_ in self._rank_from(tb.title, project_id, within)[:1]:
                    signals.append((code_, 0.6 * prob_ / 100, f"tegningens titel »{tb.title}«"))
        if tb.found:
            for family, value in (("K", tb.discipline), ("H", tb.drawing_type),
                                  ("N", tb.a104[-3:] if tb.a104 else "")):
                if value:
                    name_codes.setdefault(family, value)
            if tb.title:
                readable = clean_name(tb.title, ids)[:60] or readable
                if tb.number and not tb.a104:  # firmaets eget tegningsnummer bevares i navnet
                    readable = f"{readable} {tb.number}"
            content_note += (f" Tegningshoved{' (læst med tekstgenkendelse)' if tb.via_ocr else ''}: "
                             f"{tb.summary()}.")
        combined = [] if forced_code else self.combine_signals(signals)
        if combined:
            weak = combined[0][1] < 50
        code = forced_code or (combined[0][0] if combined else (c.best.folder_code if c.best else None))
        content_probability = 0
        if (prof.large_format or tb.found) and lower_ext == ".pdf" and code and code.startswith("C07"):
            c.doc_kind = "drawing"
        prior = self.EXT_PRIORS.get(lower_ext)
        if prior and code == prior[0] and not code.startswith("C07"):
            c.doc_kind = "document"  # fx en tidsplan i MS Project er ikke en tegning, selv om navnet siger »plan«
        if look.is_drawing and lower_ext == ".pdf":
            drawing_folder = "C07.01" if self.db.folder("C07.01") else "C07"
            # tegningshovedet afgør kun placeringen, hvis de andre spor ikke klart peger et andet sted hen
            # (fx »Granskning af tegninger.pdf« indeholder tegninger, men hører til i C10.01 Granskning)
            strong_elsewhere = bool(combined) and combined[0][1] >= 70 and not combined[0][0].startswith("C07")
            if not forced_code and (not code or not code.startswith("C07")) and not strong_elsewhere \
                    and (not within or drawing_folder.startswith(within + ".")):
                code = drawing_folder
                content_probability = 90
                content_note += " Filen har et tegningshoved (Tegn. nr., mål …) og placeres som tegning."
            if code and code.startswith("C07"):
                c.doc_kind = "drawing"
                if look.drawing_number:
                    for family, value in zip("KHN", look.drawing_number.split("_")):
                        name_codes.setdefault(family, value)

        model_folder = "C07.02" if self.db.folder("C07.02") else "C07"
        if lower_ext in (".dwg", ".dxf") and self.db.folder("C07.01"):
            model_folder = "C07.01"  # F01 Tegningsfil -> Tegning
        elif lower_ext in (".rfa", ".rte") and self.db.folder("C07.04"):
            model_folder = "C07.04"  # families og skabeloner -> Applikationsfiler
        k = name_codes.get("K") or (c.knowledge_area[0] if c.knowledge_area else "K01")
        if lower_ext in CAD_EXTENSIONS and forced_code in (None, "C07", model_folder) \
                and (not within or model_folder.startswith(within + ".")):
            phase = name_codes.get("A") or (c.phase[0] if c.phase else "Ax")
            f_code = name_codes.get("F") or CAD_EXTENSIONS[lower_ext]
            new_name = f"{project_id or 'PROJEKT-ID'}_{phase}_{f_code}_{k}_{safe_name(readable)[:60]}"
            reason = "CAD-/modelfil: Projekt-ID_Fase_Filtype_Vidensområde_Navn."
            if phase == "Ax":
                reason += " Erstat »Ax« med den aktuelle fase."
            return FileSuggestion(source, description, model_folder, self.db.folder_name(model_folder), 95,
                                  self.finish_name(new_name, ids), ext, "model", reason)
        if lower_ext in MEDIA_EXTENSIONS and weak and not forced_code and self.db.folder("C05.06") \
                and (not within or "C05.06".startswith(within + ".")):
            label = readable
            if is_generic(readable):  # »20261012_143522« / »IMG_1234« -> »Foto_2026-10-12«
                kind = "Video" if lower_ext in {".mp4", ".mov", ".avi", ".wmv"} else "Foto"
                m = re.search(r"(20\d{2})[-_]?([01]\d)[-_]?([0-3]\d)", stem)
                try:
                    when = f"{m.group(1)}-{m.group(2)}-{m.group(3)}" if m else \
                        datetime.fromtimestamp(source.stat().st_mtime).strftime("%Y-%m-%d")
                except OSError:
                    when = ""
                label = f"{kind} {when}".strip()
            return FileSuggestion(source, description, "C05.06", self.db.folder_name("C05.06"), 85,
                                  self.finish_name(f"C05.06_{k}_{label}", ids), ext, "document",
                                  "Billeder og video placeres i ANALYSE → Foto og video.")
        if not code:
            return FileSuggestion(source, description, None, "", 0, safe_name(stem), ext, c.doc_kind,
                                  "Ingen sikker placering – vælg mappen selv.")
        probability = 100 if forced_code else max(c.probability, content_probability)
        alternatives = [(a.folder_code, a.folder_name, a.probability) for a in c.alternatives]
        signal_note = ""
        if combined and not forced_code:
            win = next((x for x in combined if x[0] == code), None)
            if win:
                probability = max(win[1], content_probability)
                signal_note = " Spor: " + "; ".join(win[2][:5]) + "."
            alternatives = [(a, self.db.folder_name(a), p) for a, p, _r in combined if a != code][:3]

        if c.doc_kind == "drawing":
            h = name_codes.get("H") or (c.drawing_type[0] if c.drawing_type else "H0")
            n = name_codes.get("N") or "N01"  # løbenummeret tælles op i projektmappen ved kopiering
            new_name = f"{k}_{h}_{n}_{'' if is_generic(readable) else readable}"  # »Document1« siger intet
            reason = "Tegning: Vidensområde_Afbildningstype_Løbenummer_Navn."
        elif c.doc_kind == "model":
            new_name = c.filename
            reason = "Model/CAD-fil: Projekt-ID_Fase_Filtype_Vidensområde_Navn."
        else:
            new_name = c.filename
            if c.best and code != c.best.folder_code and new_name.startswith(c.best.folder_code + "_"):
                new_name = code + new_name[len(c.best.folder_code):]
            if name_codes.get("K"):  # brug vidensområdet fra det oprindelige navn
                new_name = re.sub(r"(?<=_)K\d{2}(?=_)", name_codes["K"], new_name, count=1)
            reason = c.explanation if c.best and c.best.folder_code == code else \
                f"Placeret i {code} {self.db.folder_name(code)}."
        reason += content_note + signal_note
        if forced_code:
            reason = "Du har valgt mappen. " + reason
        return FileSuggestion(source, description, code, self.db.folder_name(code), probability,
                              self.finish_name(new_name, ids), ext, c.doc_kind, reason, alternatives)

    @staticmethod
    def finish_name(name: str, project_id: str = "", max_body: int = 60) -> str:
        """Koderne én gang, ingen gentagelser, og en beskrivende del på højst `max_body` tegn."""
        stem = tidy_filename(safe_name(name), project_id)
        parts = stem.split("_")
        for i, part in enumerate(parts):
            if not _is_code(part, project_id) and len(part) > max_body:
                parts[i] = part[:max_body].rsplit(" ", 1)[0].strip(" ,.-")
        return safe_name("_".join(parts))

    @staticmethod
    def rename_for_folder(s: FileSuggestion, new_code: str, new_name_of_folder: str) -> None:
        if s.folder_code and s.new_name.startswith(s.folder_code + "_"):
            s.new_name = new_code + s.new_name[len(s.folder_code):]
        s.folder_code = new_code
        s.folder_name = new_name_of_folder

    # ------------------------------------------------------------ kopiering
    @staticmethod
    def next_free_path(folder: Path, stem: str, ext: str) -> Path:
        m = SERIAL_RE.search(stem)
        if m and folder.exists():
            prefix, suffix = stem[:m.start()], stem[m.end():]
            pattern = re.compile(re.escape(prefix) + r"_N(\d+)", re.IGNORECASE)
            used = set()
            for p in folder.iterdir():
                hit = pattern.match(p.stem)
                if hit:
                    used.add(int(hit.group(1)))
            n = int(m.group(1))
            while n in used:
                n += 1
            stem = f"{prefix}_N{n:02d}{suffix}"
        candidate = folder / f"{stem}{ext}"
        i = 2
        while candidate.exists():
            candidate = folder / f"{stem} ({i}){ext}"
            i += 1
        return candidate

    @staticmethod
    def is_inside(root: Path, path: Path) -> bool:
        try:
            Path(path).resolve().relative_to(Path(root).resolve())
            return True
        except ValueError:
            return False

    def copy_into_project(self, root: Path, source: Path, code: str, filename: str,
                          scan: ProjectScan | None = None, move: bool = False) -> tuple[Path, bool]:
        """Kopierer filen ind i projektets A104-mappe – originalen bevares.

        Returnerer (sti, sprunget_over). Ligger der allerede en fil med præcis samme indhold i mappen,
        kopieres der ikke igen (så der ikke opstår »(2)«-dubletter).
        `move=True` bruges kun til filer, der allerede ligger i projektet og skal rykkes på plads."""
        source = Path(source)
        folder = self.resolve_folder(root, code, scan)
        stem, ext = split_name(safe_name(filename), source.suffix)
        if move and source.parent.resolve() == folder.resolve() and source.name == f"{stem}{ext}":
            return source, False
        existing = self.identical_in_folder(folder, source)
        if existing is not None:
            return existing, True
        target = self.next_free_path(folder, stem, ext)
        if move and self.is_inside(root, source):
            shutil.move(str(source), str(target))
        else:
            shutil.copy2(source, target)
            make_visible_in_sharepoint(target)
        return target, False

    # ------------------------------------------------------------- dubletter
    @staticmethod
    def file_hash(path: Path) -> str:
        digest = hashlib.sha256()
        with open(path, "rb") as fh:
            for chunk in iter(lambda: fh.read(1 << 20), b""):
                digest.update(chunk)
        return digest.hexdigest()

    def _keep_priority(self, pf: ProjectFile) -> tuple:
        """Lavest = bedst at beholde: korrekt navn/placering, ingen »(2)«-kopi, ligger i A104, ældst."""
        ok, _ = self.naming_status(pf)
        is_copy = bool(COPY_SUFFIX_RE.search(pf.path.stem))
        return (not ok, is_copy, pf.folder_code is None, pf.modified, len(pf.name), pf.name.lower())

    def find_duplicates(self, scan: ProjectScan) -> list[DuplicateGroup]:
        """Finder dubletter:

        1. Filer med præcis samme indhold (SHA-256) – uanset navn og mappe.
        2. »(2)«-/»- kopi«-filer, hvis originalnavn findes i samme mappe, men med andet indhold.

        Den første fil i hver gruppe er forslaget til, hvilken der beholdes."""
        files = [pf for group in scan.files.values() for pf in group] + list(scan.outside)
        by_size: dict[int, list[ProjectFile]] = defaultdict(list)
        for pf in files:
            if pf.size > 0:
                by_size[pf.size].append(pf)
        groups: list[DuplicateGroup] = []
        in_identical: set[Path] = set()
        unreadable: set[Path] = set()  # fx OneDrive-filer, der kun ligger i skyen
        for same_size in by_size.values():
            if len(same_size) < 2:
                continue
            by_hash: dict[str, list[ProjectFile]] = defaultdict(list)
            for pf in same_size:
                try:
                    by_hash[self.file_hash(pf.path)].append(pf)
                except OSError:
                    unreadable.add(pf.path)
                    continue
            for g in by_hash.values():
                if len(g) > 1:
                    groups.append(DuplicateGroup(sorted(g, key=self._keep_priority), True))
                    in_identical.update(pf.path for pf in g)

        by_name: dict[tuple[str, str], list[ProjectFile]] = defaultdict(list)
        for pf in files:
            by_name[(str(pf.path.parent).lower(), base_name(pf.name))].append(pf)
        for same_name in by_name.values():
            copies = [pf for pf in same_name if is_copy_name(pf.name) and pf.path not in in_identical]
            if not copies:
                continue
            original = sorted((pf for pf in same_name if not is_copy_name(pf.name)), key=self._keep_priority)[:1]
            # Kan indholdet ikke læses (fx OneDrive »kun i skyen«), sammenlignes på navn + præcis samme størrelse
            likely = [c for c in copies if original and c.size == original[0].size and c.size > 0
                      and (original[0].path in unreadable or c.path in unreadable)]
            likely_paths = {c.path for c in likely}
            different = sorted((c for c in copies if c.path not in likely_paths), key=lambda p: p.name.lower())
            if likely:
                groups.append(DuplicateGroup(
                    original + sorted(likely, key=lambda p: p.name.lower()), True,
                    "Samme navn og præcis samme størrelse – originalen ligger kun i skyen (OneDrive) og kunne "
                    "ikke sammenlignes byte for byte."))
            if different and (original or len(different) > 1):
                groups.append(DuplicateGroup(original + different, False))

        groups.sort(key=lambda g: (not g.identical, -g.files[0].size * (len(g.files) - 1), g.files[0].name.lower()))
        return groups

    def newest_first(self, files: list[ProjectFile]) -> list[ProjectFile]:
        """Den nyeste fil først (den beholdes som standard); ved samme tid: korrekt navn/placering først."""
        return sorted(files, key=lambda pf: (-pf.modified.timestamp(), self._keep_priority(pf)))

    def default_plan(self, group: DuplicateGroup) -> DuplicateAction:
        """Standard: behold den nyeste – de andre i gruppen (samme indhold eller ældre versioner med samme navn)
        flyttes til papirkurven, og den nyeste overtager det rene navn, hvis den er en »(2)«-kopi."""
        ordered = self.newest_first(group.files)
        return plan_for(ordered[0].path, [pf.path for pf in ordered[1:]])

    @staticmethod
    def apply_plan(action: DuplicateAction, trash) -> tuple[list[Path], Path | None, list[str]]:
        """Udfør en plan. `trash(paths) -> [navne der ikke kunne flyttes]`.
        Returnerer (flyttet til papirkurven, ny sti for den beholdte fil hvis omdøbt, fejl)."""
        failed = trash(action.remove)
        removed = [p for p in action.remove if p.name not in failed and not p.exists()]
        renamed = None
        errors = [f"{n}: kunne ikke flyttes til papirkurven (er den åben?)" for n in failed]
        if action.rename_to is not None and action.rename_to in removed and action.keep.exists():
            try:
                action.keep.rename(action.rename_to)
                renamed = action.rename_to
            except OSError as exc:
                errors.append(f"{action.keep.name}: kunne ikke omdøbes til {action.rename_to.name}: {exc}")
        return removed, renamed, errors

    def identical_in_folder(self, folder: Path, source: Path) -> Path | None:
        """Findes en fil med præcis samme indhold allerede i mappen?"""
        if not folder.exists():
            return None
        try:
            size = source.stat().st_size
        except OSError:
            return None
        source_hash = None
        for p in folder.iterdir():
            try:
                if not p.is_file() or p.stat().st_size != size or p.resolve() == source.resolve():
                    continue
                source_hash = source_hash or self.file_hash(source)
                if self.file_hash(p) == source_hash:
                    return p
            except OSError:
                continue
        return None

    # ------------------------------------------------------------- giv kode
    def known_ids(self, project_id: str = "") -> list[str]:
        """Alle projekt-ID'er programmet kender – så gamle ID'er i filnavne kan genkendes og fjernes."""
        ids = [project_id] if project_id else []
        try:
            ids += [p["project_id"] for p in self.db.projects() if p["project_id"]]
            meta = self.db.get_meta("excel_project_id")
            if meta:
                ids.append(meta)
        except Exception:  # databasen er ikke klar – brug bare det angivne ID
            pass
        return list(dict.fromkeys(ids))

    @staticmethod
    def strip_codes(stem: str, project_id="") -> str:
        """Fjerner alle A104-koder foran navnet: 'C05.01_K09_Beregning' -> 'Beregning',
        'PROJEKT-ID_A4_F02_K01_Model' -> 'Model'. Resten af navnet (og dets skilletegn) bevares."""
        parts = stem.split("_")
        while len(parts) > 1 and _is_code(parts[0], project_id):
            parts.pop(0)
        return "_".join(parts).strip(" _-") or stem

    def code_suggestion(self, path: Path, current_code: str | None, project_id: str = "") -> FileSuggestion:
        """Forslag til A104-navn for en fil i projektet. Det beskrivende navn bevares; koden kommer fra
        mappen filen ligger i (eller findes automatisk, hvis den ligger i en hovedmappe/uden for A104)."""
        path = Path(path)
        ext = path.suffix
        if current_code and not self.has_children(current_code):
            code, probability, reason = current_code, 100, "Koden svarer til mappen, filen ligger i."
        else:
            s = self.suggest(path, current_code, project_id)
            code, probability = s.folder_code, s.probability
            reason = "Filen ligger ikke i en undermappe – mappen er fundet automatisk, og filen flyttes dertil."
        if not code:
            return FileSuggestion(path, path.stem, None, "", 0, path.stem, ext, "document",
                                  "Ingen sikker mappe – vælg den selv.")
        # Koder, der allerede står i navnet (også med mellemrum, fx »K01 H2 N01«), genbruges – de gentages ikke
        name_codes = codes_in(path.stem)
        ids = self.known_ids(project_id)
        stem = self.strip_codes(path.stem, ids)
        look = file_search.peek(path)
        if is_generic(clean_name(stem, ids)) and (look.title or look.heading):
            stem = clean_name(look.title or look.heading, ids)[:60]
            reason += f" Navnet er taget fra filens indhold: »{stem}«."
        if look.drawing_number:
            for family, value in zip("KHN", look.drawing_number.split("_")):
                name_codes.setdefault(family, value)
        if code == "C07.01" and ext.lower() == ".pdf":  # tegningshovedet: fag, afbildningstype, nummer og titel
            tb = title_block.read(path)
            if tb.found:
                for family, value in (("K", tb.discipline), ("H", tb.drawing_type),
                                      ("N", tb.a104[-3:] if tb.a104 else "")):
                    if value:
                        name_codes.setdefault(family, value)
                if tb.title and is_generic(clean_name(stem, ids)):
                    stem = clean_name(tb.title, ids)[:60] + (f" {tb.number}" if tb.number and not tb.a104 else "")
                reason += f" Tegningshoved: {tb.summary()}."
        c = self.classifier.classify(describe_filename(" ".join(t for t in (stem, look.title) if t)), project_id)
        k = name_codes.get("K") or (c.knowledge_area[0] if c.knowledge_area else "K01")
        kind = "document"
        if code == "C07.02" or (code == "C07.04" and ext.lower() in CAD_EXTENSIONS):
            phase = name_codes.get("A") or (c.phase[0] if c.phase else "Ax")
            f_code = name_codes.get("F") or CAD_EXTENSIONS.get(ext.lower(), "F02")
            new_name = f"{project_id or 'PROJEKT-ID'}_{phase}_{f_code}_{k}_{stem}"
            kind = "model"
        elif code == "C07.01":
            h = name_codes.get("H") or (c.drawing_type[0] if c.drawing_type else (
                next((hc for hc, words in kb_drawing_hints() if any(w in stem.lower() for w in words)), "H0")))
            n = name_codes.get("N") or "N01"  # løbenummeret tælles op ved omdøbning
            new_name = f"{k}_{h}_{n}_{'' if is_generic(clean_name(stem, ids)) else stem}"
            kind = "drawing"
        else:
            new_name = f"{code}_{k}_{stem}"
            if name_codes.get("N"):
                new_name += f"_{name_codes['N']}"
        return FileSuggestion(path, stem, code, self.db.folder_name(code), probability,
                              self.finish_name(new_name, ids), ext, kind, reason)

    # ------------------------------------------------------------ omdøbning
    def target_for_name(self, filename: str, project_id: str = "") -> tuple[str | None, int, str]:
        """Hvilken mappe hører en fil med dette navn til? Returnerer (mappekode, sikkerhed, begrundelse)."""
        filename = filename.strip()
        if not filename:
            return None, 0, ""
        code = self.file_code(filename)
        if code:
            return code, 100, "Filnavnet starter med mappekoden."
        stem = Path(filename).stem
        if MODEL_NAME_RE.search(filename) and self.db.folder("C07.02"):
            return "C07.02", 95, "Navnet følger navngivningen for modeller (Projekt-ID_Fase_Filtype_Vidensområde_Navn)."
        if DRAWING_NAME_RE.match(stem) and self.db.folder("C07.01"):
            return "C07.01", 95, "Navnet følger navngivningen for tegninger (Vidensområde_Afbildningstype_Løbenummer)."
        s = self.suggest(Path(filename), None, project_id)
        return s.folder_code, s.probability, s.reason

    @staticmethod
    def _serial_taken(folder: Path, stem: str, own: Path) -> bool:
        """Bruger en anden fil i mappen allerede løbenummeret (fx K01_H1_N01_…)?"""
        m = SERIAL_RE.search(stem)
        if not m or not folder.exists():
            return False
        pattern = re.compile(re.escape(stem[:m.start()]) + r"_N(\d+)", re.IGNORECASE)
        number = int(m.group(1))
        for p in folder.iterdir():
            hit = pattern.match(p.stem)
            if hit and int(hit.group(1)) == number and p.resolve() != Path(own).resolve():
                return True
        return False

    def rename_file(self, root: Path, path: Path, new_name: str, target_code: str | None = None,
                    scan: ProjectScan | None = None) -> Path:
        """Omdøber en fil i projektet og flytter den til `target_code`, hvis den er angivet.
        Findes navnet allerede i målmappen, overskrives intet – der tilføjes (2), eller løbenummeret tælles op."""
        path = Path(path)
        stem, ext = split_name(safe_name(new_name), path.suffix)
        if not stem:
            raise ValueError("Filnavnet er tomt.")
        folder = self.resolve_folder(root, target_code, scan) if target_code else path.parent
        target = folder / f"{stem}{ext}"
        if target.resolve() == path.resolve():
            return path
        if folder.resolve() == path.parent.resolve() and target.name.lower() == path.name.lower():
            path.rename(target)  # kun store/små bogstaver ændret
            return target
        if target.exists() or self._serial_taken(folder, stem, path):
            target = self.next_free_path(folder, stem, ext)
        shutil.move(str(path), str(target))
        return target

    # ----------------------------------------------------------------- tjek
    def check(self, scan: ProjectScan) -> list[Issue]:
        issues: list[Issue] = []
        for pf in scan.outside:
            s = self.suggest(pf.path)
            issues.append(Issue(pf, "Ligger uden for A104-mapperne", s.folder_code))
        for code, files in scan.files.items():
            main_with_children = self.has_children(code)
            for pf in files:
                named_code = self.file_code(pf.name)
                if is_copy_name(pf.name):
                    issues.append(Issue(pf, "Mulig kopi – »(2)« / »kopi« i navnet. Brug »🧹 Find dubletter«.", code))
                    continue
                if main_with_children and named_code != code:
                    s = self.suggest(pf.path, code)
                    if s.folder_code == code:  # fx Opgavegrundlag, der hører til i D1 selv
                        continue
                    issues.append(Issue(pf, f"Ligger direkte i hovedmappen {code} – bør ligge i en undermappe"
                                        + (f" (forslag: {s.folder_code})" if s.folder_code else ""), s.folder_code))
                elif named_code and named_code != code:
                    issues.append(Issue(pf, f"Filnavnet angiver {named_code}, men filen ligger i {code}", named_code))
                elif not named_code and not MODEL_NAME_RE.search(pf.name) and not DRAWING_NAME_RE.match(pf.path.stem):
                    issues.append(Issue(pf, "Følger ikke A104-navngivningen (Mappe_Vidensområde_Navn)", code))
        return issues

    def naming_status(self, pf: ProjectFile) -> tuple[bool, str]:
        named_code = self.file_code(pf.name)
        if not pf.folder_code:
            return False, "Ligger uden for A104-mapperne."
        if is_copy_name(pf.name):
            return False, "Mulig kopi – »(2)« / »kopi« i navnet. Brug »Find dubletter«."
        if self.has_children(pf.folder_code) and named_code != pf.folder_code:
            return False, f"Ligger direkte i hovedmappen {pf.folder_code} – bør ligge i en undermappe."
        if named_code == pf.folder_code:
            return True, "Følger A104-navngivningen og ligger i den rigtige mappe."
        if named_code:
            return False, f"Filnavnet angiver {named_code}, men filen ligger i {pf.folder_code}."
        if MODEL_NAME_RE.search(pf.name):
            return True, "Følger A104-navngivningen for model-/CAD-filer."
        if DRAWING_NAME_RE.match(pf.path.stem):
            return True, "Følger A104-navngivningen for tegninger."
        return False, "Følger ikke A104-navngivningen (Mappe_Vidensområde_Navn)."

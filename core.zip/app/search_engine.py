"""Global søgning: RapidFuzz + nøgleord, forkortelser, sammensatte ord og begreber.

Søgningen er bygget til dansk byggefagsprog:

* Stopord fjernes, så "Hvor skal en kontrolplan ligge?" søger på "kontrolplan".
* Sammensatte ord håndteres begge veje: "brand" finder "Brandstrategirapport",
  og "brandstrategirapport" finder mapper med ordet "brand".
* Forkortelser udvides (KS → kvalitetssikring, kontrol; ABA → brandalarmanlæg).
* Begreber (brand, lyd, KS, udbud, ...) giver ekstra relevans til de mapper,
  fagdiscipliner og vidensområder, som begrebet peger på.
* Koder genkendes uanset nuller: "K1" = "K01", "Y70" = "Y070", "c4.4" = "C04.04".
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from rapidfuzz import fuzz, process

import knowledge_base as kb
from database import Database, code_key
from models import (CODE, DISCIPLINE, DOCUMENT, ENTITY_PRIORITY, EXAMPLE, FOLDER, KNOWLEDGE_AREA, EntityRef,
                    SearchHit)

TOKEN_RE = re.compile(r"[0-9a-zæøåéüö]+(?:[.\-&][0-9a-zæøåéüö]+)*")
CODE_QUERY_RE = re.compile(r"^[a-z]{1,2}\d{1,4}x?(?:\.[a-z]?\d{1,3})?$")
MIN_SCORE = 42.0

KIND_LABELS = {"document": "Dokument", "drawing": "Tegning", "model": "Model/CAD-fil"}


def normalize(text: str | None) -> str:
    return (text or "").lower().replace("_", " ")


def tokenize(text: str | None) -> list[str]:
    return TOKEN_RE.findall(normalize(text))


def word_forms(text: str | None) -> set[str]:
    """Ord inkl. delene af bindestregs-ord: 'ks-dokumentation' -> {ks-dokumentation, ks, dokumentation}."""
    words: set[str] = set()
    for tok in tokenize(text):
        words.add(tok)
        for part in re.split(r"[.\-&]", tok):
            if part:
                words.add(part)
    return words


@dataclass
class QueryInfo:
    raw: str
    tokens: list[str]
    terms: list[str]
    expansions: dict[str, list[str]]
    concepts: dict[str, float]
    code_keys: list[str]

    @property
    def cleaned(self) -> str:
        return " ".join(self.terms)

    @property
    def is_empty(self) -> bool:
        return not self.terms


@dataclass
class IndexEntry:
    ref: EntityRef
    title: str
    code: str
    subtitle: str
    folder_code: str | None
    fields: list[tuple[float, set[str]]]
    title_norm: str
    code_keys: set[str]
    boost: float = 1.0


@dataclass
class Concept:
    key: str
    label: str
    emoji: str
    terms: list[str]
    targets: dict[tuple[str, str], float] = field(default_factory=dict)
    folders: set[str] = field(default_factory=set)


class SearchEngine:
    def __init__(self, db: Database):
        self.db = db
        self.entries: list[IndexEntry] = []
        self.vocab: list[str] = []
        self.vocab_set: set[str] = set()
        self.concepts: list[Concept] = []
        self.rebuild()

    # ------------------------------------------------------------------ indeks
    def rebuild(self) -> None:
        db = self.db
        db.invalidate_cache()
        entries: list[IndexEntry] = []

        folder_docs: dict[str, list[str]] = {}
        for d in db.documents():
            if d["folder_code"]:
                folder_docs.setdefault(d["folder_code"], []).append(d["name"])

        for f in db.folders():
            path = " → ".join(name for _, name in db.folder_path(f["code"]))
            entries.append(self._entry(
                EntityRef(FOLDER, f["code"]), f["name"], f["code"], f"Mappe · {path}", f["code"],
                [(1.0, f["code"]), (1.0, f["name"]), (0.92, (f["keywords"] or "").replace(",", " ")),
                 (0.85, " ".join(folder_docs.get(f["code"], []))), (0.55, f["purpose"] or ""),
                 (0.5, db.folder_name(f["parent_code"]))],
                code_keys={code_key(f["code"])}, boost=1.05))

        for d in db.documents():
            folder = d["folder_code"]
            where = f"{folder} {db.folder_name(folder)}" if folder else "ikke placeret"
            entries.append(self._entry(
                EntityRef(DOCUMENT, str(d["id"])), d["name"], folder or "",
                f"{KIND_LABELS.get(d['doc_kind'], 'Dokument')} · {where}", folder,
                [(1.0, d["name"]), (0.85, d["keywords"] or ""), (0.5, d["explanation"] or ""),
                 (0.55, db.folder_name(folder))]))

        for e in db.examples():
            folder = e["folder_code"]
            entries.append(self._entry(
                EntityRef(EXAMPLE, str(e["id"])), e["name"], folder or "",
                f"Eksempel fra Excel · {e['generated_name'] or e['sheet']}", folder,
                [(0.95, e["name"]), (0.9, e["generated_name"] or ""), (0.5, db.folder_name(folder)),
                 (0.45, db.code_name(e["knowledge_area_code"]))], boost=0.92))

        for m in db.disciplines():
            entries.append(self._entry(
                EntityRef(DISCIPLINE, m["code"]), m["name"], m["code"], "Fagdisciplin (M)", None,
                [(1.0, m["code"]), (1.0, m["name"]), (0.85, m["keywords"] or ""), (0.6, m["description"] or "")],
                code_keys={code_key(m["code"])}, boost=0.93))

        for k in db.knowledge_areas():
            entries.append(self._entry(
                EntityRef(KNOWLEDGE_AREA, k["code"]), k["name"], k["code"], "Vidensområde (K)", None,
                [(1.0, k["code"]), (1.0, k["name"]), (0.9, k["keywords"] or "")],
                code_keys={code_key(k["code"])}, boost=0.93))

        for c in db.query("SELECT * FROM codes WHERE entity_type = 'code' ORDER BY sort_order"):
            keys = {code_key(c["code"])} if c["code"] else set()
            keys |= {code_key(a) for a in (c["aliases"] or "").split(",") if a.strip()}
            entries.append(self._entry(
                EntityRef(CODE, str(c["id"])), c["name"], c["code"] or "", f"{c['category']} ({c['family']})",
                c["folder_code"],
                [(1.0, c["code"] or ""), (1.0, c["name"]), (0.5, c["category"]), (0.6, c["description"] or "")],
                code_keys=keys, boost=0.88))

        vocab: set[str] = set()
        for entry in entries:
            for _, words in entry.fields:
                vocab |= words
        self.entries = entries
        self.vocab = sorted(vocab)
        self.vocab_set = vocab

        self.concepts = []
        for c in db.concepts():
            concept = Concept(c["key"], c["label"], c["emoji"] or "", [t.lower() for t in c["terms"]])
            for to_type, to_key, weight in c["targets"]:
                concept.targets[(to_type, to_key)] = weight
                if to_type == FOLDER:
                    concept.folders.add(to_key)
            self.concepts.append(concept)

    @staticmethod
    def _entry(ref, title, code, subtitle, folder_code, fields, code_keys=None, boost=1.0) -> IndexEntry:
        prepared = [(weight, word_forms(text)) for weight, text in fields if text]
        return IndexEntry(ref, title, code or "", subtitle, folder_code, prepared, normalize(title),
                          set(code_keys or ()), boost)

    # --------------------------------------------------------------- analyse
    def analyze(self, text: str) -> QueryInfo:
        tokens = tokenize(text)
        terms = [t for t in tokens if t not in kb.STOPWORDS and (len(t) > 1 or t.isdigit())]
        if not terms:
            terms = [t for t in tokens if len(t) > 1]
        expansions = {t: list(kb.ABBREVIATIONS.get(t, [])) for t in terms}
        code_keys = [code_key(t) for t in terms if CODE_QUERY_RE.match(t)]
        words = set()
        for t in terms:
            words |= word_forms(t)
        expanded = {e for values in expansions.values() for e in values}
        concepts: dict[str, float] = {}
        for concept in self.concepts:
            strength = self._concept_strength(words, concept.terms)
            if expanded:
                strength = max(strength, 0.9 * self._concept_strength(expanded, concept.terms))
            if strength > 0:
                concepts[concept.key] = strength
        return QueryInfo(text, tokens, terms, expansions, concepts, code_keys)

    @staticmethod
    def _concept_strength(words: set[str], terms: list[str]) -> float:
        best = 0.0
        for q in words:
            for t in terms:
                if q == t:
                    return 1.0
                if len(t) >= 3 and q.startswith(t):
                    s = 0.85
                elif len(t) >= 4 and t in q:
                    s = 0.8
                elif len(q) >= 4 and t.startswith(q) and len(q) >= 0.6 * len(t):
                    s = 0.8
                elif len(q) >= 5 and len(t) >= 5 and fuzz.ratio(q, t) >= 85:
                    s = 0.7
                else:
                    continue
                best = max(best, s)
        return best

    def concept(self, key: str) -> Concept | None:
        return next((c for c in self.concepts if c.key == key), None)

    # ------------------------------------------------------------------ søgning
    def _term_scores(self, term: str) -> dict[str, float]:
        """Scorer ét søgeord mod hele ordforrådet (beregnes én gang pr. søgning)."""
        scores: dict[str, float] = {}
        if term in self.vocab_set:
            scores[term] = 100.0
        lt = len(term)
        for w in self.vocab:
            if w == term:
                continue
            lw = len(w)
            if lt >= 2 and w.startswith(term):
                s = 86 + 12 * lt / lw
            elif lt >= 4 and term in w:
                s = 76 + 14 * lt / lw
            elif lw >= 5 and lt > lw and w in term:
                s = 50 + 25 * lw / lt
            else:
                continue
            if s > scores.get(w, 0):
                scores[w] = s
        if lt >= 4:
            for w, s, _ in process.extract(term, self.vocab, scorer=fuzz.ratio, score_cutoff=78, limit=None):
                s2 = s * 0.92
                if s2 > scores.get(w, 0):
                    scores[w] = s2
        return scores

    @staticmethod
    def _entry_term_score(entry: IndexEntry, scores: dict[str, float]) -> float:
        best = 0.0
        for weight, words in entry.fields:
            for w in words:
                s = scores.get(w)
                if s and s * weight > best:
                    best = s * weight
        return best

    def search(self, text: str, limit: int = 80, types: set[str] | None = None) -> list[SearchHit]:
        q = self.analyze(text)
        if q.is_empty:
            return []
        term_scores = {t: self._term_scores(t) for t in q.terms}
        exp_scores = {e: self._term_scores(e) for vals in q.expansions.values() for e in vals}
        cleaned = q.cleaned

        hits: list[SearchHit] = []
        for entry in self.entries:
            if types and entry.ref.entity_type not in types:
                continue
            per_term = []
            for t in q.terms:
                s = self._entry_term_score(entry, term_scores[t])
                for e in q.expansions.get(t, []):
                    s = max(s, 0.8 * self._entry_term_score(entry, exp_scores[e]))
                per_term.append(s)
            base = 0.6 * (sum(per_term) / len(per_term)) + 0.4 * max(per_term)

            title_sim = fuzz.token_set_ratio(cleaned, entry.title_norm)
            if len(cleaned) >= 4 and len(entry.title_norm) >= len(cleaned):
                title_sim = max(title_sim, fuzz.partial_ratio(cleaned, entry.title_norm))
            if base < 1 and title_sim < 80:
                score = 0.0
            else:
                score = 0.75 * base + 0.25 * title_sim

            if q.code_keys and entry.code_keys:
                if entry.code_keys & set(q.code_keys):
                    score = max(score, 100.0) + 15
                elif any(k.startswith(qk + ".") for k in entry.code_keys for qk in q.code_keys):
                    score = max(score, 82.0)

            bonus, direct = 0.0, False
            for key, strength in q.concepts.items():
                concept = self.concept(key)
                if not concept:
                    continue
                weight = concept.targets.get((entry.ref.entity_type, entry.ref.key))
                if weight:
                    bonus = max(bonus, 22 * strength * weight)
                    direct = True
                elif entry.folder_code and entry.folder_code in concept.folders:
                    bonus = max(bonus, 10 * strength)
            if score > 0:
                final = min(100.0, score * entry.boost + bonus)
            elif direct:
                # Kun begrebsmatch (fx "branddør" -> brand -> C04.04 Myndighedskrav)
                final = 35.0 + bonus
            else:
                final = 0.0
            if final >= MIN_SCORE:
                hits.append(SearchHit(entry.ref, entry.title, entry.code, entry.subtitle, round(final, 1),
                                      entry.folder_code))

        hits.sort(key=lambda h: (-h.score, ENTITY_PRIORITY.get(h.entity_type, 9), h.code, h.title))
        return hits[:limit]

    def lookup_code(self, text: str) -> list[SearchHit]:
        """Rent kodeopslag (K01, M06, C04, D2.A5 ...)."""
        key = code_key(text.strip())
        if not key:
            return []
        exact, children = [], []
        for entry in self.entries:
            if key in entry.code_keys:
                exact.append(SearchHit(entry.ref, entry.title, entry.code, entry.subtitle, 100.0, entry.folder_code))
            elif any(k.startswith(key + ".") for k in entry.code_keys):
                children.append(SearchHit(entry.ref, entry.title, entry.code, entry.subtitle, 85.0,
                                          entry.folder_code))
        exact.sort(key=lambda h: ENTITY_PRIORITY.get(h.entity_type, 9))
        return exact + children

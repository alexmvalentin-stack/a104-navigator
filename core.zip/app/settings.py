"""Stier, konstanter, logning og brugerindstillinger."""
from __future__ import annotations

import json
import logging
import os
import re
import sys
from dataclasses import asdict, dataclass, field, fields
from logging.handlers import RotatingFileHandler
from pathlib import Path

APP_NAME = "A104 Navigator"
APP_ID = "A104Navigator"
APP_VERSION = "2.21.1"
APP_ORGANIZATION = "A104 Navigator"
APP_AUTHOR = "Alexander Valentin"
APP_EMAIL = "Alva1000@stud.ek.dk"  # vises i »Om programmet«, exe-egenskaber og installationsfilen
APP_YEAR = "2026"
APP_COPYRIGHT = f"© {APP_YEAR} {APP_AUTHOR}" + (f" ({APP_EMAIL})" if APP_EMAIL else "")
APP_COPYRIGHT_NOTICE = (
    f"© {APP_YEAR} {APP_AUTHOR}. Alle rettigheder forbeholdes.\n\n"
    f"{APP_NAME} er udviklet af {APP_AUTHOR} og er beskyttet af ophavsret. Kopiering, ændring og distribution "
    "kræver skriftlig tilladelse, medmindre andet følger af gældende lovgivning eller programmets licensvilkår.\n\n"
    f"Kontakt: {APP_EMAIL}"
)
# Datamappen beholder sit oprindelige navn, så eksisterende projekter og indstillinger bevares
DATA_DIR_NAME = "MolioNavigator"


def _is_writable(path: Path) -> bool:
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / ".write_test"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        return True
    except OSError:
        return False


def _resource_root() -> Path:
    """Mappen med medfølgende filer (assets). I en PyInstaller-build er det _MEIPASS."""
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).resolve().parent))
    return Path(__file__).resolve().parent.parent


def _data_root() -> Path:
    """Mappen hvor database, indstillinger og logfiler skrives.

    Den installerede .exe bruger altid %LOCALAPPDATA%\\MolioNavigator, så data (projekter, favoritter,
    indstillinger) bevares, når programmet opdateres eller pakkes ud et nyt sted.
    Kørt fra kildekoden bruges projektmappen.
    """
    if getattr(sys, "frozen", False):
        return Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / DATA_DIR_NAME
    return Path(__file__).resolve().parent.parent


LEGACY_FILES = ("molio_navigator.db", "molio_navigator.db-wal", "molio_navigator.db-shm", "settings.json",
                "knowledge_custom.json")


def migrate_legacy_data() -> bool:
    """Ældre versioner gemte data i »database« ved siden af exe-filen. Flyt dem én gang til %LOCALAPPDATA%."""
    if not getattr(sys, "frozen", False):
        return False
    legacy = Path(sys.executable).resolve().parent / "database"
    if not (legacy / "molio_navigator.db").exists() or DATABASE_PATH.exists():
        return False
    import shutil
    DATABASE_DIR.mkdir(parents=True, exist_ok=True)
    for name in LEGACY_FILES:
        if (legacy / name).exists():
            shutil.copy2(legacy / name, DATABASE_DIR / name)
    return True


RESOURCE_DIR = _resource_root()
ASSETS_DIR = RESOURCE_DIR / "assets"
DATA_ROOT = _data_root()
DATABASE_DIR = DATA_ROOT / "database"
LOG_DIR = DATA_ROOT / "logs"
DATABASE_PATH = DATABASE_DIR / "molio_navigator.db"
SETTINGS_PATH = DATABASE_DIR / "settings.json"
CUSTOM_KNOWLEDGE_PATH = DATABASE_DIR / "knowledge_custom.json"
LOG_PATH = LOG_DIR / "molio_navigator.log"


DEFAULT_EXCEL_NAME = "A104_Molio_Informationshaandtering_Samlet.xlsx"  # Molios standard – bruges fra start


def bundled_excel_files() -> list[Path]:
    """Excel-filer lagt i assets-mappen. Molios samlede standard står først."""
    if not ASSETS_DIR.exists():
        return []
    files = [p for p in ASSETS_DIR.glob("*.xls*") if not p.name.startswith("~$")]
    return sorted(files, key=lambda p: (p.name != DEFAULT_EXCEL_NAME, p.name.lower()))


def default_excel() -> Path | None:
    """Molios samlede standard: den der følger med programmet – ellers programmets egen kopi i datamappen
    (gemt ved første start, så den ikke forsvinder ved opdatering, flytning eller en ufuldstændig installation)."""
    p = ASSETS_DIR / DEFAULT_EXCEL_NAME
    backup = DATA_ROOT / "database" / "standard" / DEFAULT_EXCEL_NAME
    if p.exists():
        try:
            if not backup.exists() or backup.stat().st_size != p.stat().st_size:
                backup.parent.mkdir(parents=True, exist_ok=True)
                import shutil
                shutil.copy2(p, backup)
        except OSError:
            pass
        return p
    return backup if backup.exists() else None


def is_old_example(path: str | Path | None) -> bool:
    """Et af de eksempelark, ældre versioner brugte som standard (fx »…_2H_…_Eksempel_V5.xlsx«)."""
    name = Path(path).name if path else ""
    return bool(re.search(r"Eksempel_V\d+", name)) or (bool(path) and Path(path).parent == ASSETS_DIR
                                                          and name != DEFAULT_EXCEL_NAME)


def resolve_excel_path(path: str | Path | None) -> str:
    """Den fil, programmet skal indlæse. Findes den gemte sti ikke længere (fx efter geninstallation et andet sted),
    bruges den medfølgende fil med samme navn – ellers Molios standard, hvis den følger med."""
    if path and Path(path).exists():
        return str(path)
    if path:
        same = ASSETS_DIR / Path(path).name
        if same.exists():
            return str(same)
    default = default_excel()
    return str(default) if default else ""


EXPORT_NAME_RE = re.compile(r"struktur \d{4}-\d{2}-\d{2}|^Filer af ", re.IGNORECASE)


def find_a104_files(limit_dirs: int = 4000) -> list[Path]:
    """Søger efter A104-Excel-ark på computeren (Overførsler, Skrivebord, Dokumenter og OneDrive), bedste først:
    Molios samlede standard, så andre A104-ark, nyeste først. Søgningen er begrænset, så den går hurtigt."""
    home = Path.home()
    roots = [home / "Downloads", home / "Desktop", home / "Documents"]
    for var in ("OneDrive", "OneDriveCommercial", "OneDriveConsumer"):
        if os.environ.get(var):
            base = Path(os.environ[var])
            roots += [base, base / "Desktop", base / "Skrivebord", base / "Documents", base / "Dokumenter"]
    roots += [home / "Skrivebord", home / "Dokumenter", home / "Overførsler"]
    found: dict[str, Path] = {}
    visited = 0
    for root in dict.fromkeys(r for r in roots if r.exists()):
        for dirpath, dirnames, filenames in os.walk(root):
            visited += 1
            depth = len(Path(dirpath).relative_to(root).parts)
            dirnames[:] = [] if depth >= 3 else [d for d in dirnames if not d.startswith((".", "$", "node_modules"))]
            for fn in filenames:
                low = fn.lower()
                if "a104" in low and low.endswith((".xlsx", ".xlsm")) and not fn.startswith("~$") \
                        and not EXPORT_NAME_RE.search(fn):  # programmets egne eksporter er ikke datagrundlag
                    found.setdefault(low, Path(dirpath) / fn)
            if visited > limit_dirs:
                break

    def rank(p: Path):
        try:
            mtime = p.stat().st_mtime
        except OSError:
            mtime = 0
        return ("samlet" not in p.name.lower(), -mtime)

    return sorted(found.values(), key=rank)


def excel_label(path: str | Path) -> str:
    """Et læsbart navn til valglisten i Indstillinger."""
    name = Path(path).name
    if name == DEFAULT_EXCEL_NAME:
        return "Molio A104 – samlet standard (værdilister + A104c-mappestrukturer)"
    m = re.search(r"_(\dH)_.*Eksempel_(V\d+)", name)
    if m:
        return f"Eksempel {m.group(1)} ({m.group(2)}) – mindre omfattende"
    return name


def setup_logging() -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    root = logging.getLogger()
    if root.handlers:
        return
    root.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(name)s: %(message)s")
    file_handler = RotatingFileHandler(LOG_PATH, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
    file_handler.setFormatter(fmt)
    root.addHandler(file_handler)
    if not getattr(sys, "frozen", False):
        console = logging.StreamHandler()
        console.setFormatter(fmt)
        root.addHandler(console)


@dataclass
class UserSettings:
    """Brugerens indstillinger – gemmes som JSON i database-mappen."""

    excel_path: str = ""
    theme: str = "system"  # system | light | dark
    project_id: str = ""
    company: str = ""
    include_project_id: bool = False
    window_geometry: str = ""
    last_page: int = 0
    current_project: int = 0
    initials: str = ""  # senest søgte initialer i »Søg på initialer«
    share_initials: bool = True  # del rettede initialer med holdet via projektmappen (.a104navigator)
    auto_dedupe: bool = True  # ryd dubletter ved ⟳ Opdatér: behold nyeste, ældre versioner med samme navn erstattes
    ask_comment: bool = True  # spørg om en kommentar til Log, når nye/opdaterede filer kommer ind i projektet
    header_states: dict = field(default_factory=dict)  # kolonnebredder/-rækkefølge pr. liste (base64)
    default_source_offered: bool = False  # er der spurgt om at skifte til Molios samlede standard?
    molio_standard_checked: bool = False  # v2.11: gamle eksempelark/manglende ark er skiftet til Molios standard
    last_seen_version: str = ""   # »Nyt i denne version« er vist for denne version
    update_folder: str = ""       # holdets opdateringsmappe (tom = find selv i Teams/SharePoint)
    update_check: bool = True     # tjek for ny version ved opstart
    update_skip_version: str = ""  # »Spring over« for denne version

    @classmethod
    def load(cls) -> "UserSettings":
        try:
            data = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return cls()
        known = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in data.items() if k in known})

    def save(self) -> None:
        try:
            SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
            SETTINGS_PATH.write_text(json.dumps(asdict(self), indent=2, ensure_ascii=False), encoding="utf-8")
        except OSError:
            logging.getLogger(__name__).exception("Kunne ikke gemme indstillinger")

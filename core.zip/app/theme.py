"""Tema i web-udgaven: farverne er CSS-variabler, så HTML fra detail_renderer følger lys/mørk tilstand i browseren.

Erstatter app/theme.py (som bruger Qt) – kun current_palette() bruges af de moduler, web-appen kører.
"""
from __future__ import annotations

_KEYS = ("window", "surface", "surface_alt", "border", "text", "muted", "accent", "accent_hover", "accent_text",
         "accent_soft", "accent_bright", "link", "chip", "success", "warning", "warn_soft")
_PALETTE = {"name": "web", **{k: f"var(--{k.replace('_', '-')})" for k in _KEYS}}


def current_palette() -> dict:
    return _PALETTE

"""Tegningshovedet (nederst til højre på en tegning): titel, tegningsnummer, målestok, fase, fag og revision.

1. PDF med tekstlag (Revit, AutoCAD, ArchiCAD …): teksten læses med sin placering, og kun det, der står i
   hjørnet nederst til højre, bruges – også når siden er roteret.
2. Ingen tekst dér (scannet tegning, eller tekst gemt som streger): hjørnet læses med Windows' tekstgenkendelse.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path

import knowledge_base as kb

log = logging.getLogger(__name__)

# hjørnet nederst til højre (andel af siden, set som den vises)
REGION_X, REGION_Y = 0.5, 0.55

LABEL_TITLE = re.compile(r"^(?:tegnings?titel|titel|tegningens?\s+indhold|indhold|emne|drawing\s+title|title|"
                         r"tegning(?!\s*s?\.?\s*nr))\s*[:.]?\s*(.*)$", re.IGNORECASE)
LABEL_NUMBER = re.compile(r"(?:tegn(?:ing)?s?\.?\s*nr\.?|tegning\s+nr\.?|tegningsnummer|dwg\.?\s*no\.?|drawing\s+no\.?|"
                          r"sheet\s+no\.?|blad\s*nr\.?)\s*[:.]?\s*([A-ZÆØÅ0-9][\w.\-/]{1,24})", re.IGNORECASE)
A104_NUMBER = re.compile(r"(?<![A-Za-z0-9])(K\d{2})[_ .-]?(H\d)[_ .-]?(N\d{2,3})", re.IGNORECASE)
OTHER_NUMBER = re.compile(r"(?<![A-Za-z0-9])([A-Z]{1,3}[-_.]?\d{2,4}(?:[-_.]\d{1,3})?)(?![A-Za-z0-9])")
SCALE_RE = re.compile(r"\b1\s*:\s*(\d{1,4})\b")
REV_RE = re.compile(r"\brev(?:ision)?\.?\s*[:.]?\s*([A-Z0-9]{1,3})\b", re.IGNORECASE)
DATE_RE = re.compile(r"\b(\d{1,2})[-./](\d{1,2})[-./](\d{2,4})\b")
NOT_TITLE = re.compile(r"(?i)^(?:projekt|sag|sagsnr|bygherre|adresse|dato|rev|revision|tegnet|kontrol|godkendt|mål|"
                       r"målestok|fase|stadie|format|papir|side|blad|fag|firma|tlf|telefon|e-?mail|www|cvr)\b|"
                       r"\b(?:ApS|A/S|I/S|P/S)\b|@|https?:|^\W*$")
DISCIPLINES = [("K01", ["arkitekt"]), ("K09", ["ingeniør", "konstruktion", "statik", "bærende"]),
               ("K08", ["vvs", "ventilation", "varme", "afløb", "kloak", "sanitet"]),
               ("K07", ["el-installation", "elinstallation", "el-plan", "elplan", "belysning", "el "]),
               ("K02", ["landskab"]), ("K06", ["landinspektør", "opmåling", "terræn"])]


@dataclass
class TitleBlock:
    found: bool = False
    title: str = ""
    number: str = ""          # som det står i tegningshovedet, fx »A-201« eller »K01_H2_N01«
    a104: str = ""            # K01_H2_N01, hvis nummeret følger A104
    scale: str = ""           # »1:100«
    phase: str = ""           # A-kode, fx »A4«
    discipline: str = ""      # K-kode, fx »K01«
    drawing_type: str = ""    # H-kode, fx »H2«
    revision: str = ""
    via_ocr: bool = False
    lines: list[str] = field(default_factory=list)

    def summary(self) -> str:
        parts = [f"»{self.title}«" if self.title else "", f"tegn. nr. {self.number}" if self.number else "",
                 self.scale, f"rev. {self.revision}" if self.revision else ""]
        return " · ".join(p for p in parts if p)


# ------------------------------------------------------------------ læs hjørnet
def _region_lines_from_text(path: Path) -> list[str]:
    """Tekstlinjer i hjørnet nederst til højre af første side (ud fra PDF'ens tekstlag og placeringer)."""
    from pypdf import PdfReader
    logging.getLogger("pypdf").setLevel(logging.ERROR)
    reader = PdfReader(str(path), strict=False)
    if reader.is_encrypted:
        reader.decrypt("")
    if not reader.pages:
        return []
    page = reader.pages[0]
    box = page.mediabox
    x0, y0 = float(box.left), float(box.bottom)
    w, h = float(box.width), float(box.height)
    rot = (page.get("/Rotate") or 0) % 360
    pieces: list[tuple[tuple, float, str]] = []

    def to_display(x: float, y: float) -> tuple[float, float, float, float]:
        """Punkt i PDF-koordinater -> som siden vises (øverst til venstre = 0,0), plus visningens bredde/højde."""
        if rot == 90:
            return y, x, h, w
        if rot == 180:
            return w - x, y, w, h
        if rot == 270:
            return h - y, w - x, h, w
        return x, h - y, w, h

    def visit(text, cm, tm, _font, _size):
        if not text or not text.strip():
            return
        x = tm[4] * cm[0] + tm[5] * cm[2] + cm[4] - x0
        y = tm[4] * cm[1] + tm[5] * cm[3] + cm[5] - y0
        dx, dy, W, H = to_display(x, y)
        if dx < REGION_X * W or dy < REGION_Y * H:
            return
        # skriveretning som vist: vandret tekst samles i rækker, lodret tekst i kolonner
        ux, uy = tm[0] * cm[0] + tm[1] * cm[2], tm[0] * cm[1] + tm[1] * cm[3]
        ex, ey, _W, _H = to_display(x + ux, y + uy)
        if abs(ex - dx) >= abs(ey - dy):
            pieces.append((("h", round(dy / 3)), dx, text.strip()))
        else:
            pieces.append((("v", round(dx / 3)), dy, text.strip()))

    page.extract_text(visitor_text=visit)
    rows: dict[tuple, list[tuple[float, str]]] = {}
    for key, pos, text in pieces:
        rows.setdefault(key, []).append((pos, text))
    lines = [" ".join(t for _p, t in sorted(parts)) for _k, parts in sorted(rows.items())]
    return [re.sub(r"\s+", " ", ln).strip() for ln in lines if ln.strip()]


def _region_lines_from_ocr(path: Path) -> list[str]:
    import ocr
    text = ocr.read_region(path, REGION_X, REGION_Y)
    return [ln.strip() for ln in text.splitlines() if ln.strip()]


# ------------------------------------------------------------------ tolkning
def parse(lines: list[str]) -> TitleBlock:
    tb = TitleBlock(found=bool(lines), lines=lines)
    text = "\n".join(lines)
    low = text.lower()
    m = A104_NUMBER.search(text)
    if m:
        tb.a104 = "_".join(g.upper() for g in m.groups())
        tb.number = tb.a104
    else:
        m = LABEL_NUMBER.search(text)
        if m:
            tb.number = m.group(1).strip(".-")
        else:
            m = OTHER_NUMBER.search(text)
            tb.number = m.group(1) if m else ""
    m = SCALE_RE.search(text)
    tb.scale = f"1:{m.group(1)}" if m else ""
    m = REV_RE.search(text)
    tb.revision = m.group(1).upper() if m and not m.group(1).lower().startswith("dato") else ""
    for hint, code in sorted(kb.PHASE_HINTS.items(), key=lambda kv: -len(kv[0])):
        if len(hint) >= 8 and hint in low:
            tb.phase = code
            break
    for code, words in DISCIPLINES:
        if any(w in low + " " for w in words):
            tb.discipline = code
            break
    # titlen: værdien efter »Titel:« / »Tegning:« – ellers linjen med en afbildningstype (plan, snit, facade …)
    title = ""
    for i, ln in enumerate(lines):
        m = LABEL_TITLE.match(ln)
        if m:
            title = m.group(1).strip() or (lines[i + 1] if i + 1 < len(lines) else "")
            break
    if not title:
        type_words = [w for _h, words in kb.DRAWING_TYPE_HINTS for w in words if len(w) >= 4]
        candidates = [ln for ln in lines if any(w in ln.lower() for w in type_words) and not NOT_TITLE.search(ln)
                      and not LABEL_NUMBER.search(ln) and not SCALE_RE.fullmatch(ln.strip())]
        if candidates:
            title = max(candidates, key=len)
    title = SCALE_RE.sub("", title)
    title = re.sub(r"\s{2,}", " ", title).strip(" -–:·|")
    if tb.number:
        title = title.replace(tb.number, "").strip(" -–:·|")
    tb.title = title[:80]
    for code, words in kb.DRAWING_TYPE_HINTS:
        if any(re.search(rf"(?<![a-zæøå]){re.escape(w)}", tb.title.lower()) for w in words):
            tb.drawing_type = code
            break
    if tb.a104:
        tb.discipline, tb.drawing_type = tb.a104[:3], tb.a104[4:6]
    tb.found = bool(tb.title or tb.number or tb.scale)
    return tb


_cache: dict[str, tuple[float, int, TitleBlock]] = {}


def read(path: Path, allow_ocr: bool = True) -> TitleBlock:
    """Tegningshovedet på første side af en PDF-tegning. Henter aldrig filer ned fra skyen."""
    path = Path(path)
    if path.suffix.lower() != ".pdf":
        return TitleBlock()
    try:
        st = path.stat()
    except OSError:
        return TitleBlock()
    hit = _cache.get(str(path))
    if hit and hit[0] == st.st_mtime and hit[1] == st.st_size:
        return hit[2]
    import file_search
    if file_search.is_cloud_only(path):
        return TitleBlock()
    tb = TitleBlock()
    try:
        lines = _region_lines_from_text(path)
        tb = parse(lines)
        if not tb.found and allow_ocr:
            lines = _region_lines_from_ocr(path)
            tb = parse(lines)
            tb.via_ocr = tb.found
    except Exception as exc:  # en defekt tegning må ikke stoppe placeringen
        log.debug("Kunne ikke læse tegningshoved i %s: %s", path, exc)
    _cache[str(path)] = (st.st_mtime, st.st_size, tb)
    return tb

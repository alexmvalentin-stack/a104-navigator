"""Broen mellem web-appens brugerflade (JavaScript) og A104 Navigators Python-kerne (kører i Pyodide).

Hver funktion tager og returnerer JSON-venlige værdier. worker.js kalder `call(navn, args_json)`.
Kernen er den samme kode som i Windows-programmet: database, search_engine, document_classifier,
detail_renderer, br18, laws og learn_content. HTML'en fra Qt-siderne (BR18, AB 18, Lær A104) er gengivet her
uden Qt.
"""
from __future__ import annotations

import json
import os
import re
from html import escape as e

os.environ.setdefault("RAPIDFUZZ_IMPLEMENTATION", "python")  # rapidfuzz uden C-udvidelser (findes ikke i Pyodide)

from datetime import datetime  # noqa: E402
from pathlib import PurePosixPath  # noqa: E402

import br18  # noqa: E402
import knowledge_base as kb  # noqa: E402
import laws  # noqa: E402
import learn_content as lc  # noqa: E402
import project_manager as pmod  # noqa: E402
from database import Database, code_key  # noqa: E402
from detail_renderer import DetailRenderer  # noqa: E402
from document_classifier import DocumentClassifier  # noqa: E402
from models import ENTITY_ICONS, ENTITY_LABELS, FOLDER, SCHEME_TO_ENTITY, EntityRef  # noqa: E402
from search_engine import SearchEngine  # noqa: E402
from settings import APP_COPYRIGHT, APP_VERSION, DATABASE_PATH  # noqa: E402

BR18_LINK_RE = re.compile(r"(§§?\s*)(\d{1,3})")
LAW_LINK_RE = re.compile(r"(§§?\s*)(\d{1,3}[a-z]?)(?![\d])")


class WebRenderer(DetailRenderer):
    """Samme HTML som i programmet, men uden <html>/<style> – browserens CSS står for udseendet."""

    def _page(self, body: str) -> str:
        return body


class State:
    db: Database | None = None
    engine: SearchEngine | None = None
    classifier: DocumentClassifier | None = None
    renderer: WebRenderer | None = None
    projects: pmod.ProjectManager | None = None


S = State()


# ---------------------------------------------------------------------------- start
def init(favorites: list | None = None) -> dict:
    S.db = Database(DATABASE_PATH)
    S.db.conn.execute("PRAGMA journal_mode=MEMORY")
    S.db.conn.execute("DELETE FROM favorites")
    for f in favorites or []:
        S.db.conn.execute("INSERT OR IGNORE INTO favorites(item_type, item_key, label, created_at) VALUES(?,?,?,?)",
                          (f.get("item_type"), f.get("item_key"), f.get("label", ""), f.get("created_at", "")))
    S.engine = SearchEngine(S.db)
    S.classifier = DocumentClassifier(S.db, S.engine)
    S.renderer = WebRenderer(S.db)
    S.projects = pmod.ProjectManager(S.db, S.classifier)
    folder_codes = S.projects.folder_codes()
    S.projects.folder_codes = lambda: folder_codes  # slås op for hver fil – mapperne ændrer sig ikke her
    return {"version": APP_VERSION, "copyright": APP_COPYRIGHT, "imported": S.db.get_meta("imported_at"),
            "excel": os.path.basename(S.db.get_meta("excel_path") or "")}


def warm_up() -> bool:
    """Indlæs BR18 og aftalevilkårene i baggrunden, så den første søgning går hurtigt."""
    br18.library().load()
    for code, _n, _d in laws.LAWS:
        laws.library(code).load()
    return True


# ------------------------------------------------------------------------ hjælpere
def _ref_json(ref: EntityRef) -> dict:
    return {"type": ref.entity_type, "key": ref.key}


def _ref_for_code_row(row) -> EntityRef:
    return DetailRenderer._ref_for_code_row(row)


def _row(row, *cols) -> dict:
    return {c: row[c] for c in cols}


# ----------------------------------------------------------------------- dashboard
def dashboard() -> dict:
    db = S.db
    families = [{"family": f["family"], "name": f["name"], "n": f["n"], "description": f["description"] or ""}
                for f in db.code_families() if f["n"]]
    return {"stats": db.stats(), "families": families,
            "quick": [{"emoji": em, "label": label, "query": q} for em, label, q in kb.QUICK_CARDS]}


# ------------------------------------------------------------------------- søgning
def search(query: str, project_id: str = "", include_project_id: bool = False) -> dict:
    query = (query or "").strip()
    if not query:
        return {"query": "", "hits": [], "banner": None}
    hits = S.engine.search(query)
    banner = None
    if not S.engine.analyze(query).code_keys:
        c = S.classifier.classify(query, project_id, include_project_id)
        if c.best and c.probability >= 45:
            banner = {"code": c.best.folder_code, "name": c.best.folder_name, "probability": c.probability,
                      "path": " → ".join(name for _, name in c.folder_path)}
    return {"query": query, "banner": banner,
            "hits": [{"ref": _ref_json(h.ref), "icon": ENTITY_ICONS.get(h.entity_type, "•"),
                      "label": ENTITY_LABELS.get(h.entity_type, ""), "title": h.title, "code": h.code,
                      "subtitle": h.subtitle, "score": round(h.score)} for h in hits]}


def search_counts(query: str) -> dict:
    """Antal fund i BR18 og aftalevilkårene – vises som knapper over søgeresultaterne."""
    krav, guides, annexes = br18.library().count_all(query)
    return {"br18": {"krav": krav, "guides": guides},
            "laws": [{"code": c, "name": n, "n": laws.library(c).count(query)} for c, n, _d in laws.LAWS]}


# ------------------------------------------------------------------------- detaljer
def detail(entity_type: str, key: str) -> dict:
    ref = EntityRef(entity_type, str(key))
    code, title = S.renderer.title_for(ref)
    return {"ref": _ref_json(ref), "html": S.renderer.render(ref), "code": code, "title": title,
            "fav": S.db.is_favorite(entity_type, str(key)), "folder": entity_type == FOLDER}


def resolve_link(href: str) -> dict | None:
    """'folder:C04.04' -> {type, key}. Ukendte skemaer giver None."""
    scheme, _, key = href.partition(":")
    if scheme in SCHEME_TO_ENTITY:
        return {"type": SCHEME_TO_ENTITY[scheme], "key": key}
    return None


# --------------------------------------------------------------------- dokumentfinder
def classify(text: str, project_id: str = "", include_project_id: bool = False) -> dict:
    c = S.classifier.classify(text.strip(), project_id, include_project_id)
    return {"best": {"code": c.best.folder_code, "name": c.best.folder_name} if c.best else None,
            "probability": c.probability, "filename": c.filename if c.best else "",
            "html": S.renderer.render_classification(c)}


# ---------------------------------------------------------------------- mappestruktur
def tree() -> list:
    counts = {r["folder_code"]: r["n"] for r in S.db.query(
        "SELECT folder_code, COUNT(*) AS n FROM documents WHERE folder_code IS NOT NULL GROUP BY folder_code")}
    return [{"code": f["code"], "name": f["name"], "parent": f["parent_code"], "purpose": f["purpose"] or "",
             "count": counts.get(f["code"], 0)} for f in S.db.folders()]


# ---------------------------------------------------------------------------- koder
def codes() -> dict:
    db = S.db
    families = [{"family": f["family"], "name": f["name"], "n": f["n"], "description": f["description"] or ""}
                for f in db.code_families() if f["n"]]
    rows = []
    for r in db.codes_by_family():
        ref = _ref_for_code_row(r)
        rows.append({"code": r["code"] or "", "name": r["name"], "category": r["category"], "family": r["family"],
                     "aliases": r["aliases"] or "", "description": r["description"] or "", "ref": _ref_json(ref),
                     "keys": [code_key(c) for c in [r["code"] or ""] + (r["aliases"] or "").split(",") if c]})
    return {"families": families, "rows": rows}


# ------------------------------------------------------------------------ favoritter
def _favorites_export() -> list:
    return [_row(r, "item_type", "item_key", "label", "created_at") for r in S.db.favorites()]


def favorites() -> list:
    out = []
    for r in S.db.favorites():
        key = S.db.resolve_stable_key(r["item_type"], r["item_key"])
        out.append({"id": r["id"], "type": r["item_type"], "key": key, "label": r["label"],
                    "icon": ENTITY_ICONS.get(r["item_type"], "⭐"), "kind": ENTITY_LABELS.get(r["item_type"], ""),
                    "missing": key is None})
    return out


def toggle_favorite(entity_type: str, key: str) -> dict:
    key = str(key)
    if S.db.is_favorite(entity_type, key):
        S.db.remove_favorite(entity_type, key)
    else:
        code, title = S.renderer.title_for(EntityRef(entity_type, key))
        S.db.add_favorite(entity_type, key, f"{code} {title}".strip())
    return {"fav": S.db.is_favorite(entity_type, key), "export": _favorites_export()}


def remove_favorite(fav_id: int) -> list:
    S.db.remove_favorite_by_id(int(fav_id))
    return _favorites_export()


# --------------------------------------------------------------------------- Lær A104
def learn_chapters() -> list:
    return [{"key": k, "title": t} for k, t in lc.CHAPTERS]


def _lists_html() -> str:
    """Kapitlet »De 17 værdilister« (som i learn_page.LearnPage._lists_html)."""
    db, renderer = S.db, S.renderer
    families = {f["family"]: f for f in db.code_families()}
    rows = []
    for letter, purpose in lc.LIST_PURPOSE.items():
        fam = families.get(letter)
        name = fam["name"] if fam else ""
        examples = db.query("SELECT code FROM codes WHERE family = ? AND code IS NOT NULL "
                            "ORDER BY sort_order LIMIT 60", (letter,))
        codes_ = list(dict.fromkeys(r["code"] for r in examples))[:3]
        ex = ", ".join(renderer.code_link(c) for c in codes_)
        count = fam["n"] if fam else 0
        link = (f"<a href='family:{letter}'><b>{e(name)}</b></a> <span class='muted'>({count})</span>"
                if count else f"<b>{e(name)}</b>")
        rows.append(f"<tr><td class='big'>{letter}</td><td>{link}<br>{e(purpose)}"
                    f"{'<br><span class=muted>Fx </span>' + ex if ex else ''}</td>"
                    f"<td class='muted'>{e(lc.LIST_TYPES.get(letter, ''))}</td></tr>")
    extra = "".join(f"<tr><td class='mono'><b>{k}</b></td><td>{e(v)}</td></tr>" for k, v in lc.METADATA_SET.items())
    return (
        "<h1>De 17 værdilister</h1>"
        "<p>Hver liste har sit eget <b>bogstav</b>. Bogstavet står foran tallet i alle koder, så man altid kan se, "
        "hvilken slags oplysning en kode er. Klik på et listenavn for at se alle koderne.</p>"
        f"<table><tr><th>Kode</th><th>Liste og formål</th><th>Type</th></tr>{''.join(rows)}</table>"
        "<h2>Uden for listerne – metadatasættet</h2>"
        "<p>Disse oplysninger har ingen fast liste, fordi værdien er forskellig fra projekt til projekt:</p>"
        f"<table>{extra}</table>"
        "<p class='muted'>Listerne findes kun i den udgave, der er indlæst fra Excel-arket. Mangler en liste, "
        "har arket ikke koder til den.</p>")


def learn_chapter(key: str) -> str:
    return _lists_html() if key == "lister" else lc.TEXT.get(key, "")


def builder_data() -> dict:
    """Valgmulighederne i navnebyggeren (som learn_page.NameBuilder._codes)."""
    db = S.db
    out = {}
    for letter in ("A", "C", "K", "M", "F", "H", "E"):
        if letter == "C":
            rows = [r for r in db.folders() if (r["code"] or "").startswith("C")]
        elif letter == "K":
            rows = db.knowledge_areas()
        elif letter == "M":
            rows = db.disciplines()
        elif letter == "A":
            rows = db.phases()
        else:
            rows = db.query("SELECT code, name FROM codes WHERE family = ? AND code IS NOT NULL ORDER BY sort_order",
                            (letter,))
        seen, items = set(), []
        for r in rows:
            if r["code"] and r["code"] not in seen:
                seen.add(r["code"])
                items.append([r["code"], r["name"] or ""])
        out[letter] = items
    names = {}
    for letter in out:
        fam = db.code_family(letter)
        names[letter] = fam["name"] if fam else letter
    return {"codes": out, "families": names}


def quiz() -> list:
    return [{"q": q, "options": opts, "correct": correct, "why": why} for q, opts, correct, why in lc.QUIZ]


# ------------------------------------------------------------------------------ BR18
def _br18_terms(lib, query: str) -> list[str]:
    fixes = lib.corrections(query) if query.strip() else {}
    return [fixes.get(t, t) for t in lib.terms(query)]


def _highlight(text: str, terms: list[str], link_re: re.Pattern, scheme: str) -> str:
    html = e(text)
    html = link_re.sub(lambda m: f"<a href='{scheme}:{m.group(2)}'>{m.group(1)}{m.group(2)}</a>", html)
    words = [re.escape(e(t)) for t in terms if len(t) >= 2]
    if words:
        pattern = re.compile(rf"(?<![\w>])((?:{'|'.join(words)})\w*)(?![^<]*</a>)", re.IGNORECASE)
        html = pattern.sub(lambda m: f"<mark>{m.group(1)}</mark>", html)
    return html


def _br18_highlight(text: str, terms: list[str]) -> str:
    html = _highlight(text, terms, BR18_LINK_RE, "br18")
    html = re.sub(r"\s(Stk\.\s?\d{1,2}\.)\s", r"<br><br><b>\1</b> ", html)
    return re.sub(r"\s(\d{1,2}\))\s", r"<br>\1 ", html)


def _clean_snippet(s: str) -> str:
    return re.sub(r"\s+", " ", s.replace("\x02", "").replace("\x03", "")).strip()


def _kap_label(kap: str) -> str:
    return ("Bilag " + kap[1:]) if kap.startswith("B") else f"Kap. {kap.lstrip('0')}"


def br18_meta() -> dict:
    lib = br18.library()
    if not lib.load():
        return {"error": lib.error or "BR18-data mangler."}
    gaeldende = sum(1 for k in lib.krav if not k.repealed)
    counts = lib.doc_counts()
    return {
        "subtitle": (f"Fra bygningsreglementet.dk (Social- og Boligstyrelsen) · {lib.edition or 'BR18'} · "
                     f"{gaeldende} gældende krav (§/stk.) i {len(lib.chapters())} kapitler, {len(lib.tables)} tabeller "
                     f"og {counts.get('vejledning', 0)} vejledninger. Søg med ord, dele af ord eller paragrafnumre."),
        "chapters": [[kap, f"{kap.lstrip('0') or kap}. {titel}"] for kap, titel, _n in lib.chapters()],
        "domains": [[key, f"{label} ({n})"] for key, label, n in lib.domains()],
    }


def br18_search(query: str, kapitel: str | None = None, domaene: str | None = None,
                include_repealed: bool = False) -> dict:
    lib = br18.library()
    lib.load()
    query = (query or "").strip()
    kapitel, domaene = kapitel or None, domaene or None
    terms = _br18_terms(lib, query)
    out: dict = {"query": query}
    if not query:
        hits = lib.search("", kapitel, domaene, include_repealed, limit=0)
        groups: dict[str, dict] = {}
        seen: set[int] = set()
        for h in hits:
            k = h.krav
            if k.paragraf in seen:
                continue
            seen.add(k.paragraf)
            g = groups.setdefault(k.kapitel, {"label": f"{k.kapitel.lstrip('0') or k.kapitel}. {k.kapitel_titel}",
                                              "items": []})
            g["items"].append({"p": k.paragraf, "stk": 0, "ref": f"§ {k.paragraf}",
                               "text": k.afsnit_titel + (" (ophævet)" if k.repealed else ""), "repealed": k.repealed})
        out["groups"] = list(groups.values())
        out["info"] = f"{len(seen)} paragraffer – vælg et kapitel, et emne, eller skriv et søgeord."
    else:
        hits = lib.search(query, kapitel, domaene, include_repealed)
        out["items"] = [{"p": h.krav.paragraf, "stk": h.krav.stk,
                         "ref": f"§ {h.krav.paragraf}" + (f", stk. {h.krav.stk}" if h.krav.stk else ""),
                         "text": f"{h.krav.afsnit_titel} – {_clean_snippet(h.snippet)}", "repealed": h.krav.repealed}
                        for h in hits]
        fixes = lib.corrections(query)
        info = f"<b>{len(hits)}</b> krav fundet for »{e(query)}«"
        if fixes:
            info += " · søgte også på " + ", ".join(f"<i>{e(v)}</i> (i stedet for {e(k)})" for k, v in fixes.items())
        if not hits:
            info += ". Prøv færre eller kortere ord – fx »flugt« i stedet for »flugtvejsbredde«."
        out["info"] = info
    tables = lib.search_tables(query, kapitel) if terms else [t for t in lib.tables if not kapitel or t.kapitel == kapitel]
    out["tables"] = [{"id": t.id, "title": t.titel, "label": f"{_kap_label(t.kapitel)} · {len(t.rows)} rækker"}
                     for t in tables]
    guides = lib.search_docs(query, "vejledning", kapitel)
    if not query:
        guides.sort(key=lambda h: (br18._chapter_key(h.doc.kapitel or "99"), h.doc.titel))
    items = []
    for h in guides:
        d = h.doc
        snippet = _clean_snippet(h.snippet)
        label = d.titel if not snippet or snippet.startswith(d.tekst[:40].strip()) else f"{d.titel} – {snippet}"
        items.append({"id": d.id, "title": d.titel, "label": label, "kap": d.kapitel.lstrip("0") or "–"})
    out["guides"] = items
    return out


def br18_paragraph(number: int, stk: int = 0, query: str = "") -> dict | None:
    lib = br18.library()
    lib.load()
    number = int(number)
    rows = lib.paragraph(number)
    if not rows:
        return None
    terms = _br18_terms(lib, query or "")
    k0 = rows[0]
    status = " <span class='muted'>(ophævet)</span>" if all(k.repealed for k in rows) else ""
    body = [f"<p class='muted'>Kapitel {e(k0.kapitel.lstrip('0'))} · {e(k0.kapitel_titel)}</p>",
            f"<h1>§ {number}{status}</h1>",
            f"<p><b>{e(k0.afsnit_titel)}</b> · <span class='muted'>"
            f"{e(br18.DOMAIN_LABELS.get(k0.domaene, k0.domaene))}</span></p>"]
    for k in rows:
        label = f"Stk. {k.stk}." if k.stk else ""
        cls = " class='repealed'" if k.repealed else ""
        body.append(f"<p id='stk{k.stk}'{cls}><b>{label}</b> {_br18_highlight(k.tekst, terms) or '<i>Ophævet.</i>'}</p>")
    nav = []
    if lib.paragraph(number - 1):
        nav.append(f"<a href='br18:{number - 1}'>‹ § {number - 1}</a>")
    if lib.paragraph(number + 1):
        nav.append(f"<a href='br18:{number + 1}'>§ {number + 1} ›</a>")
    body.append("<p class='pager'>" + " &nbsp;·&nbsp; ".join(nav) + "</p>")
    tables = lib.chapter_tables(k0.kapitel)
    if tables:
        body.append("<h2>Tabeller i kapitlet</h2><ul>" + "".join(
            f"<li><a href='tab:{e(t.id)}'>{e(t.titel)}</a></li>" for t in tables) + "</ul>")
    body.append(f"<p class='muted'>Kilde: <a href='{e(k0.url)}' target='_blank' rel='noopener'>{e(k0.url)}</a><br>"
                "Gengivet fra bygningsreglementet.dk – kontrollér altid gældende udgave.</p>")
    ref = f"BR18 § {number}" + (f", stk. {stk}" if stk else "")
    text = f"BR18 § {number} – {k0.afsnit_titel}\n" + "\n".join(
        (f"Stk. {k.stk}. " if k.stk else "") + k.tekst for k in rows)
    return {"html": "".join(body), "ref": ref, "text": text, "url": k0.url, "stk": stk}


def br18_table(tid: str, query: str = "") -> dict | None:
    lib = br18.library()
    lib.load()
    t = lib.table(tid)
    if not t:
        return None
    terms = _br18_terms(lib, query or "")
    head = "".join(f"<th>{e(h)}</th>" for h in t.header)
    rows = "".join("<tr>" + "".join(f"<td>{_br18_highlight(c, terms)}</td>" for c in r) + "</tr>" for r in t.rows)
    where = ("Bilag " + t.kapitel[1:]) if t.kapitel.startswith("B") else f"Kapitel {t.kapitel.lstrip('0')}"
    html = (f"<p class='muted'>{e(where)} · {e(t.id)}</p><h1>{e(t.titel)}</h1>"
            f"<div class='table-wrap'><table class='grid'><tr>{head}</tr>{rows}</table></div>"
            "<p class='muted'>Tabellen er gengivet som tekst; sammenflettede celler er ikke udfoldet – "
            "kontrollér mod bygningsreglementet.dk.</p>")
    return {"html": html, "ref": f"BR18 {where}: {t.titel}", "text": t.text()}


def br18_guide(doc_id: str, query: str = "") -> dict | None:
    lib = br18.library()
    lib.load()
    d = lib.doc(doc_id)
    if d is None:
        return None
    terms = _br18_terms(lib, query or "")
    out, para = [], []

    def flush():
        if para:
            out.append("<p>" + _br18_highlight(" ".join(para), terms) + "</p>")
            para.clear()

    for line in d.tekst.splitlines():
        s = line.strip()
        if not s:
            flush()
            continue
        m = re.match(r"(#{1,6})\s*(.+)", s)
        if m:
            flush()
            level = 2 if len(m.group(1)) <= 2 else 3
            out.append(f"<h{level}>{_br18_highlight(m.group(2), terms)}</h{level}>")
        elif re.match(r"[-•*]\s+", s):
            flush()
            out.append(f"<p class='bullet'>• {_br18_highlight(s[2:], terms)}</p>")
        else:
            para.append(s)
    flush()
    meta = e(br18.GUIDE_TYPES.get(d.typ, d.typ)) + (f" · Kapitel {e(d.kapitel.lstrip('0'))}" if d.kapitel else "")
    source = (f"<p class='muted'>Kilde: <a href='{e(d.url)}' target='_blank' rel='noopener'>{e(d.url)}</a><br>"
              "Vejledende – ikke bindende. Kontrollér altid gældende udgave på bygningsreglementet.dk.</p>"
              if d.url else "")
    html = f"<p class='muted'>{meta}</p><h1>{e(d.titel)}</h1>{''.join(out)}{source}"
    return {"html": html, "ref": d.titel + (f" ({d.url})" if d.url else ""), "url": d.url, "text": d.tekst}


# ------------------------------------------------------------------- AB 18 · ABR 18 · ABT 18
def laws_list() -> list:
    return [{"code": c, "name": n, "description": d} for c, n, d in laws.LAWS]


def law_meta(code: str) -> dict:
    lib = laws.library(code)
    if not lib.load():
        return {"error": lib.error}
    return {
        "name": lib.name, "title": f"{lib.name} – {lib.description.split(' – ')[0]}",
        "subtitle": (f"{lib.title} · {len(lib.paras)} paragraffer i {len(lib.sections)} afsnit. "
                     f"{lib.description.split(' – ')[-1].capitalize()}. Søg med ord, dele af ord eller paragrafnumre."),
        "foot": (f"Kilde: {lib.source} ({lib.url}), version fra {lib.lastmod}. Aftalevilkårene gælder kun, når de "
                 "er vedtaget i aftalen – kontrollér altid gældende tekst."),
        "url": lib.url, "pdf": f"data/love/{lib.pdf.name}" if lib.pdf else "",
        "sections": [[letter, f"{letter}. {title}"] for letter, title in lib.sections],
    }


def law_search(code: str, query: str, section: str | None = None) -> dict:
    lib = laws.library(code)
    lib.load()
    query = (query or "").strip()
    section = section or None
    if not query:
        groups: dict[str, dict] = {}
        for p in lib.paras:
            if section and p.section != section:
                continue
            g = groups.setdefault(p.section, {"label": f"{p.section}. {p.section_title}", "items": []})
            g["items"].append({"key": p.key, "stk": 0, "ref": f"§ {p.key}", "text": p.heading})
        n = sum(len(g["items"]) for g in groups.values())
        return {"query": "", "groups": list(groups.values()),
                "info": f"{n} paragraffer – vælg en, eller skriv et søgeord."}
    hits = lib.search(query, section)
    items = [{"key": h.para.key, "stk": h.stk,
              "ref": f"§ {h.para.key}" + (f", stk. {h.stk}" if len(h.para.stk) > 1 else ""),
              "text": f"{h.para.heading} – {_clean_snippet(h.snippet)}"} for h in hits]
    fixes = lib.corrections(query)
    info = f"<b>{len(hits)}</b> stykker i <b>{len({h.para.key for h in hits})}</b> paragraffer for »{e(query)}«"
    if fixes:
        info += " · søgte også på " + ", ".join(f"<i>{e(v)}</i> (i stedet for {e(k)})" for k, v in fixes.items())
    if not hits:
        info += ". Prøv færre eller kortere ord."
    return {"query": query, "items": items, "info": info}


def law_paragraph(code: str, key: str, stk: int = 0, query: str = "") -> dict | None:
    lib = laws.library(code)
    lib.load()
    p = lib.para(key)
    if p is None:
        return None
    fixes = lib.corrections(query) if (query or "").strip() else {}
    terms = [fixes.get(t, t) for t in lib.terms(query or "")]
    body = [f"<p class='muted'>{e(lib.name)} · {e(p.section)}. {e(p.section_title)}</p>",
            f"<h1>§ {e(p.key)}</h1>", f"<p><b>{e(p.heading)}</b></p>"]
    for i, text in enumerate(p.stk, start=1):
        label = f"<b>Stk. {i}.</b> " if len(p.stk) > 1 else ""
        html = _highlight(text, terms, LAW_LINK_RE, "law").replace("\n", "<br>")
        body.append(f"<p id='stk{i}'>{label}{html}</p>")
    prev, nxt = lib.neighbours(p)
    nav = []
    if prev:
        nav.append(f"<a href='law:{prev.key}'>‹ § {prev.key} {e(prev.heading)}</a>")
    if nxt:
        nav.append(f"<a href='law:{nxt.key}'>§ {nxt.key} {e(nxt.heading)} ›</a>")
    body.append("<p class='pager'>" + " &nbsp;·&nbsp; ".join(nav) + "</p>")
    body.append(f"<p class='muted'>Side {p.page} i den officielle PDF · Kilde: {e(lib.source)}</p>")
    text = f"{lib.name} § {p.key} – {p.heading}\n" + "\n".join(
        (f"Stk. {i}. " if len(p.stk) > 1 else "") + t for i, t in enumerate(p.stk, start=1))
    return {"html": "".join(body), "ref": lib.reference(p, stk or None), "text": text, "page": p.page,
            "stk": stk, "key": p.key}


# --------------------------------------------------------------- projekter (SharePoint)
def _modified(text: str) -> datetime:
    try:
        return datetime.fromisoformat((text or "").replace("Z", "+00:00")).replace(tzinfo=None)
    except ValueError:
        return datetime(2000, 1, 1)


def project_scan(items: list) -> dict:
    """Knytter et SharePoint-projekts mapper og filer til A104 – som ProjectManager.scan() gør på disken.
    `items` = [[id, sti, er_mappe, størrelse, ændret], …], stien relativ til projektmappen med »/«.
    Returnerer A104-koden for hver mappe og navngivningsstatus for hver fil."""
    pm = S.projects
    codes = {c.upper(): c for c in pm.folder_codes()}
    folder_code: dict[str, str | None] = {"": None}
    folders = {}
    for _id, path, is_folder, _size, _mod in sorted((i for i in items if i[2]), key=lambda i: i[1].count("/")):
        parent, _, name = path.rpartition("/")
        if pmod.is_ignored(name):
            continue
        own = folder_code.get(parent)
        m = pmod.DIR_CODE_RE.match(name)
        if m and m.group(1).upper() in codes:
            own = codes[m.group(1).upper()]
        folder_code[path] = own
        folders[path] = {"code": own, "a104": pm.db.folder_name(own) if own else "",
                         "own": bool(m and m.group(1).upper() in codes)}
    files = {}
    ok = outside = 0
    for fid, path, is_folder, size, mod in items:
        if is_folder:
            continue
        parent, _, name = path.rpartition("/")
        if pmod.is_ignored(name) or parent not in folder_code:
            continue
        pf = pmod.ProjectFile(PurePosixPath("/sharepoint") / path, folder_code[parent], int(size or 0), _modified(mod))
        good, message = pm.naming_status(pf)
        ok += good
        outside += pf.folder_code is None
        files[fid] = [good, message, pf.folder_code]
    used = {f["code"] for f in folders.values() if f["own"]}
    return {"folders": folders, "files": files,
            "summary": {"files": len(files), "ok": ok, "issues": len(files) - ok, "outside": outside,
                        "folders": len(folders), "a104": len(used)}}


def project_file(name: str, folder_code: str | None, project_id: str = "") -> dict:
    """Forslag til mappe og A104-filnavn for en fil i et SharePoint-projekt (ud fra navnet – filen hentes ikke)."""
    pm = S.projects
    path = PurePosixPath("/sharepoint") / name
    good, message = pm.naming_status(pmod.ProjectFile(path, folder_code or None, 0, datetime.now()))
    try:
        s = pm.code_suggestion(path, folder_code or None, project_id)
    except Exception as exc:  # et forslag er en hjælp – det må aldrig vælte visningen
        return {"ok": good, "message": message, "error": str(exc)}
    out = {"ok": good, "message": message, "code": s.folder_code, "folder": s.folder_name,
           "probability": s.probability, "name": s.filename if s.folder_code else "", "reason": s.reason}
    if s.folder_code:
        out["path"] = " → ".join(f"{c} {n}" for c, n in pm.db.folder_path(s.folder_code))
    return out


def check_files(names: list, project_id: str = "") -> list:
    """Filer valgt på telefonen (fx fra OneDrive i filvælgeren): følger navnet A104, og hvor hører filen til?
    Vi kender ikke mappen, filen ligger i – koden i navnet bruges som mappe."""
    pm = S.projects
    out = []
    for name in names:
        named = pm.file_code(name)
        stem = PurePosixPath(name).stem
        if named:
            good, message = pm.naming_status(pmod.ProjectFile(PurePosixPath("/telefon") / name, named, 0, datetime.now()))
            if good:
                message = f"Følger A104-navngivningen – hører til i {named} {pm.db.folder_name(named)}."
        elif pmod.MODEL_NAME_RE.search(name):
            good, message = True, "Følger A104-navngivningen for model-/CAD-filer."
        elif pmod.DRAWING_NAME_RE.match(stem):
            good, message = True, "Følger A104-navngivningen for tegninger."
        else:
            good, message = False, "Filnavnet starter ikke med en A104-kode (Mappe_Vidensområde_Navn)."
        s = project_file(name, named, project_id)
        if named and pm.has_children(named):
            good = False
            message = f"{named} er en hovedmappe – filen bør have koden for en undermappe" + (
                f", fx {s['code']} {s['folder']}." if s.get("code") else ".")
        reason = (s.get("reason") or "").replace("Koden svarer til mappen, filen ligger i.", "Koden står i filnavnet.").replace(
            "Filen ligger ikke i en undermappe – mappen er fundet automatisk, og filen flyttes dertil.",
            "Mappen er fundet ud fra filnavnet.")
        out.append({**s, "file": name, "ok": good, "message": message, "named": named or "", "reason": reason})
    return out


# --------------------------------------------------------------------------- kaldet
def call(name: str, args_json: str) -> str:
    fn = globals().get(name)
    if name.startswith("_") or not callable(fn):
        raise ValueError(f"Ukendt funktion: {name}")
    args = json.loads(args_json) if args_json else []
    return json.dumps(fn(*args), ensure_ascii=False, default=str)
